import { Client } from "pg";
const c = new Client({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
await c.connect();
const { rows } = await c.query(`select ("factorBreakdown"->>'fairProbability')::float8 p,
  ("factorBreakdown"->>'marketFairProb')::float8 m, case when result='WIN' then 1 else 0 end y
  from picks where "factorBreakdown"->>'fairProbability' is not null
  and "factorBreakdown"->>'marketFairProb' is not null and result in ('WIN','LOSS')`);
await c.end();
const n = rows.length, b = (f) => rows.reduce((a, r) => a + (f(r) - r.y) ** 2, 0) / n;
console.log(JSON.stringify({
  n,
  brierEngine: +b((r) => r.p).toFixed(4),
  brierMarket: +b((r) => r.m).toFixed(4),
  brierRecalibrated: +b((r) => 0.15 * r.p + 0.85 * r.m).toFixed(4),
  brierCoin: +b(() => 0.5).toFixed(4),
  overconfBefore: +(rows.reduce((a, r) => a + r.p, 0) / n - rows.reduce((a, r) => a + r.y, 0) / n).toFixed(4),
  overconfAfter: +(rows.reduce((a, r) => a + (0.15 * r.p + 0.85 * r.m), 0) / n - rows.reduce((a, r) => a + r.y, 0) / n).toFixed(4),
}));
