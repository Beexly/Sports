/**
 * The labeled fictional wire sample.
 *
 * This is the ONLY home of the fictional demo wire. C-416 removed it from
 * `lib/news/wire.ts` (whose module surface is the cron-polled stored feed, and
 * whose own tests assert no fictional export). The Beat renders this sample in
 * exactly one state: no feeds are configured AND no outage occurred — the
 * labeled-sample state, visually unmistakable from live (fictional-sources
 * marker). A failed fetch never reaches this data; an empty live wire never
 * reaches this data.
 *
 * Every source, player, and report below is FICTIONAL, so no fabricated report
 * is ever attributed to a real journalist; real insider names
 * (lib/news/wire.ts NATIONAL_INSIDERS) stay an internal reliability seed only.
 */

import type { NewsItem } from "./impact";

export const DEMO_WIRE: readonly NewsItem[] = [
  { id: "n1", source: "ESPN", tier: "Insider", team: "DET", player: "Aidan Hutchinson", headline: "Hutchinson (fractured tibia) placed on IR following surgery, expected out for regular season", signal: "injury-out", minutesAgo: 12 },
  { id: "n1b", source: "The Athletic", tier: "Beat", team: "DET", player: "Aidan Hutchinson", headline: "Confirmed: Hutchinson to begin recovery; Lions exploring edge rusher trade depth", signal: "injury-out", minutesAgo: 6 },
  { id: "n2", source: "NYJ Beat", tier: "Beat", team: "NYJ", player: "Davante Adams", headline: "Adams practicing in full with Aaron Rodgers, in line for full route package Sunday", signal: "role-up", minutesAgo: 35 },
  { id: "n3", source: "NFL Network", tier: "Insider", team: "SF", player: "Christian McCaffrey", headline: "McCaffrey (Achilles) ramping up sprint workouts, targeted for Week 10 return", signal: "injury-return", minutesAgo: 60 },
  { id: "n4", source: "Bills PR", tier: "Verified", team: "BUF", player: "Amari Cooper", headline: "Bills officially announce acquisition of WR Amari Cooper from Cleveland", signal: "depth-chart", minutesAgo: 90 },
  { id: "n5", source: "GB Beat", tier: "Beat", team: "GB", player: "Jordan Love", headline: "Love operating with zero limitations at practice; deep ball rhythm back on track", signal: "scheme", minutesAgo: 45 },
  { id: "n6", source: "ESPN", tier: "Insider", team: "TB", player: "Chris Godwin", headline: "Godwin (ankle) placed on injured reserve; Sterling Shepard to take slot reps", signal: "injury-out", minutesAgo: 140 },
  { id: "n7", source: "NWS Buffalo", tier: "Beat", team: "BUF", headline: "Gusting lake-effect winds of 22-28 mph forecast at Highmark Stadium", signal: "weather", minutesAgo: 110 },
  { id: "n8", source: "NE Beat", tier: "Beat", team: "NE", player: "Drake Maye", headline: "Maye operating first-team offense exclusively, expanding intermediate play-action playbook", signal: "scheme", minutesAgo: 80 },
  { id: "n9", source: "SEA Beat", tier: "Beat", team: "SEA", player: "Jaxon Smith-Njigba", headline: "Smith-Njigba taking WR1 targets in practice with DK Metcalf nursing knee strain", signal: "role-up", minutesAgo: 25 },
];
