import { Client } from "pg";
const c = new Client({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
await c.connect();
const { rows } = await c.query(`select ("factorBreakdown"->>'fairProbability')::float8 p,
  ("factorBreakdown"->>'marketFairProb')::float8 m,
  case when result='WIN' then 1 else 0 end y, "generatedAt" ts
  from picks where "factorBreakdown"->>'fairProbability' is not null
  and "factorBreakdown"->>'marketFairProb' is not null
  and result in ('WIN','LOSS') order by "generatedAt" asc`);
await c.end();
const n = rows.length, hit = rows.reduce((a, r) => a + r.y, 0) / n;
const mean = rows.reduce((a, r) => a + r.p, 0) / n;
const brier = (f) => rows.reduce((a, r) => a + (f(r) - r.y) ** 2, 0) / n;
const mix = (w) => (r) => w * r.p + (1 - w) * r.m;
console.log(JSON.stringify({
  n, hitRate: +hit.toFixed(4), meanProb: +mean.toFixed(4),
  overconfidence: +(mean - hit).toFixed(4),
  brierEngine: +brier((r) => r.p).toFixed(4),
  brierMarket: +brier((r) => r.m).toFixed(4),
  brier5050: +brier(() => 0.5).toFixed(4),
  corrEngine: +(rows.reduce((a, r) => a + (r.p - mean) * (r.y - hit), 0) / n / (Math.sqrt(rows.reduce((a,r)=>a+(r.p-mean)**2,0)/n) * Math.sqrt(hit*(1-hit)) || 1)).toFixed(4),
}));
// out-of-time: fit w (shrink to market) and k (shrink to 0.5) on oldest 70%
const cut = Math.floor(n * 0.7), tr = rows.slice(0, cut), te = rows.slice(cut);
const b = (f, set) => set.reduce((a, r) => a + (f(r) - r.y) ** 2, 0) / set.length;
let bestW = 0, bestWB = 9;
for (let w = 0; w <= 1.0001; w += 0.05) { const v = b(mix(w), tr); if (v < bestWB) { bestWB = v; bestW = w; } }
let bestK = 0.5, bestKB = 9;
for (let k = 0.3; k <= 1.5001; k += 0.05) { const v = b((r) => Math.min(0.99, Math.max(0.01, 0.5 + k * (r.p - 0.5))), tr); if (v < bestKB) { bestKB = v; bestK = k; } }
console.log(JSON.stringify({
  train: tr.length, test: te.length,
  bestW, trainBrierW: +bestWB.toFixed(4), testBrierW: +b(mix(bestW), te).toFixed(4),
  bestK: +bestK.toFixed(2), trainBrierK: +bestKB.toFixed(4),
  testBrierK: +b((r) => Math.min(0.99, Math.max(0.01, 0.5 + bestK * (r.p - 0.5))), te).toFixed(4),
  testBrierEngine: +b((r) => r.p, te).toFixed(4),
  testBrierMarket: +b((r) => r.m, te).toFixed(4),
  testHitRate: +(te.reduce((a, r) => a + r.y, 0) / te.length).toFixed(4),
}));
