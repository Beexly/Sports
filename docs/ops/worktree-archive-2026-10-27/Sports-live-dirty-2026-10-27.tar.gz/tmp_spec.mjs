import { Client } from "pg";
const c = new Client({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
await c.connect();
const { rows } = await c.query(`select reasoning, "factorBreakdown" from picks
  where result in ('WIN','LOSS') and reasoning is not null and "factorBreakdown" ? 'fairProbability' limit 600`);
await c.end();
const human = (k) => k.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/_/g, " ").toLowerCase();
let withContext = 0, zeroCit = 0, zeroNum = 0;
const citHist = {}, numHist = {};
for (const r of rows) {
  const t = r.reasoning.toLowerCase();
  const keys = Object.keys(r.factorBreakdown);
  const cited = keys.filter((k) => t.includes(human(k))).length;
  const nums = (r.reasoning.match(/[0-9]+(\.[0-9]+)?/g) ?? []).length;
  if (t.includes("context:")) withContext++;
  if (cited === 0) zeroCit++;
  if (nums === 0) zeroNum++;
  citHist[Math.min(cited, 3)] = (citHist[Math.min(cited, 3)] ?? 0) + 1;
  numHist[Math.min(nums, 4)] = (numHist[Math.min(nums, 4)] ?? 0) + 1;
}
console.log(JSON.stringify({ n: rows.length, withContext, zeroCit, zeroNum, citHist, numHist }));
