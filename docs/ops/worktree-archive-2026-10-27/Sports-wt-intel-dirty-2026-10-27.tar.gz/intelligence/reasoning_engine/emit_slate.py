"""Build the week-4 slate trace from the ESPN scoreboard fetch and kickoff-hour weather."""
import json
import os
import sys
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "qb-behavior", "src"))

from coaching.ol_provider import NflverseOLProvider
from coaching.provider import CoachingEngineProvider
from integration.providers import DataGapError
from reasoning_engine.facets import epa_facets
from reasoning_engine.slate import COORDS, fetch_kickoff_hour, prior_for_hour

SRC = os.path.join(os.environ["LOCALAPPDATA"], "Temp", "survey", "w4-scoreboard.json")
board = json.load(open(SRC, encoding="utf-8"))
ol = NflverseOLProvider()
coaching = CoachingEngineProvider()
now = datetime.now(timezone.utc)
games = []
for ev in board["events"]:
    comp = ev["competitions"][0]
    home = away = None
    for t in comp["competitors"]:
        if t.get("homeAway") == "home":
            home = t["team"]["abbreviation"]
        else:
            away = t["team"]["abbreviation"]
    venue = comp.get("venue") or {}
    indoor = bool(venue.get("indoor"))
    kickoff = ev["date"]
    row = {
        "kickoff": kickoff,
        "away": away,
        "home": home,
        "venue": venue.get("fullName"),
        "indoor": indoor,
        "status": comp.get("status", {}).get("type", {}).get("name"),
        "source": "espn scoreboard week=4 seasontype=2 dates=2026",
    }
    for team in (home, away):
        try:
            row[f"{team}_facets"] = epa_facets(team, 2026, before_week=4)
        except Exception as exc:
            row[f"{team}_facets"] = {"error": type(exc).__name__}
        try:
            state = ol.get_ol_state(team, 4, 2026)
            row[f"{team}_ol_out"] = list(state.starters_out)
        except DataGapError as exc:
            row[f"{team}_ol_out"] = None
            row.setdefault("gaps", []).append(f"ol {team}: {exc.reason[:120]}")
        try:
            tau = coaching.get_tau_hat(team, 2026, "opp", 0.50)
            row[f"{team}_tau"] = {"tau_hat": tau.get("tau_hat"), "fallback_level": tau.get("fallback_level")}
        except DataGapError as exc:
            row[f"{team}_tau"] = None
            row.setdefault("gaps", []).append(f"tau {team}")
    # London game is not the home stadium in the coord table.
    neutral = "Tottenham" in (venue.get("fullName") or "")
    coords = None if indoor or neutral else COORDS.get(home)
    if coords is None:
        row["weather"] = prior_for_hour(None, None, None, indoor=indoor, hour_matched=False)
        if neutral:
            row["weather"]["reason"] = "neutral site, no stadium coordinate committed"
        elif home not in COORDS and not indoor:
            row["weather"]["reason"] = f"no committed coordinate for {home}"
    else:
        try:
            hour = fetch_kickoff_hour(coords[0], coords[1], kickoff, now=now)
            if not hour.get("available"):
                row["weather"] = {"applied": False, "weightStatus": "not-applied", "totalPoints": None,
                                  "reason": "kickoff hour missing from forecast", "hourMatched": False,
                                  "source": hour.get("source")}
            else:
                adj = prior_for_hour(hour.get("windMph"), hour.get("precipInch"), hour.get("tempF"),
                                     indoor=False, hour_matched=True)
                adj["windMph"] = hour.get("windMph")
                adj["tempF"] = hour.get("tempF")
                adj["source"] = hour.get("source")
                adj["license"] = hour.get("license")
                row["weather"] = adj
        except Exception as exc:
            row["weather"] = {"applied": False, "weightStatus": "not-applied", "totalPoints": None,
                              "reason": f"fetch failed: {type(exc).__name__}", "hourMatched": False}
    games.append(row)

out = os.path.join(ROOT, "reasoning_engine", "traces", "week4-2026-slate.json")
os.makedirs(os.path.dirname(out), exist_ok=True)
doc = {
    "season": 2026,
    "week": 4,
    "fetched_from": "https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?week=4&seasontype=2&dates=2026",
    "games": games,
    "note": "Weather prior is applied only when the returned hour is the kickoff hour. Dome is not a measured calm. Facets exclude week 4 plays. No pick is emitted.",
}
json.dump(doc, open(out, "w", encoding="utf-8"), indent=2, default=str)
applied = [g for g in games if g["weather"].get("applied")]
print("games", len(games), "priors applied", len(applied))
for g in games:
    w = g["weather"]
    print(g["away"], "at", g["home"], g["indoor"], w.get("applied"), w.get("totalPoints"), w.get("reason", "")[:80])
