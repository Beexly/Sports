import json

with open(r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\dfs\dk_draftables_155198_w7_main_slate.json", encoding="utf-8") as f:
    d = json.load(f)

draftables = d.get("draftables", [])
statuses = {}
for p in draftables:
    st = p.get("status", "None")
    statuses[st] = statuses.get(st, 0) + 1

print("Status distribution across all 947 draftables:")
for st, count in sorted(statuses.items(), key=lambda x: -x[1]):
    print(f" - {st}: {count}")

# List players with OUT, IR, Doubtful, Suspended
invalids = []
for p in draftables:
    st = str(p.get("status", "")).upper()
    news = str(p.get("newsStatus", "")).upper()
    is_dis = p.get("isDisabled", False)
    if st in ("OUT", "IR", "DOUBTFUL", "SUSPENDED", "COVID") or is_dis:
        invalids.append((p.get("displayName"), p.get("teamAbbreviation"), p.get("position"), st, is_dis))

print(f"\nTotal invalid / excluded draftables by DK status: {len(invalids)}")
# Show sample
for inv in invalids[:20]:
    print(f" - {inv[0]} ({inv[1]} {inv[2]}): status={inv[3]}, disabled={inv[4]}")
