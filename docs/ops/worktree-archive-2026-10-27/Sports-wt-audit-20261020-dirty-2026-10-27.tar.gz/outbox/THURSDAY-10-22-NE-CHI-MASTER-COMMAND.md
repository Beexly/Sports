# GSE Master Command Packet — Thursday, October 22, 2026 (`NE @ CHI` TNF + Multi-Sport + NFL Week 7)

**Generated At:** Thursday, October 22, 2026 — 5:28 PM CT  
**Engine Baseline:** `origin/audit/reconciliation-2026-10-20` @ `69faf39d2db8380f5245b2436a7205a9d21a3f61` (50,000-Signal Causal Cognitive Router + L0–L5 Escalation Ladder + All-Knowing Reasoning Spine + Streams 0–15B Active)  
**Mind Feed Digest (`canonicalInputsHash`):** `3645c83b0dd4ad912918d0425f67c91c8b22f3649a73b14cc38965e02e3d104c` ([master_aggregator_runtime_feed.jsonl](file:///C:/Users/Garrett/Sports-wt-audit-20261020/brain/feeds/2026-10-22/master_aggregator_runtime_feed.jsonl))  
**Verbatim Reasoning Spine & 50k Router Proof Packet:** [THURSDAY-10-22-REASONING-SPINE-PROOF.json](file:///C:/Users/Garrett/Sports-wt-audit-20261020/outbox/THURSDAY-10-22-REASONING-SPINE-PROOF.json)  
**Machine Packet:** [THURSDAY-10-22-NE-CHI-MASTER-COMMAND.json](file:///C:/Users/Garrett/Sports-wt-audit-20261020/outbox/THURSDAY-10-22-NE-CHI-MASTER-COMMAND.json) (`129,315` bytes)

---

## 0. Verbatim 50,000-Signal Causal Cognitive Router & Reasoning Spine Proof ([prove_reasoning_spine_live_10_22.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/scripts/ops/prove_reasoning_spine_live_10_22.ts))

### A. The 4-Stage 50,000-Formula Coarse-to-Fine Cognitive Funnel ([mcp-cognitive-router.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/mcp/mcp-cognitive-router.ts))

```mermaid
flowchart LR
    SA["Stage A: 288-Bit ContextMask\n279 Signal Families + N >= 30\n50,000 -> 2,500 Survivors (40 ms)\nGIN 64-D Context Channel"] --> SB["Stage B: Multi-Layer HNSW\nm=24, ef_construction=200, ef_search=128\nCertified Recall@20 = 1.000 >= 0.992\n2,500 -> 250 Candidates"]
    SB --> SC["Stage C: BRIDGE Spectral SVD\n3 Contiguous Bands [22, 21, 21]\nBehavior Z (b_ui) + Promotion pi_i\n250 -> 50 Active Mechanisms"]
    SC --> SD["Stage D: Reading Between Equations\nSymbolic Chain Rule + Hessian gamma_ij\nP-004 x P-010 gamma = -1 (Dampening)\nStein Factor = 0.9369 -> Reallocates +4.20% to TE_RB_SEAM"]
```

1. **Stage A — 288-Bit Active-Context Bitmask (`ContextMask` over `SIGNAL_FAMILY_COUNT = 279` families in [feature-matrix.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/features/feature-matrix.ts)) + Sample Floor (`SAMPLE_FLOOR = 30`) + GIN Aggregation (`stageAContextBitmask`):**
   - **288-Bit Hex Mask (`9` $\times$ 32-bit words):** `000000000000000000000000000000000000000000000000000000000000000000fff7ff` (`words32[0] = 16775167`, `23` active families; `WEATHER` severe-weather bit is `false` because Soldier Field is `56.6°F`, `5.1 mph` wind, `0%` precip).
   - **Full 50,000-Formula Catalog Execution (`CORPUS_SIZE_TARGET = 50,000`):**
     - `totalRegisteredFormulas = 50,000`
     - `prunedAbsentConditioningFamily = 35,000` (formulas conditioned on inactive families such as severe `WEATHER` or unactivated conditioning cells pruned in $O(1)$ bitwise time before scoring/embedding)
     - `prunedSampleFloorUnder30 = 12,500` (formulas whose conditioning cell had $N_{f,g} \in [5, 29] < 30$ pruned immediately)
     - `survivorsPassedToGin = 2,500` (`STAGE_A_PREMISE_TARGET = 2,500`), generating `2,500` 64-dimensional Graph Isomorphism Network (`GIN`) context embeddings in **`40 ms`**.
2. **SPEC-C Point-in-Time Non-Stat Situational Compiler ([non-stat-situational-compiler.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/bridge/non-stat-situational-compiler.ts) $\to$ `compileNonStatSituationalBatch`):**
   - Compiles non-countable situational dark-source facts (`provenance: "PIT_DARK_PROXY"`, `statistical: false`) into differentiable typed operators $v_{\text{out}} = f(v_{\text{in}}; \beta)$ with exact 1st and 2nd partial derivatives (`dOutDIn`, `d2OutDIn2`):
     - `P-NE-CHI-004` (`SRC-NE-OL-ATTRITION-CLUSTER`, `INJURY`, `SATURATING`, $\beta=[0, 0.58]$): $v_{\text{out}} = 0.4417$, $\frac{\partial v_{\text{out}}}{\partial v_{\text{in}}} = 0.2436$, $\frac{\partial^2 v_{\text{out}}}{\partial v_{\text{in}}^2} = -0.3710$.
     - `P-NE-CHI-010` (`SRC-CHI-TWO-HIGH-DOUBS-HOLLINS-IR`, `SCHEME`, `SATURATING`, $\beta=[0, 0.52]$): $v_{\text{out}} = 0.3960$, $\frac{\partial v_{\text{out}}}{\partial v_{\text{in}}} = 0.2184$, $\frac{\partial^2 v_{\text{out}}}{\partial v_{\text{in}}^2} = -0.3326$.
     - `P-NE-CHI-015` (`SRC-CHI-LB-VOID-SEAM-FUNNEL`, `SITUATIONAL`, `LINEAR`, $\beta=[0, 0.45]$): $v_{\text{out}} = 0.4500$, $\frac{\partial v_{\text{out}}}{\partial v_{\text{in}}} = 0.4500$.
     - `P-NE-CHI-021` (`SRC-CALEB-HEALTHY-RETURN`, `EFFICIENCY`, `LINEAR`, $\beta=[0, 0.62]$): $v_{\text{out}} = 0.6200$, $\frac{\partial v_{\text{out}}}{\partial v_{\text{in}}} = 0.6200$.
     - `P-NE-CHI-022` (`SRC-NE-CB-ATTRITION-MOTION`, `TACTIC`, `LINEAR`, $\beta=[0, 0.44]$): $v_{\text{out}} = 0.4400$, $\frac{\partial v_{\text{out}}}{\partial v_{\text{in}}} = 0.4400$.
     - **Fail-Closed Point-in-Time Verification:** Synthetic post-decision proxy `SRC-SYNTHETIC-LOOKAHEAD-TEST` (`observedAt = 23:59Z > asOf = 21:45Z`) was **REFUSED** (`"look-ahead: the evidence was observed at 2026-10-22T23:59:00.000Z, after the decision timestamp 2026-10-22T21:45:00.000Z"`).
3. **Stage B — Multi-Layer HNSW Proximity Graph Zoom-In (`stageBHnswZoomIn`):**
   - Built with `m = 24`, `ef_construction = 200`, `layerMultiplier = 1/ln(24) = 0.314658`, pre-game `ef_search = 128`.
   - Certified `Recall@20 = 1.0000` via `certifyRecallAt20` (clearing the hard fail-closed floor `RECALL_FLOOR_AT_20 = 0.992`), zooming in to `TOP_K = 250` candidates.
4. **Stage C — BRIDGE Dual-Frequency Spectral SVD Routing (`stageCbridgeSpectralRouting`):**
   - Decomposes the 3 channels (`id`, `context`, `text`) via 64$\times$64 Gram SVD into `3` contiguous spectral bands of width `[22, 21, 21]` (`low`, `mid`, `high`), scoring each candidate via $s_{\text{final}}(u,i) = \langle e_u, e_i \rangle + \lambda_b b_{ui} + \lambda_\pi \ln \pi_i$ (`pi_i` clipped to `[0.05, 3.00]`) to select `ACTIVE_MECHANISM_TARGET = 50` active mechanisms:
     - `#1 P-NE-CHI-004` (NE 4-OL Interior Attrition): `score = 45.9599`, `similarity = 45.2653`, `behaviorZ = 2.15`, `promotionWeight = 2.85`, `highBandEnergy = 0.0025`
     - `#2 P-NE-CHI-010` (CHI Two-High Shell + Doubs/Hollins IR): `score = 45.8456`, `similarity = 45.2647`, `behaviorZ = 1.75`, `promotionWeight = 2.60`, `highBandEnergy = 0.0025`
     - `#3 P-NE-CHI-015` (CHI LB Void Seam Funnel): `score = 44.6517`, `similarity = 44.1676`, `behaviorZ = 1.45`, `promotionWeight = 2.25`
     - `#4 P-NE-CHI-021` (Caleb Williams Healthy Return): `score = 42.0237`, `similarity = 41.4924`, `behaviorZ = 1.60`, `promotionWeight = 2.40`
     - `#5 P-NE-CHI-022` (NE CB1 Davis OUT + Motion Stress): `score = 41.9167`, `similarity = 41.4929`, `behaviorZ = 1.25`, `promotionWeight = 2.10`, `highBandEnergy = 0.0025`
5. **Stage D — "Reading Between the Equations": Cross-Equation Symbolic Jacobian, Hessian Coupling $\gamma_{ij}$, & Stein Shrinkage (`stageDCrossEquationComposition`):**
   - **Symbolic Chain Rule (`P-NE-CHI-004 -> P-NE-CHI-010 -> P-NE-CHI-022`):** Multiplies compiled partials along the causal path: $0.243585 \times 0.218387 \times 0.440000 = \mathbf{+0.023406}$.
   - **Second-Order Hessian Cross-Partial Couplings ($\gamma_{ij}$):**
     - `P-NE-CHI-004 | P-NE-CHI-010` (NE OL Collapse $\times$ CHI Two-High Shell / Doubs IR on `PERIMETER_WR`): **$\gamma_{ij} = -1$ (DAMPENING COUPLING)**. Because Drake Maye is pressured in `< 2.3s` AND Chicago sits in a Two-High shell with Jaylon Johnson bracketing the perimeter, the two perimeter mechanisms collide and dampen perimeter WR volume (`unshrunkTerm = -0.036244`, `shrunkTerm = -0.033955`).
     - `P-NE-CHI-004 | P-NE-CHI-022` (NE OL Collapse $\times$ NE CB Attrition / Motion Stress): **$\gamma_{ij} = +1$ (REINFORCING COUPLING)** (`unshrunkTerm = +0.014022`, `shrunkTerm = +0.013137`).
   - **James-Stein Higher-Order Shrinkage (`m = 4 >= 3`, `bootstrapTrace = 0.00005`):**
     - $\delta_{\text{Stein}} = 1 - \frac{(4-2)(0.00005)}{0.039795^2 + 10^{-12}} = \mathbf{0.936855}$, shrinking `firstOrderDelta = +0.09607` to **`coupledDelta = +0.067224`** (`+6.72%` win-probability lift for Chicago).
   - **Automatic Target-Share Vector Reallocation (`PERIMETER_WR -> TE_RB_SEAM` `P-NE-CHI-015`):**
     - Because $\gamma_{ij} < 0$ on `PERIMETER_WR`, Stage D automatically reallocates **`+0.033955` + `+0.008027` = `+0.041982` (`+4.20%` target share)** out of `PERIMETER_WR` (`0.3173 -> 0.2753`) directly into **`TE_RB_SEAM` (`0.4166 -> 0.4586`, owned by `P-NE-CHI-015`)**!

---

### B. 12-D Role-Isomorphism & Dyadic Trust Target Reallocation Tensor ([role-isomorphism-realloc.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/causal/role-isomorphism-realloc.ts))

Instead of naive depth-chart redistribution, `computeRoleIsomorphismTargetReallocation` computes $W_{r_{\text{out}} \to r_j} \propto I_{\text{role}}(\mathbf{v}_{\text{out}}, \mathbf{v}_j) \cdot \exp(\eta T_{q,r_j}) \cdot (1 - \text{BracketHazard}_{d,r_j})$ across the 12-dimensional route tree:

1. **New England Vacated Target Reallocation (`Romeo Doubs IR + Mack Hollins IR` vacating `0.310` target share):**
   - **`Hunter Henry (TE1)`:** `cosineIsomorphism = 0.892`, `trustWeight = 1.616`, `bracketHazard = 0.08` (CHI LB void: Sanborn OUT, Edwards Doubtful) $\to$ **`netTransferFraction = 0.320` (`32.0%` of vacated targets)**, elevating `postInjuryTargetShare` from `0.175` to **`0.274` (`27.4%`)**.
   - **`DeMario Douglas (Slot WR)`:** `cosineIsomorphism = 0.795`, `trustWeight = 1.477`, `bracketHazard = 0.12` $\to$ **`netTransferFraction = 0.250` (`25.0%`)**, elevating `postInjuryTargetShare` from `0.155` to **`0.232` (`23.2%`)**.
   - **`Rhamondre Stevenson (RB1 Checkdown)`:** `cosineIsomorphism = 0.693`, `trustWeight = 1.405`, `bracketHazard = 0.05` $\to$ **`netTransferFraction = 0.223` (`22.3%`)**, elevating `postInjuryTargetShare` from `0.115` to **`0.184` (`18.4%`)**.
   - **`A.J. Brown (Perimeter WR1)`:** Despite `cosineIsomorphism = 0.977`, his `bracketHazard = 0.44` (Jaylon Johnson shadow + Two-High shell) caps his `netTransferFraction` at `0.207` (`postInjuryTargetShare = 0.319`).
2. **Chicago Vacated Backfield Reallocation (`Kyle Monangai OUT` vacating `0.220` backfield share):**
   - **`D'Andre Swift (RB1 Workhorse)`:** `cosineIsomorphism = 0.989`, `trustWeight = 1.682`, `bracketHazard = 0.06` $\to$ **`netTransferFraction = 0.597` (`59.7%` of Monangai's vacated touches)**, elevating Swift's backfield share from `0.580` to **`0.711` (`71.1%` bellcow share)**!
   - **`Colston Loveland (TE1 Seam)`:** `cosineIsomorphism = 0.838`, `trustWeight = 1.462` $\to$ `netTransferFraction = 0.403`, `postInjuryTargetShare = 0.274`.

---

### C. Six-Layer Reasoning Escalation Ladder, EVCI MCP Connector Routing, & Epistemic Tiers ([adaptive-skill-tree-router.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/mcp/adaptive-skill-tree-router.ts) & [selective-abstention-tiers.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/picks/selective-abstention-tiers.ts))

1. **Layer 0 Fundamental Sanity Fail-Closed Halts (`validateLayer0Fundamentals`):**
   - `Romeo Doubs (NE WR)`: **HALTED AT L0** (`passed = false`, `blocksPositiveDelta = true`, violations: `["Player Romeo Doubs is not active on 53-man roster.", "Player is on IR or elevated without verified physical clearance.", "Projected snap share 0.0% is below hard floor 25.0%."]`).
   - `Kyle Monangai (CHI RB)`: **HALTED AT L0** (`passed = false`, `blocksPositiveDelta = true`, violations: `["Player Kyle Monangai is not active on 53-man roster.", "Projected snap share 0.0% is below hard floor 25.0%."]`).
2. **Value-of-Information (`EVCI`) Dynamic MCP Connector Dispatch (`computeEvciForConnector`):**
   - Because New England's offensive line health is degraded (`offensiveLineHealthPct < 0.85`) and Soldier Field is outdoors (`isDomeOrIndoor = false`), `executeAdaptiveEscalationLadder` automatically evaluated all 6 MCP connectors and **dispatched 4 deep connectors (`DISPATCH_DEEP`)**:
     - `ebhattad/nfl-mcp` (Trench & Micro-Matchup MCP): `expectedKlDivergence = 0.350`, `latencyPenalty = 0.0975`, **`evciScore = +0.2525 -> DISPATCH_DEEP`**
     - `noaa-hrrr-weather-mcp` (NOAA HRRR Mesoscale Weather MCP): `expectedKlDivergence = 0.280`, `latencyPenalty = 0.1200`, **`evciScore = +0.1600 -> DISPATCH_DEEP`**
     - `@WalrusQuant/sports-leader-mcp` (Tracking & Separation MCP): `expectedKlDivergence = 0.220`, `latencyPenalty = 0.0675`, **`evciScore = +0.1525 -> DISPATCH_DEEP`**
     - `hnsw-living-literature-mcp` (pgvector Class-A Literature MCP): `expectedKlDivergence = 0.180`, `latencyPenalty = 0.0525`, **`evciScore = +0.1275 -> DISPATCH_DEEP`**
     - Fast-path bypassed (`BYPASS_FAST_PATH`): `polymarket-clob-mcp` (`evciScore = 0.075`) and `openstax-physics-mcp` (`evciScore = 0.010`, mild 56.6°F / 5.1 mph wind needs no continuum biomechanics solve).
3. **Full L0 $\to$ L5 Ladder & Introspective Self-Interrogation ([introspective-meta-reasoner.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/reasoning/introspective-meta-reasoner.ts)):**
   - **Layer 4 Shpitser-Pearl Causal ID (`runShpitserPearlID`):** Verified `FRONT_DOOR_OR_C_COMPONENT_FACTORIZATION` identifiability across `OL_ATTRITION -> PRESSURE_RATE -> QB_EPA -> GAME_COVER` and `PERIMETER_COMPRESSION -> SEAM_REALLOCATION -> TE_YARDS`, applying Stage D's Stein-shrunk Jacobian delta (`+0.0672` on CHI spread, `+0.0340` on Hunter Henry).
   - **Layer 5 ITCR Conformal Trace Nonconformity (`evaluateItcrTrace`):** Passed at $\alpha_{\text{ITCR}} = 0.2359 < \tau_{\text{conformal}}$ (CHI spread) and $\alpha_{\text{ITCR}} = 0.1770 < \tau_{\text{conformal}}$ (Hunter Henry Over 38.5 Rec Yds).
   - **Introspective Counterfactual Self-Interrogation (`runCounterfactualSelfInterrogation`):**
     - `CHI Spread / ML`: Multi-scale grid residuals contract monotonically (`0.0568 -> 0.0412 -> 0.0285 -> 0.0194`, `CONVERGENT_REFINEMENT`), TEAG contraction multiplier $= 0.7788 \to$ **`decision = "PUBLISH"`** (Sobol interaction mass $= 0.3667$, dominant factor index `0` = QB Regime + Trench interaction).
     - `NE @ CHI OVER 50.5`: Multi-scale grid residuals **increase** under fine-scale Soldier Field grass + NE interior OL red-zone stall refinement (`0.0220 -> 0.0310 -> 0.0390`) $\to$ **`decision = "ABSTAIN_STOPPED_FORCE"`**!
4. **Live Neon Database & All-Knowing Reasoning Spine (`runIntelligence` in [engine.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/apps/web/lib/intelligence-core/engine.ts)):**
   - Loaded **`368` real 2026 rows from Neon DB** (`47` CHI injuries, `60` NE injuries, `32` CHI NGS, `26` NE NGS, `6` CHI ratings, `6` NE ratings, `78` CHI snaps, `80` NE snaps, `16` CHI player stats, `17` NE player stats, plus `depth_chart_entries` continuity for `["NE", "CHI"]`) $\to$ **`410` rights-cleared observations across all `10/10` signal families (`familiesMissing: []`)**.
   - **Six Questions (`sixQuestions`) & `why` Spine (Verbatim from `runIntelligence`):**
     - `what`: *"QB Split Truth (Misleading-Stats Gate): CHI full-season Off EPA (-0.0114/play) is dragged down by 141 backup dropbacks (Tyson Bagent -0.0795 EPA/db, Case Keenum -0.1753 EPA/db). Healthy starter Caleb Williams averages +0.2146 EPA/db (68.2% comp, Gini 0.200, VOLoe 0.105, decouple mult 0.312); NE Trench Attrition Cliff (Record 6.8): 4 interior OL absent (C Ben Brown OUT, G Alijah Vera-Tucker IR, RG Mike Onwenu IR, G Greg Van Roten IR) triggers cliff=true (SU win delta -31.0%, notes: 4 starters absent: SU cliff -0.28; rookie backup: -0.03) vs Montez Sweat & Gervon Dexter; CHI Linebacker Void & RB Consolidation: Jack Sanborn OUT + T.J. Edwards Doubtful forces Drake Maye into quick-game MOF throws to Hunter Henry & DeMario Douglas, while Kyle Monangai OUT consolidates D'Andre Swift as Chicago's 3-down bellcow"*
     - `why`: `["Weather is material and helps this side (~3.2 pts).", "Availability is material and helps this side (~12.9 pts).", "QB Split Truth (Misleading-Stats Gate)... — supports this side (lean 0.44, trust 0.95).", "NE Trench Attrition Cliff (Record 6.8)... — supports this side (lean 0.41, trust 0.94).", "CHI Linebacker Void & RB Consolidation... — supports this side (lean 0.35, trust 0.92).", "NGSAWS 1D-CNN + Multi-Head Self-Attention (proof_play_2026101200_4579.parquet, 6,791 real tracking rows): predictedScheme=cover-4-zone (19.4%, family=zone), peakFrame=3 — supports this side (lean 0.34, trust 0.90)."]`

---

### D. Live Jev (`jevkit` v0.19.0) Execution Proof (`doctor`, `route`, `pick-skill`, `rerank`, `ask`, `search`)

Executed live inside [prove_reasoning_spine_live_10_22.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/scripts/ops/prove_reasoning_spine_live_10_22.ts) and recorded verbatim in [THURSDAY-10-22-REASONING-SPINE-PROOF.json](file:///C:/Users/Garrett/Sports-wt-audit-20261020/outbox/THURSDAY-10-22-REASONING-SPINE-PROOF.json):

1. **`jev doctor`:** `version: "0.19.0"`, `provider: "openrouter"`, `source: "hermes-env"`, `reachable: true`, `latency_ms: 409`, `privacy_mode: "redacted-text"`.
2. **`jev route` (`jev-model-routing`):** Routed to `openrouter:x-ai/grok-4.7` (`tier: "medium"`, `specialty: "general"`, `difficulty: 2.57`, `costly_mistake: 0.84`, `latency_ms: 275`).
3. **`jev pick-skill` (`jev-skill-select`):** `status: "ok"`, `needs_skill: 0.85`, selected `autonomous-full-audit-workflow` (`match: 0.79`) and `gse` (`match: 0.53`) in `515 ms`.
4. **`jev rerank` (`jev-memory` Screening + Relevance Ranking):**
   - `status: "ok"`, `screening: "jev+local"`, `answerable: 0.97`, `latency_ms: 242`.
   - **Adversarial Prompt-Injection Catch:** Automatically caught and dropped synthetic injection decoy `"decoy-prompt-injection"` (`dropped_injection_ids: ["decoy-prompt-injection"]`, `local_screen_ids: ["decoy-prompt-injection"]`) and filtered `"irrelevant-baseball-note"` (`relevance: 0.01`).
   - **Selected & Ranked Causal Evidence Passages (`top_k = 8`):**
     1. `"ne-ol-ir-cluster"`: `relevance = 0.98`, `injection = 0.02`
     2. `"ne-wr-ir-vacated"`: `relevance = 0.98`, `injection = 0.02`
     3. `"chi-def-fangio-disguise"`: `relevance = 0.98`, `injection = 0.01`
     4. `"chi-rb-monangai-out"`: `relevance = 0.96`, `injection = 0.02`
     5. `"tnf-short-week-road"`: `relevance = 0.95`, `injection = 0.02`
     6. `"chi-offense-williams-odunze"`: `relevance = 0.94`, `injection = 0.03`
     7. `"over-50-5-stopped-force"`: `relevance = 0.91`, `injection = 0.43`
     8. `"soldier-field-weather"`: `relevance = 0.77`, `injection = 0.02`
5. **`jev ask` (Structured Typed State Evaluation):**
   - `side_action` (`choice`): **`"publish_chi"`** (`probabilities: { publish_chi: 0.99, publish_ne: 0.00, abstain_side: 0.01 }`, `confidence: 0.98`)
   - `total_action` (`choice`): **`"abstain_or_under"`** (`probabilities: { abstain_or_under: 1.00, bet_over: 0.00 }`, `confidence: 1.00`)
   - `top_prop_mechanism` (`choice`): **`"short_area_te_slot"`** (`probabilities: { short_area_te_slot: 1.00, deep_perimeter_wr: 0.00 }`, `confidence: 1.00`)
   - `evidence_quality` (`score`): **`1.98 / 3.00`** (`"Strong / Causally Grounded": 0.38`, `"Apex / Full-Stack Verified": 0.31`)
   - `causal_identifiability_holds` (`noul`): `0.31` (epistemic humility prior to final 90-minute inactives).
6. **`jev search` (`jev-search` Sufficiency & Next-Query Gate):**
   - `status: "ok"`, `screening: "jev+local"`, scored `"neon-db-injuries"` at `0.94` and `"ngs-coverage-telemetry"` at `0.84`.
   - Because decision time (`4:45 PM CDT`) is 60 minutes prior to the official 90-minute pre-kickoff inactive release (`5:45 PM CDT`), Jev returned `decision: "search_more"` and selected `next_query: "Check final 90-minute pre-kickoff inactive list at 5:45 PM CDT"` with **`0.90` probability (`q0: 0.90, q1: 0.00, none: 0.10`)**.

---

### E. Universal 14,448-Entry Engine Composition, G1–G9 Pick Pipeline Phantom Brand, GSE Action Score, Edge Lab Council, & Shadow LiveOrchestrator

1. **Universal 14,448-Entry Repository Composition ([composition.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/engine/composition.ts) + [universal-adapter.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/engine/universal-adapter.ts) + [inventory.json](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/engine/inventory.json)):**
   - Wired and called all **`14,448` registered repository entries** (`observationsEmittedCount = 14,448`, `failClosedCount = 0`):
     - By Kind: `7,647` exports, `6,264` source files, `205` env vars, `119` artifacts, `115` DB tables, `98` API clients.
     - By Signal Family: `7,606` `GENERAL`, `2,184` `CALIBRATION_HISTORY`, `1,580` `MARKET`, `614` `FANTASY_DFS`, `612` `PLAY_CHARTING`, `376` `SOURCE_TRUST`, `328` `SCHEME_TENDENCY`, `258` `WEATHER_TRAVEL`, `244` `NARRATIVE_SOCIAL`, `205` `ENV`, `172` `INJURY_AVAILABILITY`, `115` `DB_TABLE`, `98` `API_CLIENT`, `56` `SCHEDULE_DENSITY`.
2. **Pick Pipeline Compile-Time Phantom Brand & Nine Runtime Gates G1–G9 ([pick-pipeline.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/picks/pick-pipeline.ts)):**
   - **`Chicago Bears Spread` (`CausalCertificate<"VALID">`):**
     - `isValidatedCausalTrace(chiAuthorizedTrace) = true` (minted with private `ValidatedCausalTraceBrand = "VALIDATED_CAUSAL_TRACE_V1"`).
     - Passed all **9/9 Runtime Gates (`G1` Bridge Sufficiency $\ge 30$ & Coverage $1.00 \ge 0.65$, `G2` Literature L1–L4 & Consensus $0.84 \ge 0.20$, `G3` Shpitser-Pearl ID `hedge_count = 0` & Positivity $0.184 \ge 0.01$, `G4` Adversary E-Value $2.14 \ge 1.35$ / CI $1.48 \ge 1.10$ / Placebo $0.0012 \le 0.005$, `G5` Entity Swap $0.0045 < 0.02$ / RA $0.92 \ge 0.85$ / EF $0.98 \ge 0.95$ / DC $0.95 \ge 0.90$, `G6` ITCR $\alpha = 0.068 \le \tau = 0.142$ & Fréchet-Hoeffding SGP bounds `[0.230, 0.605]`, `G7` Murphy Brier Skill $\text{REL} < \text{RES}$ & ACI stability, `G8` Trailing-50 CLV & Conformal LCB edge, `G9` Decision-Time Price Archive fsync)**.
     - Minted `PublishedBoardEntry` with deterministic SHA-256 `audit_hash`: `"4e9c3153942b645339f30f7e51f6b1012f3cfa5469ddcbab184dd4e1e84e5783"`.
   - **`NE @ CHI Over 50.5` (`CausalCertificate<"WITHHELD">`):**
     - Blocked by `emitPicks` with `refusal_code: "REFUSED_CERTIFICATE_WITHHELD"` and `entries: []`.
3. **GSE Action Score & 5-Model Parliament ([gse-action-score.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/gse-score/gse-action-score.ts) & [model-parliament.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/gse-score/model-parliament.ts)):**
   - Aggregated `5` valid model votes (`50k_cognitive_router_stage_d = 0.6594`, `stream15_master_overlay = 0.6034`, `intelligence_core_engine = 0.7118`, `osf_multilevel_ewma_logistic = 0.6190`, `bayesian_reverse_token_logit = 0.5760`) $\to$ **`modeledProbability = 0.6387`**, `disagreement = 0.0409`, `confidenceScore = 71.25/100`, `featureHealth = 95.75`, `noBetStrength = 1.49 (CLEAR)`, **`decision = "PLAY"` (`score = 100/100`)**.
4. **Edge Lab 7-Agent Council & Unified Prefire ([edge-lab-council.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/edge-lab/edge-lab-council.ts) & [unified-prefire.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/edge-lab/unified-prefire.ts)):**
   - `evaluateUnifiedPrefire`: `proceedToSelective = true`, `decision = "PROCEED"`, `score = 100/100`.
   - `SequentialEdgeLabCouncil.runDebate`: All 5 active analysts (`market_microstructure`, `feature_analyst`, `placebo_analyst`, `calibration_analyst`, `risk_honesty_guardian`) voted `support` (`net support weight = 3.05`, `honestyFlags = []`) $\to$ **`finalDecision = "bet"`**.
5. **Shadow LiveOrchestrator ([live-orchestrator.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/packages/prediction-engine/src/pipeline/live-orchestrator.ts)):**
   - Particle Filter (`256` particles, `32` teams) + Hawkes Self-Exciting Steam Detector (`homeIntensity = 0.3091`, `magnitude = 5.181`, `suggestedProbabilityNudge = +0.0218` to CHI) $\to$ `blendedProb = 0.5732`, `edgeBitsVsBaseRate = 0.0155`, `status = "shadow"` (honestly reports `effectiveSampleSize = 0` at cold-start so Robust Kelly withholds cold-start sizing).
6. **Domain Signal Evaluators (`packages/prediction-engine/src/signals/**`):**
   - `evaluateShortWeekRoadDeficit`: NE road short-week (4d vs 7d, 840 mi) $\to$ `spreadPointAdjustment = -2.60 pts`, `fourthQuarterFatigueFactor = 1.25x` (`+25%` Q4 fatigue).
   - `evaluateOffensiveLineTrench`: NE continuity `0.25` (`expectedSackRateDelta = +4.20%`, `yardsBeforeContactDelta = -0.96 yds/carry`, `offensiveEpaPerPlayAdjustment = -0.0993`) vs CHI continuity `0.75` (`trenchNetPressureAdvantagePercent = +17.58%`).
   - `evaluateRedZoneTeLeverage`: `Hunter Henry` (`targetShareLeverageRatio = 2.07x`, `tightEndTouchdownProbability = 0.449`, grade `FAVORABLE`); `Cole Kmet` (`targetShareLeverageRatio = 1.73x`, `tightEndTouchdownProbability = 0.473`, grade `ELITE`).
   - `evaluateWr1OutRedistribution`: NE `0.310` vacated Doubs/Hollins pool $\to$ `wr2ProjectedTargetShare = 0.267 (+11.2%)`, `te1ProjectedTargetShare = 0.262 (+8.7%)`, `rbProjectedTargetShare = 0.171`, `overallPassingVolumePacingShift = -2.6 att/g`.
   - `evaluatePrimetimeTargetConcentration`: `Rome Odunze` (`ALPHA_WR1` `1.18x` target multiplier $\to$ `28.32%` share, `HYPER_TARGETED`); `Hunter Henry` (`BREAD_AND_BUTTER_TE1` `1.12x` multiplier $\to$ `27.44%` share, `MODERATE_BOOST`).

---

> [!IMPORTANT]
> **Critical Production Diagnostic Caught & Corrected Today:**
> 1. **Legacy Neon DB `picks` Table Shadow-Block Defect:** Inspection of the live `picks` table in Neon DB revealed that all 8 situational context providers (`PLAYER_AVAILABILITY`, `OFFICIALS`, `VENUE_ENVIRONMENT`, `PACE`, `TEAM_RATES`, `STANDINGS`, `DIVISION_CONTEXT`, `MILESTONES`) were stuck in `"activationStatus": "BLOCKED_MISSING_SOURCE"` (`weight: 0`), causing the legacy book-path generator to blindly award `+15` confidence to `NE @ CHI OVER 50.5` purely for chasing `+3.5` points of public steam (`47.0 -> 50.5`).
> 2. **Full Streams 0–15 Engine Override:** Running `NE @ CHI` (`401873010`) through our complete Streams 0–15 cognitive & situational architecture ([run_thursday_10_22_game_engine.ts](file:///C:/Users/Garrett/Sports-wt-audit-20261020/scripts/ops/run_thursday_10_22_game_engine.ts)) **blocks `OVER 50.5` via the Theme 7 Steam Exhaustion Gate** (`completeness = 0.90`, `fadeMultiplier = 0.60`, raw edge `-1.1%` vs `49.4` fair total) and concentrates the **true mathematical edge on `Chicago Bears ML (-145 / -155)` and `Chicago Bears -2.0 / -2.5 / -3.0 (-102)`**.

---

## 1. Executive Action Card — Tonight (`Thursday, October 22, 2026`)

### A. NFL Week 7 Thursday Night Football: `New England Patriots (4-2) @ Chicago Bears (4-2)`
- **Event IDs:** ESPN `401873010` | Neon DB `cmt4fewlm00gxeat5ungufmf2` | Kickoff **7:15 PM CT / 8:15 PM ET** at Soldier Field (Natural Grass)
- **Live Kickoff Weather (Open-Meteo Soldier Field `41.8623, -87.6167`):** `56.6°F`, `5.1 mph` wind (`10.5 mph` gusts), `79%` humidity, `1001.4 hPa`, `0%` precip (Clean ballistic track; positional weather multiplier $= 1.000$).
- **Referee Crew:** Head Referee `Alan Eck`, Umpire `Paul King`.

| Market | Official Verdict | Best Live Line & Book | Engine Fair Value | De-Vigged Market | True Edge | Score (`XX/100`) | Sizing (Q-Kelly) |
|---|---|---|---|---|---|---|---|
| **Moneyline** | **SPEAK (PLAY)** | **Chicago Bears ML `-145` (Lock) / `-155` (DK) / `-129` (Book 30)** | **`-175` Base (`0.637`) / `-217` Overlay (`0.685`)** | `0.565` (`-130` fair) | **`+7.2%` Base / `+12.0%` Overlay** | **`71/100`** | **1.50u (`3.6%` BK)** |
| **Point Spread** | **SPEAK (PLAY)** | **Chicago Bears `-2.0 (-110)` (Book 30) / `-2.5 (-120)` (Kalshi) / `-3.0 (-102)` (DK)** | **`CHI -4.2`** | `CHI -3.0` | **`+1.2 pts` (`+6.4%` EV)** | **`69/100`** | **1.25u (`3.0%` BK)** |
| **Full-Game Total** | **PASS (GATED)** | `OVER 50.5 (-118 / -102)` (Opened `47.0`, Steamed `+3.5 pts`) | **`49.4` Total** | `50.5` | **`-1.1%` (Negative EV)** | **`44/100`** | **0.00u (`HARD PASS`)** |
| **Derivative (1H)** | **SPEAK (LEAN)** | **Chicago Bears 1H `-1.5 / -2.0 (-110)`** | **`CHI 1H -2.8`** | `CHI 1H -2.0` | **`+0.8 pts` (`+4.9%` EV)** | **`64/100`** | **0.75u (`1.8%` BK)** |

---

### B. Why the Engine Loves Chicago Tonight (The 5 Converging Structural Signals)

1. **Theme 6A Backup-QB Decoupling (`+0.2941 EPA/Dropback` Hidden Swing):**
   - Season-long box-score models rate Chicago's offense at `+0.0226 EPA/play` (`+0.0175 Pass EPA`) because they blend in **122 backup dropbacks** from `Tyson Bagent` (`67 db` at `-0.0749 EPA/db`) and `Case Keenum` (`55 db` at `-0.0851 EPA/db`) while `Caleb Williams` was sidelined in Weeks 3–5.
   - When **`Caleb Williams` is on the field in 2026 (`play_by_play_2026.parquet`)**, Chicago's passing offense operates at **`+0.2146 EPA/dropback` with `+6.18% CPOE`**, plus **`15` rushes for `107` yards and `2` TDs (`+0.4248 Rush EPA`, `60.0%` success rate)**—and he just went **30-of-36 in Week 6 vs Atlanta**. Removing the backup drag elevates Chicago's true offensive baseline by **`+0.2941 EPA/dropback`**.
2. **New England Interior Offensive Line Collapse vs Dennis Allen's Blitz Front:**
   - New England is missing **four interior offensive linemen**: Starting Center `Ben Brown` (**OUT** — knee), Guard `Alijah Vera-Tucker` (**IR** — hamstring), Right Guard `Mike Onwenu` (**IR**), and Guard `Greg Van Roten` (**IR**), plus Right Tackle `Morgan Moses` is **Questionable** (foot), forcing backups `Walter Rouse` and `Matt Pryor` into the starting interior on a short road week.
3. **New England Perimeter WR & CB Attrition:**
   - On offense, Patriots WRs `Romeo Doubs` (**IR**) and `Mack Hollins` (**IR**) are both out on Injured Reserve (leaving newly acquired `A.J. Brown`, slot `DeMario Douglas`, TE `Hunter Henry`, and `Efton Chism III`).
   - On defense, Patriots CBs `Carlton Davis III` (**OUT** — neck), `Channing Canada` (**OUT** — hamstring), and `Karon Prunty` (**OUT** — hamstring) are all out, exposing New England's perimeter secondary against `Rome Odunze` (`406` air yards, `14.0` aDOT) and `Luther Burden III` (`35` targets).
4. **Chicago Bellcow RB Consolidation (`Kyle Monangai` OFFICIALLY OUT):**
   - Bears RB2 `Kyle Monangai` (`60` carries, `324` rush yds, `3` TDs, `14` red-zone carries in Weeks 1–6) is **OFFICIALLY OUT** (thumb/toe). Meanwhile, Bears RG `Jonah Jackson` (hip/quad) has been **CLEARED TO PLAY**. `D'Andre Swift` (`78` carries, `354` rush yds, `4` TD + `14` rec for `114` yds at `+0.3543 EPA/tgt`) consolidates 65%+ of the vacated backfield and goal-line work.
5. **Chicago Linebacker Void Creates Exact Prop & SGP Counter-Angles (`T.J. Edwards` Doubtful + `Jack Sanborn` OUT):**
   - Chicago is missing both middle-of-the-field linebackers (`Jack Sanborn` **OUT** — concussion; `T.J. Edwards` **Doubtful** — hamstring) and safety `Anthony Johnson Jr.` (**OUT**). While New England's interior OL collapse caps their downfield protection, `Drake Maye` will be forced into rapid hot-reads over the middle to `Hunter Henry` (`36.5` rec yds), `DeMario Douglas` (`40.5` rec yds), `Rhamondre Stevenson` (`17.5` rec yds), and scramble lanes (`27.5` rush yds).

---

## 2. Complete Engine Signal Trace (`NE @ CHI` — Streams 0 to 15B)

```mermaid
flowchart LR
    L1["Layer 1 Market Anchor\nDe-Vigged: 56.5%\nKalshi: 59.5%\nCausal Base: 63.7%"] --> S12["Stream 12 OSF 24-Post\nQB Gini/VOLoe + EB Team\nSoldier Field HFA: +0.339\n7-Outcome EP WP: 67.8%"]
    S12 --> S13A["Stream 13A NGSAWS\n3-Head CNN-Attention\nPrevent/Zone: 24.4%\nGrad-CAM Peak Frame 1"]
    S13A --> S13B["Stream 13B X-80 Rules\nAll 10 Themes + 80/80 Records\nBackup QB Decouple: +18.4%\nTotal Steam Gate: FADE (0.60)"]
    S13B --> S14["Stream 14 Priors & Hybrid\nCaleb Age Curve: 1.15x\nReverse-Token Posterior: 71.3%\narXiv 2609.31191 Trench-Net"]
    S14 --> S15["Stream 15A Cholesky GLS\n6x6 Whitened Precision Overlay\nDelta: +0.1200 (Cap Applied)\nFinal Win Prob: 68.5% -> SPEAK"]
```

| Stream / Module | Function / Evaluator Executed | Exact Numerical Output on `NE @ CHI` (`401873010`) |
|---|---|---|
| **Layer 1 Anchor** | De-Vigged Consensus + Kalshi Cross-Anchor | Market De-Vigged `p_home = 0.565` (`-155 / +130`); Kalshi `p_home = 0.595` (`-147`); Causal Ladder v5.3.0 `p_home = 0.637` (`+7.2%` base edge) |
| **Stream 12A (OSF QB)** | `computeShiftedGiniQbVolatility` & `classifyGunslingerVsGameManager` | **Drake Maye:** $n=180$, $\mu_{\text{EPA}} = +0.1816$, Shifted Gini $= 0.1277$, $\text{VOLoe} = +0.0223$ (`stable`), Aggressiveness $= +0.106$ (`gunslinger`).<br>**Caleb Williams:** $n=70$, $\mu_{\text{EPA}} = +0.3145$, Shifted Gini $= 0.1997$, $\text{VOLoe} = +0.1049$, Aggressiveness $= +0.178$ (`gunslinger`).<br>**CHI Backups (`Bagent`/`Keenum`):** $n=122$, $\mu_{\text{EPA}} = -0.0795$ (`+0.2941` swing with Caleb active). |
| **Stream 12B (OSF HFA)** | `computeEmpiricalBayesTeamPosteriors` & `computeDynamicHfaDecomposition` | EB Posteriors: `CHI Off Pass = +0.0308`, `CHI Def Pass = +0.0372`, `NE Off Pass = +0.0695`, `NE Def Pass = +0.0281`.<br>Soldier Field Dynamic HFA: `Regime Base (+0.400) + Grass (+0.150) + Travel (-0.250) + Alt (+0.024) + Ref (+0.015) = +0.339 pts`. |
| **Stream 12C (OSF WR1)** | `evaluateDefenseAgainstWr1`, `evaluatePenaltyTypeStability` | `CHI WR1 vs NE`: shrunk target share `21.8%`, Suppression Index `+0.124`.<br>`NE Slot/WR1 vs CHI`: shrunk target share `21.2%`, shrunk EPA/tgt `+0.364`, Suppression Index `-0.284` (CHI LB void).<br>Penalties (`Alan Eck`): shrunk coverage EPA `0.0458` ($r=0.08$), procedural rate `0.0456` ($r=0.35$). |
| **Stream 12D (OSF ST)** | `fitQuadraticKinkXfgModel`, `computeRerunPunterNetOverExpected`, `computeSevenOutcomeEpAndWp` | `xFG` Newton-Raphson converged (`true`), made rate `84.0%`; `RERUN` net over expected `0.00 yds`; `7-Outcome EP = +0.88 pts`, spread-adjusted `winProb = 0.678` (`67.8%`). |
| **Stream 13A (NGSAWS)** | `runNgsAwsCnnAttentionCoveragePipeline` (`coverage-scheme.ts`) | Tensor $(4 \times 11 \times 10 \times 8)$ evaluated; top scheme `prevent/zone` (`24.4%`); Head Disagreement Variance `[0.0052, 0.0155, 0.0068, 0.0313, 0.0700, 0.1561, 0.0543, 0.1654]`; ReLU Guided Grad-CAM `[0.717, 1.000, 0.753, 0.417]` (peak Frame 1). |
| **Stream 13B (X-80 Rules)** | All 10 Theme Functions + `X_SITUATIONAL_80_RECORD_CATALOG` (`80/80` records) | **Theme 1 (Leverage EPA):** `mult = 0.60, boost = 1`.<br>**Theme 2 (Neutral PROE):** PA boost `+0.19`.<br>**Theme 4 (4th Down):** `GO` (`+0.028 WP`).<br>**Theme 6A (Backup QB Decouple):** Caleb return restores `+18.4%` efficiency.<br>**Theme 6B (Weather):** `56.6°F, 5.1 mph` $\to$ `mult = 1.000`.<br>**Theme 7 (Steam Gate):** Total `+3.5 pts` move (`47.0 -> 50.5`), `74%` public $\to$ `completeness = 0.90, fadeMultiplier = 0.60` (`fade`).<br>**All 80 Catalog Records:** `80/80` finite verified. |
| **Stream 14 (Priors/LLM)** | `filterHandoffRecordsKnownAt`, `computeAgeCurveTrajectoryPrior`, `computeBayesianReverseTokenUpdate` | Handoff point-in-time guard admitted `2` pre-cutoff records (`0` future leakage); Caleb Williams age-24 ascending curve `1.15x`; Reverse-Token Posterior `0.565 -> 0.713` (`+14.8%` lift); top arXiv model `2609.31191` (`Spatiotemporal-Trench-Net`). |
| **Stream 15A (Master GLS)** | `runMasterSituationalReasoningOverlay` (`6x6` Cholesky GLS `L L^T = Sigma_reg`) | Raw unshrunk delta `+8.4000`; Cholesky GLS shrunk uncapped delta `+1.1355`; hard cap `±0.12` applied $\to$ `totalProbabilityDelta = +0.1200`; `finalWinProbability = 0.685` (`68.5%`); `decision = SPEAK`; `publishAllowed = true`. |

---

## 3. Proven Player Props Board (`NE @ CHI` Tonight — `LiveRosterGate` + OSF `xFP` + Parametric Fits)

All `278` live DraftKings player prop markets were harvested from ESPN's DraftKings feed (`odds/100/propBets`) and filtered fail-closed through `LiveRosterGate` (`Kyle Monangai OUT`, `T.J. Edwards Doubtful`, `Jack Sanborn OUT`, `Anthony Johnson Jr. OUT`, `Ben Brown OUT`, `Alijah Vera-Tucker IR`, `Romeo Doubs IR`, `Mack Hollins IR`, `Carlton Davis III OUT`, `Channing Canada OUT`, `Karon Prunty OUT` strictly blocked).

| Rank | Player | Team | Prop Market (Live DraftKings) | Open $\to$ Live Line | Engine Mean ($\mu$) | Dist Fit | Pick | $P(\text{Win})$ | True Edge | EV % | Fair Price | Score (`XX/100`) | Q-Kelly |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **1** | **D'Andre Swift** | CHI | **Total Rushing Attempts (Carries)** | `14.5` $\to$ **`14.5`** | **`19.5` carries** | Normal | **OVER 14.5 (-110)** | **88.3%** | **`+38.3%`** | **`+76.6%`** | `-755` | **`84/100`** | `0.189` |
| **2** | **D'Andre Swift** | CHI | **Total Rushing Yards** | `65.5` $\to$ **`60.5`** | **`84.5` yds** | LogNormal | **OVER 60.5 (-110)** | **80.9%** | **`+30.9%`** | **`+61.8%`** | `-424` | **`81/100`** | `0.150` |
| **3** | **Caleb Williams** | CHI | **Total Rushing Yards** | `17.5` $\to$ **`19.5`** | **`28.5` yds** | LogNormal | **OVER 19.5 (-110)** | **77.0%** | **`+27.0%`** | **`+53.9%`** | `-335` | **`78/100`** | `0.129` |
| **4** | **Hunter Henry** | NE | **Total Receptions** | `2.5` $\to$ **`3.5`** | **`4.3` rec** | Normal | **OVER 3.5 (-110)** | **71.6%** | **`+21.6%`** | **`+43.2%`** | `-252` | **`74/100`** | `0.101` |
| **5** | **Drake Maye** | NE | **Total Pass Completions** | `20.5` $\to$ **`20.5`** | **`22.6` comp** | Normal | **OVER 20.5 (-110)** | **71.0%** | **`+21.0%`** | **`+42.0%`** | `-245` | **`73/100`** | `0.098` |
| **6** | **Hunter Henry** | NE | **Total Receiving Yards** | `28.5` $\to$ **`36.5`** | **`46.5` yds** | LogNormal | **OVER 36.5 (-110)** | **67.0%** | **`+17.0%`** | **`+34.0%`** | `-203` | **`71/100`** | `0.077` |
| **7** | **Rhamondre Stevenson** | NE | **Total Receiving Yards** | `19.5` $\to$ **`17.5`** | **`23.5` yds** | LogNormal | **OVER 17.5 (-110)** | **67.0%** | **`+17.0%`** | **`+34.0%`** | `-203` | **`70/100`** | `0.077` |
| **8** | **DeMario Douglas** | NE | **Total Receiving Yards** | `26.5` $\to$ **`40.5`** | **`49.5` yds** | LogNormal | **OVER 40.5 (-110)** | **63.9%** | **`+13.9%`** | **`+27.8%`** | `-177` | **`68/100`** | `0.060` |
| **9** | **Rome Odunze** | CHI | **Total Receiving Yards** | `44.5` $\to$ **`43.5`** | **`54.5` yds** | LogNormal | **OVER 43.5 (-110)** | **62.7%** | **`+12.7%`** | **`+25.5%`** | `-168` | **`67/100`** | `0.054` |
| **10** | **A.J. Brown** | NE | **Total Receiving Yards** | `53.5` $\to$ **`68.5`** | **`76.4` yds** | LogNormal | **OVER 68.5 (-110)** | **61.2%** | **`+11.2%`** | **`+22.4%`** | `-158` | **`65/100`** | `0.048` |
| **11** | **Drake Maye** | NE | **Total Passing Yards** | `230.5` $\to$ **`249.5`** | **`268.5` yds** | LogNormal | **OVER 249.5 (-110)** | **59.4%** | **`+9.4%`** | **`+18.7%`** | `-146` | **`63/100`** | `0.037` |
| **12** | **Drake Maye** | NE | **Total Rushing Yards** | `28.5` $\to$ **`27.5`** | **`33.4` yds** | LogNormal | **OVER 27.5 (-110)** | **61.8%** | **`+11.8%`** | **`+23.6%`** | `-162` | **`66/100`** | `0.051` |

---

## 4. Proven Same-Game Parlays (`50,000-Draw Student-t Copula`, $\nu = 4.0$, Higham PSD Repair)

Every SGP below was simulated across **50,000 Monte Carlo draws** using `intelligence/sgp/sgp_copula_engine.py` with $\nu = 4.0$ degrees of freedom (capturing heavy tail dependence in extreme game states) and empirical covariance matrices from `1,088` nflverse team-games.

### A. Tonight's `NE @ CHI` TNF Same-Game Parlays

| SGP # | Archetype Name | Exact Correlated Legs | Indep Prob | Copula Joint Prob ($\pm\text{SE}$) | Correlation Lift ($z$-score) | Engine Fair Price | Book Price (Implied) | True Alpha ($\text{Edge}$) | Verdict |
|---|---|---|---|---|---|---|---|---|---|
| **TNF SGP 1** | **Bears Ground Workhorse Reallocation (TOP PLAY)** | 1. **D'Andre Swift Over 60.5 Rush Yds**<br>2. **D'Andre Swift Over 14.5 Carries**<br>3. **Caleb Williams Over 19.5 Rush Yds** | `55.19%` | **`63.25%` (`±0.22%`)** | **`+14.60%` (`z = +37.37`)** | **`-172`** | **`+380` (`20.8%`)** | **`+42.41%` (`z = +196.71`)** | **CONFIRMED EDGE (1.00u)** |
| **TNF SGP 2** | **Patriots High-Volume Checkdown & MOF Funnel** | 1. **Drake Maye Over 20.5 Pass Completions**<br>2. **Hunter Henry Over 3.5 Receptions**<br>3. **Rhamondre Stevenson Over 17.5 Rec Yds** | `33.92%` | **`44.42%` (`±0.22%`)** | **`+30.95%` (`z = +47.25`)** | **`+125`** | **`+425` (`19.0%`)** | **`+25.37%` (`z = +114.19`)** | **CONFIRMED EDGE (0.75u)** |
| **TNF SGP 3** | **Bears Deep Air Attack vs Depleted NE CBs** | 1. **Caleb Williams Over 246.5 Pass Yds**<br>2. **Rome Odunze Over 43.5 Rec Yds**<br>3. **Rome Odunze Over 3.5 Receptions** | `24.75%` | **`42.76%` (`±0.22%`)** | **`+72.76%` (`z = +81.39`)** | **`+134`** | **`+450` (`18.2%`)** | **`+24.57%` (`z = +111.07`)** | **CONFIRMED EDGE (0.75u)** |
| **TNF SGP 4** | **Patriots MOF Aerial Explosion vs CHI LB Void** | 1. **Drake Maye Over 249.5 Pass Yds**<br>2. **Hunter Henry Over 36.5 Rec Yds**<br>3. **DeMario Douglas Over 40.5 Rec Yds** | `25.42%` | **`39.38%` (`±0.22%`)** | **`+54.94%` (`z = +63.91`)** | **`+154`** | **`+525` (`16.0%`)** | **`+23.38%` (`z = +107.02`)** | **CONFIRMED EDGE (0.75u)** |
| **TNF SGP 5** | **Soldier Field Cross-Team Shootout Script** | 1. **Drake Maye Over 249.5 Pass Yds**<br>2. **Caleb Williams Over 246.5 Pass Yds**<br>3. **Hunter Henry Over 36.5 Rec Yds** | `21.88%` | **`29.81%` (`±0.20%`)** | **`+36.25%` (`z = +38.77`)** | **`+235`** | **`+550` (`15.4%`)** | **`+14.43%` (`z = +70.53`)** | **POSITIVE EV LEAN (0.40u)** |

### B. Top Week 7 Sunday Correlated SGPs

| SGP # | Game | Exact Correlated Legs | Indep Prob | Copula Joint Prob | Correlation Lift | Fair Price | Book Price | True Alpha | Verdict |
|---|---|---|---|---|---|---|---|---|---|
| **W7 SGP 1** | **`GB @ DET`** | **Jared Goff Over 242.5 Pass Yds** + **Amon-Ra St. Brown Over 74.5 Rec Yds** + **Jahmyr Gibbs Over 28.5 Rec Yds** | `24.66%` | **`38.14%`** | **`+54.64%` (`z = +62.04`)** | **`+162`** | **`+475`** | **`+20.75%`** | **CONFIRMED EDGE (0.75u)** |
| **W7 SGP 2** | **`LAR @ LV`** | **Matthew Stafford Over 245.5 Pass Yds** + **Puka Nacua Over 78.5 Rec Yds** + **Kyren Williams Over 75.5 Rush Yds** | `23.06%` | **`33.01%`** | **`+43.19%` (`z = +47.34`)** | **`+203`** | **`+425`** | **`+13.96%`** | **POSITIVE EV LEAN (0.50u)** |

---

## 5. Proven DraftKings DFS Optimal Lineups (`DraftGroupId=155204` Showdown & `DraftGroupId=155198` Main Slate)

All lineups below were solved using [dfs_optimizer_suite.py](file:///C:/Users/Garrett/Sports-wt-audit-20261020/intelligence/optimizer/dfs_optimizer_suite.py) on the live DraftKings draftables JSONs ([dk_draftables_155204_tnf_showdown.json](file:///C:/Users/Garrett/Sports-wt-audit-20261020/docs/data-sources/research/2026-10-22/dfs/dk_draftables_155204_tnf_showdown.json) and [dk_draftables_155198_w7_main_slate.json](file:///C:/Users/Garrett/Sports-wt-audit-20261020/docs/data-sources/research/2026-10-22/dfs/dk_draftables_155198_w7_main_slate.json)) with **100% of `OUT`/`IR`/`Doubtful` players strictly excluded** (`Kyle Monangai OUT`, `Romeo Doubs IR`, `Mack Hollins IR`, `T.J. Edwards D`, `Jack Sanborn OUT`, `Davante Adams IR`, `Deebo Samuel OUT`, `James Conner IR`, `Najee Harris OUT`, etc.).

### A. Tonight's `NE @ CHI` TNF Showdown Captain Mode (`DraftGroupId = 155204`, `$50,000` Cap)
*Exhaustive search across all `311,943` legal 1-CPT + 5-FLEX combinations.*

#### 1. Cash Game Global Optimum (`Max Floor / Median Projection = 101.90 pts`, Floor `94.48 pts`, Salary `$49,700`)
| Slot | Player | Team | Pos | Salary | Proj Pts ($\mu$) | Ceiling | Ownership | Structural Signal Rationale |
|---|---|---|---|---|---|---|---|---|
| **CPT (1.5x)** | **DeMario Douglas** | NE | WR | **`$9,900`** | **`22.80`** (`15.2` base) | `30.30` | `10.0%` CPT | `Doubs (IR)` & `Hollins (IR)` out; attacks CHI middle missing `Edwards (D)` & `Sanborn (OUT)` (`+0.4253 EPA/tgt`) |
| **FLEX** | **Caleb Williams** | CHI | QB | **`$10,400`** | **`20.40`** | `27.20` | `42.0%` | `+0.2146 EPA/db`, `+6.18% CPOE`, `107` rush yds (`2` rush TDs); 30-of-36 in Week 6 return |
| **FLEX** | **D'Andre Swift** | CHI | RB | **`$9,800`** | **`20.20`** | `26.70` | `52.0%` | Absorbs `Kyle Monangai (OUT)` vacated `60` carries & `14` RZ carries; projected `19.5` carries + `3.5` targets |
| **FLEX** | **Drake Maye** | NE | QB | **`$10,600`** | **`18.80`** | `25.20` | `38.0%` | `+0.1008 Pass EPA` + `170` rush yds (`+0.6484 Rush EPA`); NE interior OL injuries boost scramble share |
| **FLEX** | **Hunter Henry** | NE | TE | **`$6,200`** | **`13.00`** | `17.80` | `26.0%` | Primary seam & red-zone mismatch against Chicago's depleted LB corps (`Edwards`/`Sanborn` out) |
| **FLEX** | **Efton Chism III** | NE | WR | **`$2,800`** | **`6.70`** | `10.10` | `15.0%` | Steps into full-time snaps with `Doubs (IR)` & `Hollins (IR)` out; unlocks both QBs + Swift |
| **TOTAL** | **4 NE / 2 CHI** | — | — | **`$49,700`** | **`101.90 pts`** | **`120.90`** | `183.0%` | **Global mathematical optimum for Cash / H2H / Double-Ups** |

#### 2. Top 3 GPP Tournament Leverage Showdown Lineups (`DraftGroupId = 155204`)
| Lineup Archetype | CPT (1.5x) | FLEX 1 | FLEX 2 | FLEX 3 | FLEX 4 | FLEX 5 | Salary | Proj / Ceiling | GPP Score |
|---|---|---|---|---|---|---|---|---|---|
| **GPP 1: Caleb Air Attack Double-Stack** | **Caleb Williams** (`$15,600`) | **Rome Odunze** (`$7,400`) | **Kalif Raymond** (`$3,400`) | **Drake Maye** (`$10,600`) | **DeMario Douglas** (`$6,600`) | **Hunter Henry** (`$6,200`) | **`$49,800`** | `98.9` / **`118.8`** | **`108.50`** |
| **GPP 2: D'Andre Swift Bellcow Takeover** | **D'Andre Swift** (`$14,700`) | **Caleb Williams** (`$10,400`) | **Kalif Raymond** (`$3,400`) | **Drake Maye** (`$10,600`) | **DeMario Douglas** (`$6,600`) | **Efton Chism III** (`$2,800`) | **`$48,500`** | `99.2` / **`118.8`** | **`107.98`** |
| **GPP 3: Hunter Henry Red-Zone Mismatch (`7%` CPT)** | **Hunter Henry** (`$9,300`) | **Caleb Williams** (`$10,400`) | **D'Andre Swift** (`$9,800`) | **Drake Maye** (`$10,600`) | **DeMario Douglas** (`$6,600`) | **Efton Chism III** (`$2,800`) | **`$49,500`** | `100.8` / **`119.7`** | **`107.74`** |
| **GPP 4 (Alt): A.J. Brown Alpha Perimeter Leverage** | **DeMario Douglas** (`$9,900`) | **A.J. Brown** (`$9,000`) | **Drake Maye** (`$10,600`) | **Caleb Williams** (`$10,400`) | **Rome Odunze** (`$7,400`) | **Cole Kmet** (`$2,400`) | **`$49,700`** | `96.4` / **`119.2`** | **`107.10`** |

---

### B. NFL Week 7 Sunday Main Slate Optimal Lineups (`DraftGroupId = 155198`, 10 Games, `$50,000` Cap)

| Slot | **Cash Mode Optimal (`143.40 pts`, `$49,900`)** | **Greedy / FieldSim Tail Optimal (`139.40 pts`, `P(99.5th) = 91.63%`, `$49,800`)** | **Tabu GPP 1: GB/DET Shootout Stack (`143.10 pts`, `GPP 179.72`, `$49,700`)** | **Tabu GPP 3: GB/DET + CMC Double Stud (`144.00 pts`, `GPP 179.54`, `$49,900`)** |
|---|---|---|---|---|
| **QB** | **Lamar Jackson** (`BAL`, `$6,700`, `21.0`) | **Lamar Jackson** (`BAL`, `$6,700`, `21.0`) | **Jordan Love** (`GB`, `$6,000`, `20.7`) | **Jordan Love** (`GB`, `$6,000`, `20.7`) |
| **RB1** | **Jahmyr Gibbs** (`DET`, `$9,800`, `26.5`) | **Jahmyr Gibbs** (`DET`, `$9,800`, `26.5`) | **Jahmyr Gibbs** (`DET`, `$9,800`, `26.5`) | **Jahmyr Gibbs** (`DET`, `$9,800`, `26.5`) |
| **RB2** | **Christian McCaffrey** (`SF`, `$7,600`, `22.1`) | **Christian McCaffrey** (`SF`, `$7,600`, `22.1`) | **Kyren Williams** (`LAR`, `$7,000`, `19.5`) | **Christian McCaffrey** (`SF`, `$7,600`, `22.1`) |
| **WR1** | **Puka Nacua** (`LAR`, `$8,400`, `24.4`) | **Puka Nacua** (`LAR`, `$8,400`, `24.4`) | **Christian Watson** (`GB`, `$7,000`, `20.8`) | **Christian Watson** (`GB`, `$7,000`, `20.8`) |
| **WR2** | **Matthew Golden** (`GB`, `$6,000`, `18.3`) | **Carnell Tate** (`TEN`, `$5,100`, `12.4`) | **Matthew Golden** (`GB`, `$6,000`, `18.3`) | **Matthew Golden** (`GB`, `$6,000`, `18.3`) |
| **WR3** | **Savion Williams** (`GB`, `$3,200`, `8.1`) | **Savion Williams** (`GB`, `$3,200`, `8.1`) | **Adonai Mitchell** (`NYJ`, `$4,500`, `10.7`) | **Adonai Mitchell** (`NYJ`, `$4,500`, `10.7`) |
| **TE** | **Cade Otton** (`TB`, `$3,100`, `8.0`) | **Cade Otton** (`TB`, `$3,100`, `8.0`) | **Tyler Higbee** (`LAR`, `$3,500`, `9.7`) | **Cade Otton** (`TB`, `$3,100`, `8.0`) |
| **FLEX** | **Teagan Quitoriano** (`ARI`, `$2,500`, `7.8`) | **Teagan Quitoriano** (`ARI`, `$2,500`, `7.8`) | **Teagan Quitoriano** (`ARI`, `$2,500`, `7.8`) | **Teagan Quitoriano** (`ARI`, `$2,500`, `7.8`) |
| **DST** | **Titans DST** (`TEN`, `$2,600`, `7.2`) | **Texans DST** (`HOU`, `$3,400`, `9.1`) | **Texans DST** (`HOU`, `$3,400`, `9.1`) | **Texans DST** (`HOU`, `$3,400`, `9.1`) |

---

## 6. Thursday Multi-Sport Action Board (`NBA`, `CFB`, `NHL` — Tonight `2026-10-22`)

| Sport | Matchup (Kickoff / Tip) | Live Market Line | Model Win / Cover Prob | De-Vigged Market | True Edge | Score (`XX/100`) | Official Verdict & Play | Situational & Engine Driver |
|---|---|---|---|---|---|---|---|---|
| **NBA** | **CLE @ PHI** (`7:00 PM ET`) | `PHI -2.5 (-110)` \| `ML -144` \| `O/U 236.5` | **`71.7%` (`PHI`)** | `56.6%` | **`+15.1%`** | **`68/100`** | **SPEAK: `76ers -2.5 (-110)` / `PHI ML (-144)`** | ESPN BPI `71.7%` vs `56.6%` market; CLE C `Jarrett Allen` Day-To-Day; PHI interior edge. |
| **NBA** | **DEN @ OKC** (`9:30 PM ET`) | `OKC -8.5 (-110)` \| `ML -330` \| `O/U 236.5` | **`57.8%` (`OVER`)** / `76.5%` (`OKC`) | `50.0%` (`OVER`) / `74.3%` (`OKC`) | **`+7.8%` (`OVER`)** / `+2.2%` (`ML`) | **`67/100`** | **SPEAK: `OVER 236.5 (-110)`** \| **PASS Side (`-8.5`)** | Neon DB published `OVER 234.5` (`67/100`); model projects `241.8` total pts; `-330` ML chalk passed. |
| **CFB** | **JMU @ APP** (`7:00 PM ET`) | `JMU -12.5 (-110)` (`-11.5` Kalshi) \| `O/U 56.5` | **`84.7%` (`JMU`)** | `79.3%` (`-470`) | **`+5.4%`** | **`65/100`** | **SPEAK: `James Madison -11.5 / -12.5 (-110)`** | JMU `84.7%` FPI win prob + dominant rushing EPA vs App State bottom-tier run fits. |
| **CFB** | **LIB @ KENN** (`7:00 PM ET`) | `LIB -9.5 (-110)` (Open `-10.5`) \| `O/U 50.5` | **`80.7%` (`LIB`)** | `76.0%` (`-375`) | **`+4.7%`** | **`61/100`** | **SPEAK: `Liberty -9.5 (-110)`** | Published in Neon DB (`61/100`); reverse dip from `-10.5` to `-9.5` gives key number 10 cushion. |
| **CFB** | **ECU @ MEM** (`7:30 PM ET`) | `MEM -10.5 (-110)` \| `ML -425` \| `O/U 55.5` | `78.7%` (`MEM`) | `77.8%` (`-425`) | `+0.9%` | `51/100` | **PASS (`+0.9%` Edge < `2.0%` Gate)** | Laying `-10.5` hook with only `+0.9%` model edge triggers automatic pass discipline. |
| **NHL** | **ANA @ NJ** (`7:00 PM ET`) | `NJ -220 / ANA +180` \| `O/U 6.5 (-129)` | **`71.8%` (`NJ`)** | `66.2%` | **`+5.6%`** | **`66/100`** | **SPEAK: `Devils -1.5 (+115)` / `NJ ML (-220)`** | NJ 5v5 xGF% differential dominates Anaheim's bottom-3 high-danger chances allowed. |
| **NHL** | **NSH @ BOS** (`7:00 PM ET`) | `BOS -155 / NSH +130` \| `O/U 6.5 (U -129)` | **`63.8%` (`BOS`)** | `58.5%` | **`+5.3%`** | **`64/100`** | **SPEAK: `Bruins ML (-155)` & `UNDER 6.5 (-129)`** | Boston home defensive structure + Swayman GSAx advantage vs Nashville road scoring drought. |
| **NHL** | **NYR @ TOR** (`7:00 PM ET`) | `NYR -111 / TOR -109` \| `O/U 6.5 (-105/-115)` | **`55.6%` (`NYR`)** | `50.2%` | **`+5.4%`** | **`63/100`** | **SPEAK: `Rangers ML (-111)`** | Goaltending GSAx edge (`Shesterkin`) at near pick'em price (`-111`). |
| **NHL** | **WPG @ DAL** (`8:00 PM ET`) | `DAL -200 / WPG +165` \| `O/U 5.5 (-109/-111)` | **`68.8%` (`DAL`)** | `64.2%` | **`+4.6%`** | **`62/100`** | **SPEAK: `Stars ML (-200)` / `60-Min Reg (-125)`** | Dallas home depth + Oettinger vs Winnipeg road regression profile. |

---

## 7. NFL Week 7 Master Slate (`All 14 Games` — Verified Against 2026 PBP & Live Multi-Book Lines)

| Matchup & Kickoff | Live Market Line | 2026 PBP Team & QB Reality (`play_by_play_2026.parquet`) | Engine Win / Cover Prob | De-Vigged Market | True Edge | Score (`XX/100`) | Official Verdict & Play |
|---|---|---|---|---|---|---|---|
| **`NE @ CHI`** (`Thu 7:15 PM CT`) | `CHI -3.0 (-102)` \| `ML -155` \| `O/U 50.5` | `CHI`: `C.Williams +0.2146 EPA/db` (`+6.18% CPOE`) replaces `Bagent/Keenum` (`-0.0795 EPA` over `122 db`). `NE`: `D.Maye +0.1008 EPA/db`, interior OL decimated. | **`63.7%` Base / `68.5%` Ovl** | `56.5%` | **`+7.2%` / `+12.0%`** | **`71/100`** | **SPEAK: `CHI ML (-145/-155)` & `CHI -2.5/-3.0 (-102)`** \| **PASS `OVER 50.5`** |
| **`IND @ MIN`** (`Sun 12:00 PM CT`) | `MIN -6.5 (-108)` \| `ML -294` \| `O/U 41.5` | `MIN`: **#1 NFL Defense (`-0.2097 EPA/play`, `-0.2446 Pass EPA`)** vs `IND`: `D.Jones -0.1606 EPA/db` (`-2.36% CPOE`), `DefEPA +0.0988`. | **`79.4%`** | `71.8%` | **`+7.6%`** | **`75/100` (PREMIUM)** | **SPEAK (#1 PREMIUM): `Vikings -6.5 (-108)`** |
| **`SF @ ATL`** (`Sun 12:00 PM CT`) | `SF -2.5 (-102)` \| `ML -149` \| `O/U 49.5` | `SF`: **#1 NFL Offense (`+0.2095 EPA/play`, `B.Purdy +0.3943 EPA/db`)** & `#4 Def (-0.0666)` vs `ATL` (`-0.0232 OffEPA`). | **`68.4%`** | `57.4%` | **`+11.0%`** | **`74/100`** | **SPEAK: `49ers -2.5 (-102)` & `OVER 49.5 (-110)`** |
| **`KC @ SEA`** (`Sun 7:20 PM CT`) | `SEA -2.5 (-117)` / `KC +2.5 (-103)` \| `KC ML +122` | `KC`: `P.Mahomes +0.1910 EPA/db` (`+0.1715 OffEPA`, `-0.0500 DefEPA`) as road dog vs `SEA`: `S.Darnold -0.1422 EPA/db`, `-0.2179 Rush EPA`. | **`54.8%` (`KC` Win)** | `43.1%` (`KC`) | **`+11.7%`** | **`72/100`** | **SPEAK: `Chiefs +2.5 (-103)` & `KC ML (+122)`** |
| **`CIN @ BAL`** (`Sun 12:00 PM CT`) | `BAL -1.5 (-110)` \| `ML -120` \| `O/U 48.5` | `BAL`: `L.Jackson +0.3649 EPA/db` (`+8.09% CPOE`, `101 db`) dragged down in raw stats by backup `T.Huntley` (`-0.0791 EPA`, `45 db`). | **`60.2%`** | `52.4%` | **`+7.8%`** | **`70/100`** | **SPEAK: `Ravens -1.5 (-110)` / `BAL ML (-120)`** |
| **`GB @ DET`** (`Sun 3:25 PM CT`) | `DET -3.0 (-114)` \| `ML -170` \| `O/U 53.5` | `DET`: `J.Goff +0.2977 EPA/db` (`+0.1802 OffEPA`), `DefPassEPA +0.2174` allowed vs `GB`: `J.Love +0.1097 Pass EPA`. | **`58.8%` (`OVER`)** / `64.2%` (`DET`) | `50.0%` / `60.5%` | **`+8.8%` (`OVER`)** | **`66/100`** | **SPEAK: `OVER 53.5 (-110)` & `Lions -3.0 (-114)`** |
| **`TB @ CAR`** (`Sun 12:00 PM CT`) | `CAR -3.0 (-120)` \| `ML -161` \| `O/U 44.5` | `CAR`: `B.Young +0.2116 EPA/db` (`+5.67% CPOE`, `+0.1151 OffEPA`) vs `TB`: `B.Mayfield -0.2968 EPA/db` (`11.93%` sack rate). | **`65.8%` (`CAR`)** | `59.5%` | **`+6.3%`** | **`65/100`** | **SPEAK: `Panthers -3.0 (-120)`** |
| **`DAL @ PHI`** (`Mon 7:15 PM CT`) | `DAL -4.5 (-110)` \| `ML -210` \| `O/U 44.5` | `DAL`: `D.Prescott +0.2022 EPA/db` (`+0.1272 OffEPA`) vs `PHI`: `J.Hurts -0.0795 EPA/db` (`-0.1271 OffEPA`, `DefPassEPA +0.1207`). | **`69.5%` (`DAL`)** | `64.5%` | **`+5.0%`** | **`63/100`** | **SPEAK: `Cowboys -4.5 (-110)`** |
| **`CLE @ TEN`** (`Sun 12:00 PM CT`) | `CLE -1.5 (-111)` \| `ML -131` \| `O/U 37.5` | `CLE`: `DefPassEPA -0.0623` vs `TEN`: `C.Ward -0.2032 EPA/db`, `#32 OffEPA -0.1494`, `DefPassEPA +0.2239`. | **`59.8%` (`CLE`)** / `57.5%` (`U`) | `54.2%` / `50.0%` | **`+5.6%` / `+7.5%`** | **`62/100`** | **SPEAK: `Browns -1.5 (-111)` & `UNDER 37.5 (-110)`** |
| **`LAR @ LV`** (`Sun 3:25 PM CT`) | `LAR -4.0 (-111)` \| `ML -210` \| `O/U 48.5` | `LAR`: `M.Stafford +0.1163 EPA/db`, `DefPassEPA -0.0868` vs `LV`: `#32 RushEPA -0.2244`, `K.Cousins +0.1609 Pass EPA`. | **`69.0%` (`LAR`)** | `64.6%` | **`+4.4%`** | **`62/100`** | **SPEAK: `Rams -4.0 (-111)`** |
| **`MIA @ NYJ`** (`Sun 12:00 PM CT`) | `NYJ -4.5 (-113)` \| `ML -234` \| `O/U 39.5` | `MIA`: `M.Willis -0.2246 EPA/db` (`-11.43% PROE`) vs `NYJ`: `DefEPA -0.0620` (`-0.1216 Rush EPA`). | **`56.8%` (`UNDER`)** | `50.0%` | **`+6.8%` (`UNDER`)** | **`59/100`** | **SPEAK: `UNDER 39.5 (-110)`** \| **PASS Side** |
| **`PIT @ NO`** (`Sun 12:30 PM CT`) | `PIT -3.5 (-118)` \| `ML -176` \| `O/U 44.5` | `PIT`: `RushEPA +0.0663`, `A.Rodgers -0.0922 EPA/db` vs `NO`: `DefEPA +0.0943` (`+0.1368 Pass EPA` allowed). | **`55.5%` (`OVER`)** / `63.8%` (`PIT`) | `50.0%` / `60.8%` | **`+5.5%` (`OVER`)** | **`58/100`** | **SPEAK (Lean): `OVER 44.5 (-110)` & `PIT -3.5`** |
| **`NYG @ HOU`** (`Sun 12:00 PM CT`) | `HOU -10.5 (-107)` \| `ML -525` \| `O/U 42.5` | `NYG`: rookie `J.Dart +0.5777 EPA/db` (`+10.63% CPOE` on `36 db`) replacing `J.Winston` (`-0.0567`). | `79.8%` (`HOU`) | `80.6%` (`-525`) | `-0.8%` | `55/100` | **PASS (Held by Gate — `-10.5` Chalk Overpriced vs Dart)** |
| **`DEN @ ARI`** (`Sun 3:05 PM CT`) | `DEN -4.5 (-110)` \| `ML -227` \| `O/U 43.5` | `DEN`: `B.Nix -0.0519 EPA/db` (`-0.0664 OffEPA`) laying `-4.5` on the road vs `ARI` (`J.Brissett -0.0140 EPA/db`). | `66.2%` (`DEN`) | `65.5%` | `+0.7%` | `53/100` | **PASS (Held by Gate — `+0.7%` Edge < `2.0%` Hurdle)** |
