import json

path = r'C:\Users\Garrett\.gemini\antigravity-cli\brain\6ced681b-ae7a-43f2-b3bf-68bfc9e88a9a\scratch\espn_dk_props_and_neon.json'
with open(path, 'r', encoding='utf-8') as f:
    d = json.load(f)

games = d.get('neon_games', [])
print(f'neon_games total: {len(games)}')
for g in games:
    home = g.get('homeTeamName', '')
    away = g.get('awayTeamName', '')
    commence = g.get('commenceTime', '')
    if any(t in f'{home} {away}' for t in ['Bears', 'Patriots', 'CHI', 'NE']):
        print('NE/CHI Game:', g.get('id'), home, away, commence)

picks = d.get('neon_picks', [])
print(f'neon_picks total: {len(picks)}')
for p in picks[:10]:
    sel = p.get('selection', '')
    line = p.get('line', '')
    tier = p.get('tier', '')
    conf = p.get('confidence', '')
    print(f'  Pick: {sel} {line} ({tier}) conf={conf}')

sigs = d.get('neon_signals', [])
print(f'neon_signals total: {len(sigs)}')
for s in sigs[:5]:
    print('  Sig:', s.get('signalKey'), s.get('direction'), s.get('value'))
