import * as fs from "node:fs";
import * as path from "node:path";
import {
  runIntelligence,
  type GameBundle,
} from "../../apps/web/lib/intelligence-core/engine";
import {
  evaluateLbVoidTeRbVsSlotAbsorption,
  evaluateMutualDefensiveAttritionTotalOverride,
  evaluateQbKneeldownAndLeadScriptRushHaircut,
  evaluateRookieSnapAndTargetRampOverride,
  evaluatePreKickoffRealityReconciliationGate,
} from "../../packages/prediction-engine/src/nfl/x-situational-80-rules";

const now = new Date("2026-10-23T03:35:00.000Z");

// 1. Verify situational-trace.ts & reasoning.ts fixes on NE @ CHI
const chiSpreadBundle: GameBundle = {
  gameId: "nfl-2026-w7-ne-chi",
  sport: "NFL",
  selection: "Chicago Bears -2.5",
  pickType: "SPREAD",
  commenceTime: "2026-10-23T00:15:00.000Z",
  homeTeam: "Chicago Bears",
  awayTeam: "New England Patriots",
  market: {
    market: "SPREAD",
    fairProb: 0.5000,
    line: -2.5,
    bookmakerCount: 7,
    consensusPct: 0.56,
    clv: 0.018,
  },
  situation: {
    restDaysHome: 4,
    restDaysAway: 4,
    travelTimezoneShift: 1,
    weatherImpact: 0.025,
    injuryImpact: 0.045,
  },
  extraObservations: [
    {
      family: "PLAY_CHARTING",
      key: "nfl:caleb-healthy-epa-lift",
      fact: "Caleb Williams healthy return (+0.2146 EPA/db, +4.4% CPOE) vs CHI backup drag (-0.0795 EPA/db)",
      knownAt: "2026-10-22T22:00:00.000Z",
      origin: "play_by_play_2026",
      trust: 0.94,
      freshness: 0.98,
      lean: 0.48,
      rights: "cleared",
      tier: 1,
    },
    {
      family: "INJURY_AVAILABILITY",
      key: "nfl:ne-guard-attrition-short-week",
      fact: "NE missing starting guards Alijah Vera-Tucker (hamstring OUT) and Ben Brown (knee OUT) + Mike Onwenu (IR) and CB1 Carlton Davis (neck OUT) on 4-day road week",
      knownAt: "2026-10-22T22:45:00.000Z",
      origin: "nfl-official-90min-inactives",
      trust: 0.96,
      freshness: 1.0,
      lean: 0.42,
      rights: "cleared",
      tier: 1,
    },
    {
      family: "INJURY_AVAILABILITY",
      key: "nfl:chi-lb-void-counterweight",
      fact: "CHI inside LBs Jack Sanborn (OUT) and T.J. Edwards (OUT) vacate middle-of-field hook/seam zones (counter-lean)",
      knownAt: "2026-10-22T22:45:00.000Z",
      origin: "nfl-official-90min-inactives",
      trust: 0.95,
      freshness: 1.0,
      lean: -0.22, // Negative lean tests that situational-trace.ts clamps signed leans into (0,1) without crashing!
      rights: "cleared",
      tier: 1,
    },
    {
      family: "SCHEME_TENDENCY",
      key: "nfl:swift-bellcow-monangai-out",
      fact: "Kyle Monangai OUT consolidates CHI early-down and red-zone rush volume into D'Andre Swift",
      knownAt: "2026-10-22T22:45:00.000Z",
      origin: "nfl-official-90min-inactives",
      trust: 0.91,
      freshness: 0.96,
      lean: 0.35,
      rights: "cleared",
      tier: 1,
    },
  ],
  modelVersion: "v5.3.0-streams-12-15",
  statedConfidence: 66,
  grade: "SOLID_PLAY",
  now,
};

const chiSpreadIntel = runIntelligence(chiSpreadBundle);

// 2. Execute Theme 9A: LB Void TE/RB Seam vs Slot CB Absorption
const lbVoidResult = evaluateLbVoidTeRbVsSlotAbsorption({
  startingInsideLbsOut: 2, // Jack Sanborn OUT + T.J. Edwards OUT
  opposingNickelCbActive: true, // Kyler Gordon ACTIVE
  te1BaseTargetShare: 0.175, // Hunter Henry (actual: 7 TGTS / 31 = 22.6%, 7 REC, 71 YDS)
  te2BaseTargetShare: 0.065, // Eli Raridon (actual: 4 TGTS / 31 = 12.9%, 3 REC, 56 YDS, 1 TD)
  rb1BaseTargetShare: 0.115, // Rhamondre Stevenson (actual: 5 TGTS / 31 = 16.1%, 5 REC, 93 YDS, 1 TD)
  slotWrBaseTargetShare: 0.165, // DeMario Douglas (actual: 4 TGTS / 31 = 12.9%, 3 REC, 23 YDS)
});

// 3. Execute Theme 9B: Mutual Defensive Attrition + Calm Weather Total Override
const mutualAttritionTotalResult = evaluateMutualDefensiveAttritionTotalOverride({
  homeStartingLbsOut: 2, // Sanborn OUT, Edwards OUT
  awayStartingCb1Out: true, // Carlton Davis OUT (neck)
  homeEdgePrimaryPassRusherActive: false, // Montez Sweat / Gervon Dexter produced 0 stats/sacks
  temperatureF: 56.6,
  windMph: 5.1,
  baseProjectedTotal: 48.5,
});

// 4. Execute Theme 9C: QB Kneeldown & Lead/Trail Script Rush Haircut
const calebRushHaircut = evaluateQbKneeldownAndLeadScriptRushHaircut({
  rawProjectedRushYards: 21.8,
  propLine: 19.5,
  teamWinProbability: 0.61, // CHI led 20-14 at half, 27-14 in Q3, closed in victory formation
  projectedPassYards: 292,  // Actual: 308 pass yds
});

const mayeRushHaircut = evaluateQbKneeldownAndLeadScriptRushHaircut({
  rawProjectedRushYards: 28.8,
  propLine: 27.5,
  teamWinProbability: 0.39, // NE trailed entire game, forced into high-volume pass script
  projectedPassYards: 295,  // Actual: 321 pass yds
});

// 5. Execute Theme 9D: Rookie Snap & Target Ramp Override
const lovelandRamp = evaluateRookieSnapAndTargetRampOverride({
  draftRound: 1,
  trailingTwoWeekRouteRate: 0.84,
  seasonPriorTargetShare: 0.145,
  veteranCoStarterLimitedOrDecoy: true, // DJ Moore 0 targets
});

const burdenRamp = evaluateRookieSnapAndTargetRampOverride({
  draftRound: 2,
  trailingTwoWeekRouteRate: 0.78,
  seasonPriorTargetShare: 0.110,
  veteranCoStarterLimitedOrDecoy: true,
});

// 6. Execute Theme 9E: Pre-Kickoff Reality Reconciliation Gate
// 6a) Feed the flawed pre-game draft state to prove the gate catches all 6 discrepancies:
const preGameDraftFailureAudit = evaluatePreKickoffRealityReconciliationGate({
  inactivesVerified90MinPreKick: false, // Claimed Bradbury/Durant/Wilson OUT when Wilson started & Vera-Tucker/Ben Brown were the actual inactives
  cardWindMph: 15.0,
  sensorWindMph: 5.1,
  cardTempF: 46.0,
  sensorTempF: 56.6,
  cardSpread: -1.5,
  liveBookSpread: -2.5,
  engineLayersUnanimous: false, // runIntelligence was WITHHOLD while stream15MasterOverlay was SPEAK
  espnScoreboardMatchupsVerified: false, // Proof JSON had ORL@ATL, LAL@GSW instead of CLE@PHI, DEN@OKC
  brandHandle: "@GalaxySportsAI",
});

// 6b) Feed the reconciled state to prove it passes cleanly when all facts match reality:
const reconciledPostFixAudit = evaluatePreKickoffRealityReconciliationGate({
  inactivesVerified90MinPreKick: true,
  cardWindMph: 5.1,
  sensorWindMph: 5.1,
  cardTempF: 56.6,
  sensorTempF: 56.6,
  cardSpread: -2.5,
  liveBookSpread: -2.5,
  engineLayersUnanimous: chiSpreadIntel.publishState === "CANDIDATE",
  espnScoreboardMatchupsVerified: true,
  brandHandle: "@GalaxySportsHQ",
});

const proof = {
  verifiedAt: now.toISOString(),
  gameActualFinal: {
    eventId: "401873010",
    matchup: "New England Patriots @ Chicago Bears",
    finalScore: "CHI 30, NE 24",
    totalPoints: 54,
    spreadOutcome: "CHI -1.5 / -2.5 / -3.0 COVERED (margin +6)",
  },
  engineFixesVerified: {
    situationalTraceFix: {
      ok: chiSpreadIntel.situationTrace?.ok,
      failReason: chiSpreadIntel.situationTrace?.failReason,
      divergence: chiSpreadIntel.situationTrace?.divergence,
      consistencyPassed: chiSpreadIntel.situationTrace?.consistencyPassed,
      activeSignalsCount: chiSpreadIntel.situationTrace?.activeSignals.length,
      dormantSignalsCount: chiSpreadIntel.situationTrace?.dormantSignals.length,
    },
    reasoningPublishStateReconciliationFix: {
      selection: chiSpreadBundle.selection,
      calibratedProb: chiSpreadIntel.calibratedProb,
      marketFairProb: chiSpreadIntel.reasoning.marketFairProb,
      edgeVsMarket: chiSpreadIntel.edgeVsMarket,
      knowability: chiSpreadIntel.knowability,
      evidenceHealth: chiSpreadIntel.evidenceHealth,
      publishState: chiSpreadIntel.publishState,
      withholdReasons: chiSpreadIntel.withholdReasons,
    },
  },
  theme9PostGameEvaluatorsProof: {
    lbVoidTeRbVsSlotAbsorption: lbVoidResult,
    mutualDefensiveAttritionTotalOverride: mutualAttritionTotalResult,
    qbKneeldownAndLeadScriptRushHaircut: {
      calebWilliams: {
        ...calebRushHaircut,
        actualRushYards: 18,
        actualCarries: 5,
        propLine: 19.5,
      },
      drakeMaye: {
        ...mayeRushHaircut,
        actualRushYards: 26,
        actualCarries: 4,
        propLine: 27.5,
      },
    },
    rookieSnapAndTargetRampOverride: {
      colstonLoveland: {
        ...lovelandRamp,
        actualStatLine: "7 REC, 69 YDS, 1 TD (12 TGTS)",
      },
      lutherBurdenIII: {
        ...burdenRamp,
        actualStatLine: "4 REC, 130 YDS, 1 TD (4 TGTS, 58 long)",
      },
    },
    preKickoffRealityReconciliationGate: {
      caughtPreGameDraftErrors: preGameDraftFailureAudit,
      reconciledCleanState: reconciledPostFixAudit,
    },
  },
};

const outDir = path.resolve(__dirname, "../../outbox");
fs.mkdirSync(outDir, { recursive: true });
const outPath = path.join(outDir, "POSTGAME-10-22-LEARNING-LOOP-PROOF.json");
fs.writeFileSync(outPath, JSON.stringify(proof, null, 2), "utf-8");
console.log("POST-GAME LEARNING LOOP VERIFICATION COMPLETE:", JSON.stringify({
  traceOk: proof.engineFixesVerified.situationalTraceFix.ok,
  traceActiveSignals: proof.engineFixesVerified.situationalTraceFix.activeSignalsCount,
  publishState: proof.engineFixesVerified.reasoningPublishStateReconciliationFix.publishState,
  lbVoidNickelSuppression: lbVoidResult.slotWrNickelSuppressionApplied,
  lbVoidCombinedTeRbShareDelta: lbVoidResult.combinedTeRbShareDelta,
  mutualAttritionOverridesUnder: mutualAttritionTotalResult.overridesOlineUnderLean,
  mutualAttritionAdjustedTotal: mutualAttritionTotalResult.adjustedProjectedTotal,
  calebAdjustedRush: calebRushHaircut.adjustedProjectedRushYards,
  calebRecommendation: calebRushHaircut.recommendation,
  mayeAdjustedRush: mayeRushHaircut.adjustedProjectedRushYards,
  mayeRecommendation: mayeRushHaircut.recommendation,
  preGameErrorsCaught: preGameDraftFailureAudit.violations.length,
  reconciledGatePass: reconciledPostFixAudit.publishAllowed,
}, null, 2));
