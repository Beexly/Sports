import json

with open(r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\dfs\dk_draftables_155198_w7_main_slate.json", encoding="utf-8") as f:
    d = json.load(f)

draftables = d.get("draftables", [])
print(f"Total draftables: {len(draftables)}")

competitions = set()
teams = set()
for p in draftables:
    teams.add(p.get("teamAbbreviation"))
    comp = p.get("competition", {}).get("name")
    if comp:
        competitions.add(comp)

print("\nCompetitions (Games) on Week 7 Main Slate (155198):")
for c in sorted(competitions):
    print(" -", c)

print(f"\nTotal Teams ({len(teams)}):", sorted([t for t in teams if t]))
