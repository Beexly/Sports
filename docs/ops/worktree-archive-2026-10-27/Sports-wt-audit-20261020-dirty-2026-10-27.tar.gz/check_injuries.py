import json
import urllib.request

req = urllib.request.Request('https://site.api.espn.com/apis/site/v2/sports/football/nfl/injuries', headers={'User-Agent': 'Mozilla/5.0'})
with urllib.request.urlopen(req, timeout=15) as resp:
    espn_data = json.loads(resp.read().decode('utf-8'))

espn_injuries = {}
for team in espn_data.get('injuries', []):
    team_name = team.get('team', {}).get('displayName', '')
    for item in team.get('injuries', []):
        ath = item.get('athlete', {})
        name = ath.get('displayName', '')
        status = item.get('status', '')
        detail = item.get('details', {}).get('type', '')
        espn_injuries[name.lower()] = {
            'name': name,
            'team': team_name,
            'status': status,
            'detail': detail,
            'desc': item.get('shortComment', '')
        }

print(f"Total ESPN injured players: {len(espn_injuries)}")

# Check key players from prompt:
test_names = [
    "Kyle Monangai", "T.J. Edwards", "Jack Sanborn", "Anthony Johnson Jr.",
    "Ben Brown", "Alijah Vera-Tucker", "Channing Canada", "Karon Prunty",
    "Drake Maye", "Caleb Williams", "D'Andre Swift", "Hunter Henry", "DeMario Douglas", "Rhamondre Stevenson",
    "Morgan Moses"
]

print("\n--- Check Test Players in ESPN Injuries ---")
for n in test_names:
    match = espn_injuries.get(n.lower())
    if match:
        print(f"MATCH: {match['name']} ({match['team']}): status={match['status']}, detail={match['detail']}, desc={match['desc']}")
    else:
        # Partial match
        found = False
        for k, v in espn_injuries.items():
            if n.lower() in k or k in n.lower():
                print(f"PARTIAL MATCH for {n}: {v['name']} ({v['team']}): status={v['status']}, detail={v['detail']}")
                found = True
        if not found:
            print(f"NOT on injury report: {n}")
