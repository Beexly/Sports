import pandas as pd
import numpy as np

pbp_path = r"C:\Users\Garrett\Sports-wt-audit-20261020\intelligence\coaching\data\play_by_play_2026.parquet"
pbp = pd.read_parquet(pbp_path)

print("Passers:")
passers = pbp.groupby("passer_player_name").agg(
    att=("pass_attempt", "sum"),
    yds=("passing_yards", "sum"),
    tds=("pass_touchdown", "sum"),
    epa=("epa", "mean")
).loc[lambda x: x.index.isin(["D.Maye", "C.Williams"])]
print(passers)

print("\nRushers:")
rushers = pbp.groupby("rusher_player_name").agg(
    carries=("rush_attempt", "sum"),
    yds=("rushing_yards", "sum"),
    tds=("rush_touchdown", "sum"),
    epa=("epa", "mean")
).loc[lambda x: x.index.isin(["D.Swift", "K.Monangai", "R.Stevenson", "C.Williams", "D.Maye", "R.Johnson"])]
print(rushers)

print("\nReceivers:")
receivers = pbp.groupby("receiver_player_name").agg(
    tgts=("pass_attempt", "count"),
    recs=("complete_pass", "sum"),
    yds=("receiving_yards", "sum"),
    tds=("pass_touchdown", "sum"),
    air_yds=("air_yards", "sum"),
    epa=("epa", "mean")
).loc[lambda x: x.index.isin(["R.Odunze", "L.Burden", "K.Raymond", "C.Loveland", "C.Kmet", "H.Henry", "D.Douglas", "D.Swift", "R.Stevenson", "R.Doubs", "M.Hollins"])]
print(receivers)
