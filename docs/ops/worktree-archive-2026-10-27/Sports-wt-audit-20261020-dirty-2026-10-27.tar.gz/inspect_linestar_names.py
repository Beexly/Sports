import pandas as pd
import re

p_line = r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\universal-agent-handoff\extracted-samples\linestar_ownership_full_282_2026-10-22.csv"
df_line = pd.read_csv(p_line)
print(df_line.head(15))
