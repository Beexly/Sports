import pandas as pd
import numpy as np

# Load 2026 PBP
df = pd.read_parquet(r"C:\Users\Garrett\Sports-wt-audit-20261020\intelligence\coaching\data\play_by_play_2026.parquet")

df_ne = df[df["posteam"] == "NE"]
df_chi = df[df["posteam"] == "CHI"]

# Red zone plays (yardline_100 <= 20)
rz_chi = df_chi[df_chi["yardline_100"] <= 20]
rz_ne = df_ne[df_ne["yardline_100"] <= 20]

print("CHI RZ rushes:", rz_chi[rz_chi["rush_attempt"] == 1]["rusher_player_name"].value_counts())
print("CHI RZ targets:", rz_chi[rz_chi["pass_attempt"] == 1]["receiver_player_name"].value_counts())

print("\nNE RZ rushes:", rz_ne[rz_ne["rush_attempt"] == 1]["rusher_player_name"].value_counts())
print("NE RZ targets:", rz_ne[rz_ne["pass_attempt"] == 1]["receiver_player_name"].value_counts())

# Air yards and EPA
print("\nCHI air yards & EPA by receiver:")
for rec, group in df_chi[df_chi["pass_attempt"] == 1].groupby("receiver_player_name"):
    if len(group) >= 5:
        print(f"{rec:<12}: targets={len(group):<2}, air_yards={group['air_yards'].sum():<5.1f}, aDOT={group['air_yards'].mean():<4.1f}, EPA={group['epa'].mean():<5.2f}")

print("\nNE air yards & EPA by receiver:")
for rec, group in df_ne[df_ne["pass_attempt"] == 1].groupby("receiver_player_name"):
    if len(group) >= 5:
        print(f"{rec:<12}: targets={len(group):<2}, air_yards={group['air_yards'].sum():<5.1f}, aDOT={group['air_yards'].mean():<4.1f}, EPA={group['epa'].mean():<5.2f}")
