import { describe, expect, it } from "vitest";
import {
  evaluateLbVoidTeRbVsSlotAbsorption,
  evaluateMutualDefensiveAttritionTotalOverride,
  evaluateQbKneeldownAndLeadScriptRushHaircut,
  evaluateRookieSnapAndTargetRampOverride,
  evaluatePreKickoffRealityReconciliationGate,
} from "../nfl/x-situational-80-rules";

describe("Theme 9: Post-Game Learning Loop & Pre-Kickoff Reality Reconciliation (2026-10-22 NE @ CHI)", () => {
  it("routes inside-LB void (Sanborn + Edwards OUT) to TE1/TE2/RB1 while suppressing Slot WR when Nickel CB is active", () => {
    const res = evaluateLbVoidTeRbVsSlotAbsorption({
      startingInsideLbsOut: 2,
      opposingNickelCbActive: true,
      te1BaseTargetShare: 0.175,
      te2BaseTargetShare: 0.065,
      rb1BaseTargetShare: 0.115,
      slotWrBaseTargetShare: 0.165,
    });
    expect(res.slotWrNickelSuppressionApplied).toBe(true);
    expect(res.te1AdjustedTargetShare).toBeGreaterThan(0.175);
    expect(res.te2AdjustedTargetShare).toBeGreaterThan(0.065);
    expect(res.rb1AdjustedTargetShare).toBeGreaterThan(0.115);
    expect(res.slotWrAdjustedTargetShare).toBeLessThan(0.165);
    expect(res.combinedTeRbShareDelta).toBeCloseTo(0.12, 4);
  });

  it("overrides O-line Under lean when mutual defensive spine attrition meets calm kicking conditions (CHI 30, NE 24 = 54)", () => {
    const res = evaluateMutualDefensiveAttritionTotalOverride({
      homeStartingLbsOut: 2,
      awayStartingCb1Out: true,
      homeEdgePrimaryPassRusherActive: false,
      temperatureF: 56.6,
      windMph: 5.1,
      baseProjectedTotal: 48.5,
    });
    expect(res.overridesOlineUnderLean).toBe(true);
    expect(res.explosivePlayPointsDelta).toBeCloseTo(4.6, 4);
    expect(res.calmWeatherExtendedFgPointsDelta).toBeCloseTo(1.5, 4);
    expect(res.adjustedProjectedTotal).toBeCloseTo(54.6, 4);
  });

  it("flags kneeldown and clean-pocket pass-first hook risk on Caleb Williams (18 vs 19.5) and Drake Maye (26 vs 27.5)", () => {
    const caleb = evaluateQbKneeldownAndLeadScriptRushHaircut({
      rawProjectedRushYards: 21.8,
      propLine: 19.5,
      teamWinProbability: 0.61,
      projectedPassYards: 292,
    });
    expect(caleb.adjustedProjectedRushYards).toBeLessThan(19.5);
    expect(caleb.hookRiskFlag).toBe(true);
    expect(caleb.recommendation).toBe("PASS_KNEELDOWN_HOOK_RISK");

    const maye = evaluateQbKneeldownAndLeadScriptRushHaircut({
      rawProjectedRushYards: 28.8,
      propLine: 27.5,
      teamWinProbability: 0.39,
      projectedPassYards: 295,
    });
    expect(maye.adjustedProjectedRushYards).toBeLessThan(27.5);
    expect(maye.hookRiskFlag).toBe(true);
    expect(maye.recommendation).toBe("PASS_KNEELDOWN_HOOK_RISK");
  });

  it("boosts Day-1/Day-2 rookies crossing 65% route ramp when veteran co-starter is decoyed (Loveland 12 TGTS, Burden 130 YDS)", () => {
    const loveland = evaluateRookieSnapAndTargetRampOverride({
      draftRound: 1,
      trailingTwoWeekRouteRate: 0.84,
      seasonPriorTargetShare: 0.145,
      veteranCoStarterLimitedOrDecoy: true,
    });
    expect(loveland.breakoutActive).toBe(true);
    expect(loveland.rampBoostDelta).toBeCloseTo(0.12, 4);
    expect(loveland.adjustedTargetShare).toBeCloseTo(0.265, 4);
  });

  it("blocks publication on all 7 pre-game discrepancies and allows publication only when 100% reconciled", () => {
    const failedDraft = evaluatePreKickoffRealityReconciliationGate({
      inactivesVerified90MinPreKick: false,
      cardWindMph: 15.0,
      sensorWindMph: 5.1,
      cardTempF: 46.0,
      sensorTempF: 56.6,
      cardSpread: -1.5,
      liveBookSpread: -2.5,
      engineLayersUnanimous: false,
      espnScoreboardMatchupsVerified: false,
      brandHandle: "@GalaxySportsAI",
    });
    expect(failedDraft.publishAllowed).toBe(false);
    expect(failedDraft.violations).toHaveLength(7);

    const cleanState = evaluatePreKickoffRealityReconciliationGate({
      inactivesVerified90MinPreKick: true,
      cardWindMph: 5.1,
      sensorWindMph: 5.1,
      cardTempF: 56.6,
      sensorTempF: 56.6,
      cardSpread: -2.5,
      liveBookSpread: -2.5,
      engineLayersUnanimous: true,
      espnScoreboardMatchupsVerified: true,
      brandHandle: "@GalaxySportsHQ",
    });
    expect(cleanState.publishAllowed).toBe(true);
    expect(cleanState.violations).toHaveLength(0);
  });
});
