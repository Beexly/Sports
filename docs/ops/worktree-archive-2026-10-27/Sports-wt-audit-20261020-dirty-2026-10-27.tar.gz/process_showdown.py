import json

with open(r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\dfs\dk_draftables_155204_tnf_showdown.json", encoding="utf-8") as f:
    d = json.load(f)

draftables = d.get("draftables", [])
flex_players = [p for p in draftables if p["rosterSlotId"] == 512]
cpt_players = {p["displayName"]: p for p in draftables if p["rosterSlotId"] == 511}

print(f"Total draftables: {len(draftables)}, Distinct players: {len(flex_players)}")
print("-" * 95)
print(f"{'Player':<22} | {'Team':<4} | {'Pos':<4} | {'FLEX $':<6} | {'CPT $':<6} | {'FPPG':<5} | {'DK Status':<10} | {'Disabled'}")
print("-" * 95)

for p in sorted(flex_players, key=lambda x: -x["salary"]):
    fppg = next((a["value"] for a in p.get("draftStatAttributes", []) if a.get("id") == 90), "0")
    status = p.get("status", "None")
    is_disabled = p.get("isDisabled", False)
    cpt = cpt_players.get(p["displayName"])
    cpt_sal = cpt["salary"] if cpt else 0
    print(f"{p['displayName']:<22} | {p['teamAbbreviation']:<4} | {p['position']:<4} | ${p['salary']:<5} | ${cpt_sal:<5} | {fppg:<5} | {status:<10} | {is_disabled}")
