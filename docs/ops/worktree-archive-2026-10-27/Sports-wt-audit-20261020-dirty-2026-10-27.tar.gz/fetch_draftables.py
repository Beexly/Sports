import asyncio
import json
import os
from playwright.async_api import async_playwright

targets = [
    (155204, 'dk_draftables_155204_tnf_showdown.json'),
    (155198, 'dk_draftables_155198_w7_main_slate.json')
]

out_dirs = [
    r'C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\dfs',
    r'C:\Users\Garrett\Sports\docs\data-sources\research\2026-10-22\dfs'
]

for d in out_dirs:
    os.makedirs(d, exist_ok=True)

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            executable_path=r'C:\Program Files\Google\Chrome\Application\chrome.exe',
            headless=True
        )
        context = await browser.new_context(
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'
        )
        page = await context.new_page()
        print('Navigating to draftkings.com...')
        await page.goto('https://www.draftkings.com', wait_until='domcontentloaded')
        
        for dgid, filename in targets:
            url = f'https://api.draftkings.com/draftgroups/v1/draftgroups/{dgid}/draftables'
            print(f'Fetching {dgid} from {url}...')
            result = await page.evaluate('''async (targetUrl) => {
                const res = await fetch(targetUrl);
                return { status: res.status, text: await res.text() };
            }''', url)
            
            status = result.get('status')
            print(f'{dgid} response status: {status}')
            raw_text = result.get('text', '{}')
            data = json.loads(raw_text)
            draftables = data.get('draftables', [])
            print(f'{dgid} parsed {len(draftables)} draftables')
            
            for d in out_dirs:
                dest = os.path.join(d, filename)
                with open(dest, 'w', encoding='utf-8') as f:
                    f.write(raw_text)
                print(f'Saved {filename} to {dest} ({os.path.getsize(dest)} bytes)')
                
        await browser.close()

if __name__ == '__main__':
    asyncio.run(main())
