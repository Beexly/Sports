import json
import pandas as pd
import re

# Load draftables 155198
with open(r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\dfs\dk_draftables_155198_w7_main_slate.json", encoding="utf-8") as f:
    d = json.load(f)

draftables = d.get("draftables", [])

# Load DFF projections
p_fuel = r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\universal-agent-handoff\extracted-samples\dailyfantasyfuel_nfl_projections_2026-10-22.csv"
df_fuel = pd.read_csv(p_fuel)

# Load LineStar ownership
p_line = r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\universal-agent-handoff\extracted-samples\linestar_ownership_full_282_2026-10-22.csv"
df_line = pd.read_csv(p_line)

print(f"Draftables: {len(draftables)}")
print(f"DFF rows: {len(df_fuel)}")
print(f"LineStar rows: {len(df_line)}")

# Normalize names for matching
def norm(name):
    n = re.sub(r"[^a-zA-Z0-9 ]", "", str(name).lower())
    n = re.sub(r"\b(jr|sr|ii|iii|iv)\b", "", n)
    return " ".join(n.split())

dff_map = {}
for _, row in df_fuel.iterrows():
    dff_map[norm(row["name"])] = row

line_map = {}
for _, row in df_line.iterrows():
    line_map[norm(row["name"])] = row

# Check how unique players match
unique_players = {}
for p in draftables:
    pid = p["playerId"]
    if pid not in unique_players:
        unique_players[pid] = p

print(f"Unique players in slate: {len(unique_players)}")

matched_dff = 0
matched_line = 0
for pid, p in unique_players.items():
    nm = norm(p["displayName"])
    if nm in dff_map:
        matched_dff += 1
    if nm in line_map:
        matched_line += 1

print(f"Matched DFF: {matched_dff}/{len(unique_players)}")
print(f"Matched LineStar: {matched_line}/{len(unique_players)}")
