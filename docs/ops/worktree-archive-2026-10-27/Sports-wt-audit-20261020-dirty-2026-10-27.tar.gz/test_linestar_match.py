import json
import pandas as pd
import re

with open(r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\dfs\dk_draftables_155198_w7_main_slate.json", encoding="utf-8") as f:
    d = json.load(f)

draftables = d.get("draftables", [])
p_line = r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\universal-agent-handoff\extracted-samples\linestar_ownership_full_282_2026-10-22.csv"
df_line = pd.read_csv(p_line)

def norm_init_last(fn, ln):
    init = fn[0].lower() if fn else ""
    last = re.sub(r"[^a-zA-Z]", "", ln.lower())
    return f"{init}_{last}"

def norm_line(name):
    # e.g. 'C. McCaffrey' -> init='c', last='mccaffrey'
    # e.g. 'Titans' -> last='titans'
    parts = name.strip().split()
    if len(parts) == 1:
        return f"_{re.sub(r'[^a-zA-Z]', '', parts[0].lower())}"
    init = parts[0][0].lower()
    last = re.sub(r"[^a-zA-Z]", "", "".join(parts[1:]).lower())
    return f"{init}_{last}"

line_by_key_sal = {}
for _, row in df_line.iterrows():
    key = norm_line(row["name"])
    line_by_key_sal[(key, int(row["salary"]))] = row["owned_pct"]
    line_by_key_sal[key] = row["owned_pct"]

unique_players = {}
for p in draftables:
    pid = p["playerId"]
    if pid not in unique_players:
        unique_players[pid] = p

matched = 0
for pid, p in unique_players.items():
    fn = p.get("firstName", "")
    ln = p.get("lastName", "")
    sal = p.get("salary", 0)
    key = norm_init_last(fn, ln) if fn else f"_{re.sub(r'[^a-zA-Z]', '', ln.lower())}"
    if (key, sal) in line_by_key_sal or key in line_by_key_sal:
        matched += 1

print(f"Matched LineStar players with key matching: {matched}/{len(unique_players)}")
