import json

with open(r"C:\Users\Garrett\Sports-wt-audit-20261020\outbox\thursday_10_22_dfs_optimal_results.json", encoding="utf-8") as f:
    d = json.load(f)

print("Audit Status:", d["audit_status"])
print("Showdown Matchup:", d["part_a_showdown_ne_chi"]["slate_info"]["matchup"])
cash_sd = d["part_a_showdown_ne_chi"]["cash_optimal_lineup"]
print(f"Showdown Cash: Salary=${cash_sd['total_salary']:,}, Proj={cash_sd['projected_points']}, CPT={cash_sd['captain']['name']}")

for lu in d["part_a_showdown_ne_chi"]["gpp_leverage_lineups"]:
    data = lu["data"]
    print(f"{lu['lineup_title']}: Sal=${data['total_salary']:,}, Proj={data['projected_points']}, Ceiling={data['ceiling_points']}, CPT={data['captain']['name']}")

w7 = d["part_b_week7_main_slate"]
print(f"\nWeek 7 Cash: Sal=${w7['cash_mode']['total_salary']:,}, Proj={w7['cash_mode']['projected_points']}")
print(f"Week 7 Greedy: Sal=${w7['greedy_leverage']['total_salary']:,}, Proj={w7['greedy_leverage']['projected_points']}")
for tabu in w7["tabu_portfolio"]:
    print(f"Week 7 Tabu {tabu['lineup_index']}: Sal=${tabu['total_salary']:,}, Proj={tabu['projected_points']}, GPP={tabu['gpp_score']}")
print(f"Week 7 FieldSim P(>99.5pct): {w7['fieldsim_portfolio']['portfolio_p_hit']}, Cutoff={w7['fieldsim_portfolio']['field_99_5th_percentile_cutoff']}")
