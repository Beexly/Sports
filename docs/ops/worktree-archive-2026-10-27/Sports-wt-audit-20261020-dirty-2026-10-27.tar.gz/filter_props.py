import json
import pandas as pd

json_path = r"C:\Users\Garrett\.gemini\antigravity-cli\brain\6ced681b-ae7a-43f2-b3bf-68bfc9e88a9a\scratch\espn_dk_props_and_neon.json"
with open(json_path, "r", encoding="utf-8") as f:
    data = json.load(f)

props = data.get("espn_dk_props_clean", [])
df = pd.DataFrame(props)
print(f"Total props: {len(df)}")

target_players = [
    "Drake Maye", "Caleb Williams", "D'Andre Swift", "Roschon Johnson",
    "Rhamondre Stevenson", "TreVeyon Henderson", "Rome Odunze",
    "Luther Burden III", "Kalif Raymond", "Colston Loveland", "Cole Kmet",
    "Hunter Henry", "DeMario Douglas", "A.J. Brown"
]

for p in target_players:
    pdf = df[df.athlete.str.contains(p, case=False, na=False)]
    if not pdf.empty:
        print(f"\n=== Props for {p} ===")
        for _, row in pdf.iterrows():
            print(f"  {row['prop_type']:45} Line: {row['line']} (Open: {row['open_line']})")
