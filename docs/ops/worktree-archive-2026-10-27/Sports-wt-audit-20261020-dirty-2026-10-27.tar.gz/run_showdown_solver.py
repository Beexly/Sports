import json
import itertools
import numpy as np

# Load 155204 draftables
with open(r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\dfs\dk_draftables_155204_tnf_showdown.json", encoding="utf-8") as f:
    d = json.load(f)

draftables = d.get("draftables", [])

# Fail-closed roster gate:
# Strictly exclude: Kyle Monangai (OUT), Romeo Doubs (IR), Mack Hollins (IR), Myles Montgomery (IR),
# Reggie Gilliam (IR), Brittain Brown (IR), Nikola Kalinic (IR), Julian Hill (IR), Hayden Large (IR).
# Also note CHI defense injuries: T.J. Edwards (Doubtful), Jack Sanborn (OUT).
# Also note NE offensive line injuries: Ben Brown (OUT), Morgan Moses (Q).

EXCLUDE = {
    "kyle monangai", "romeo doubs", "mack hollins", "myles montgomery", "reggie gilliam",
    "brittain brown", "nikola kalinic", "julian hill", "hayden large"
}

# Signal-adjusted projections (mu), volatility (sigma), and projected DK ownership (own)
# Derived from 2026 PBP metrics, OSF xFP regression, and injury reallocation.
SHOWDOWN_PROFILES = {
    "Caleb Williams": {
        "mu": 20.4, "sigma": 6.8, "own_flex": 0.42, "own_cpt": 0.14,
        "note": "CHI starting QB; high floor/ceiling; red zone rushing threat (4 RZ rushes in 2026)"
    },
    "Drake Maye": {
        "mu": 18.8, "sigma": 6.4, "own_flex": 0.38, "own_cpt": 0.12,
        "note": "NE starting QB; Ben Brown OUT + Moses Q boosts scramble share (30 rushes in 2026)"
    },
    "D'Andre Swift": {
        "mu": 20.2, "sigma": 6.5, "own_flex": 0.52, "own_cpt": 0.20,
        "note": "Kyle Monangai OUT -> bellcow role (absorbs 60 carries / 14 RZ carries); projected 18-22 touches"
    },
    "DeMario Douglas": {
        "mu": 15.2, "sigma": 5.0, "own_flex": 0.36, "own_cpt": 0.10,
        "note": "Doubs & Hollins on IR; Edwards (D) & Sanborn (OUT) leaves CHI middle vulnerable to slot WR"
    },
    "Rhamondre Stevenson": {
        "mu": 14.6, "sigma": 5.1, "own_flex": 0.32, "own_cpt": 0.08,
        "note": "Lead early-down back + checkdown boost vs missing CHI LBs; 57 rushes + 20 targets in 2026"
    },
    "Luther Burden III": {
        "mu": 14.2, "sigma": 5.2, "own_flex": 0.34, "own_cpt": 0.09,
        "note": "CHI target leader (35 tgts, 19.1% share, 8 RZ tgts); electric rookie separator"
    },
    "Rome Odunze": {
        "mu": 13.5, "sigma": 5.8, "own_flex": 0.28, "own_cpt": 0.08,
        "note": "Deep threat leverage: 14.0 aDOT, 406 air yards; massive GPP ceiling"
    },
    "Hunter Henry": {
        "mu": 13.0, "sigma": 4.8, "own_flex": 0.26, "own_cpt": 0.07,
        "note": "Prime beneficiary of CHI LB injuries (Edwards/Sanborn out); red-zone target priority"
    },
    "A.J. Brown": {
        "mu": 9.5, "sigma": 5.0, "own_flex": 0.10, "own_cpt": 0.02,
        "note": "High salary ($9000), limited recent volume (4 targets in 2026); contrarian leverage only"
    },
    "Colston Loveland": {
        "mu": 8.8, "sigma": 4.0, "own_flex": 0.16, "own_cpt": 0.03,
        "note": "CHI TE1: 23 targets, 6 RZ targets in 2026; solid intermediate option"
    },
    "Kalif Raymond": {
        "mu": 7.8, "sigma": 3.8, "own_flex": 0.18, "own_cpt": 0.02,
        "note": "High efficiency WR3: 27 targets, 0.62 EPA/target; key salary relief at $3,400"
    },
    "Cairo Santos": {
        "mu": 7.8, "sigma": 3.2, "own_flex": 0.18, "own_cpt": 0.01,
        "note": "CHI K: 8.0 FPPG baseline, favorable dome/weather conditions"
    },
    "Bears": {
        "mu": 7.2, "sigma": 4.2, "own_flex": 0.20, "own_cpt": 0.02,
        "note": "CHI DST: facing degraded NE OL (Ben Brown OUT, Moses Q); sack/turnover floor"
    },
    "Andy Borregales": {
        "mu": 6.8, "sigma": 3.0, "own_flex": 0.14, "own_cpt": 0.01,
        "note": "NE K: 7.0 FPPG baseline"
    },
    "Efton Chism III": {
        "mu": 6.7, "sigma": 3.4, "own_flex": 0.15, "own_cpt": 0.01,
        "note": "NE WR3: absorbing vacated Doubs/Hollins snaps; 13 targets in 2026; elite $2,800 salary saver"
    },
    "Patriots": {
        "mu": 6.5, "sigma": 4.0, "own_flex": 0.16, "own_cpt": 0.01,
        "note": "NE DST: facing rookie Caleb Williams; pressure opportunity"
    },
    "TreVeyon Henderson": {
        "mu": 6.4, "sigma": 3.6, "own_flex": 0.12, "own_cpt": 0.02,
        "note": "NE RB2: 42 carries, 4 targets in 2026; explosive change-of-pace"
    },
    "Roschon Johnson": {
        "mu": 5.8, "sigma": 3.4, "own_flex": 0.14, "own_cpt": 0.01,
        "note": "CHI RB2 behind Swift: 9 carries, 8 targets; goal line vulture risk at $4,400"
    },
    "Eli Raridon": {
        "mu": 4.5, "sigma": 2.9, "own_flex": 0.07, "own_cpt": 0.005,
        "note": "NE TE2: 9 targets, 3 RZ targets in 2026"
    },
    "Kyle Williams": {
        "mu": 4.2, "sigma": 2.8, "own_flex": 0.06, "own_cpt": 0.005,
        "note": "NE WR4: 10 targets in 2026"
    },
    "Cole Kmet": {
        "mu": 4.0, "sigma": 2.8, "own_flex": 0.08, "own_cpt": 0.005,
        "note": "CHI TE2 behind Loveland: 9 targets in 2026"
    },
    "Corey Kiner": {
        "mu": 2.5, "sigma": 2.0, "own_flex": 0.03, "own_cpt": 0.001,
        "note": "NE RB3: 20 carries in 2026"
    },
    "Zavion Thomas": {
        "mu": 2.0, "sigma": 1.8, "own_flex": 0.02, "own_cpt": 0.001,
        "note": "CHI returner / depth WR"
    },
    "Jahdae Walker": {
        "mu": 1.8, "sigma": 1.6, "own_flex": 0.02, "own_cpt": 0.001,
        "note": "CHI depth WR"
    },
    "Lan Larison": {
        "mu": 1.5, "sigma": 1.5, "own_flex": 0.01, "own_cpt": 0.001,
        "note": "NE depth RB"
    },
    "Sam Roush": {
        "mu": 1.2, "sigma": 1.4, "own_flex": 0.01, "own_cpt": 0.001,
        "note": "CHI depth TE"
    },
    "Zavier Scott": {
        "mu": 0.8, "sigma": 1.0, "own_flex": 0.005, "own_cpt": 0.0005,
        "note": "CHI depth RB"
    }
}

# Collect active player roster
active_players = {}
for p in draftables:
    name = p["displayName"]
    if name.lower() in EXCLUDE:
        continue
    status = str(p.get("status", "")).upper()
    if status in ("OUT", "IR", "DOUBTFUL", "D", "SUSPENDED"):
        continue
    if p.get("isDisabled", False):
        continue
    if name not in SHOWDOWN_PROFILES:
        continue
    
    prof = SHOWDOWN_PROFILES[name]
    slot_id = p["rosterSlotId"]
    if slot_id == 512: # FLEX
        active_players[name] = {
            "name": name,
            "team": p["teamAbbreviation"],
            "pos": p["position"],
            "salary_flex": p["salary"],
            "salary_cpt": int(round(p["salary"] * 1.5)),
            "mu": prof["mu"],
            "sigma": prof["sigma"],
            "own_flex": prof["own_flex"],
            "own_cpt": prof["own_cpt"],
            "note": prof["note"],
            "pid": p["playerId"]
        }

print(f"Active Showdown Player Pool: {len(active_players)} players")

# Enumerate ALL legal Captain + 5 FLEX combinations
# Cap <= 50,000, must span both teams (at least 1 NE, at least 1 CHI)
player_list = list(active_players.values())
n = len(player_list)

all_lineups = []

for cpt_idx, cpt in enumerate(player_list):
    cpt_sal = cpt["salary_cpt"]
    rem_sal = 50000 - cpt_sal
    if rem_sal < 0:
        continue
    
    other_indices = [i for i in range(n) if i != cpt_idx]
    
    for flex_comb in itertools.combinations(other_indices, 5):
        flex_players = [player_list[i] for i in flex_comb]
        tot_flex_sal = sum(p["salary_flex"] for p in flex_players)
        tot_sal = cpt_sal + tot_flex_sal
        if tot_sal > 50000:
            continue
        
        # Check both teams
        teams = {cpt["team"]} | {p["team"] for p in flex_players}
        if len(teams) < 2:
            continue
        
        # Calculate scores
        # Cash score: floor / median projection: 1.5 * cpt_mu + sum(flex_mu)
        mu_tot = 1.5 * cpt["mu"] + sum(p["mu"] for p in flex_players)
        var_tot = (1.5 * cpt["sigma"])**2 + sum(p["sigma"]**2 for p in flex_players)
        sigma_tot = np.sqrt(var_tot)
        floor_tot = mu_tot - 0.5 * sigma_tot
        
        # GPP objective:
        # Correlation adjustments:
        corr_bonus = 0.0
        roster_names = [cpt["name"]] + [p["name"] for p in flex_players]
        roster_teams = [cpt["team"]] + [p["team"] for p in flex_players]
        
        # Caleb Williams stacks
        if "Caleb Williams" in roster_names:
            pass_catchers = {"Luther Burden III", "Rome Odunze", "Colston Loveland", "Kalif Raymond", "D'Andre Swift"}
            chi_targets_in_lineup = sum(1 for name in roster_names if name in pass_catchers)
            corr_bonus += 1.8 * chi_targets_in_lineup
            # Bring-back from NE
            ne_pass_catchers = {"DeMario Douglas", "Hunter Henry", "Rhamondre Stevenson", "Efton Chism III"}
            ne_bring_backs = sum(1 for name in roster_names if name in ne_pass_catchers)
            if ne_bring_backs >= 1:
                corr_bonus += 1.2
                
        # Drake Maye stacks
        if "Drake Maye" in roster_names:
            ne_pass_catchers = {"DeMario Douglas", "Hunter Henry", "Rhamondre Stevenson", "Efton Chism III"}
            ne_targets_in_lineup = sum(1 for name in roster_names if name in ne_pass_catchers)
            corr_bonus += 1.8 * ne_targets_in_lineup
            # Bring-back from CHI
            chi_pass_catchers = {"Luther Burden III", "Rome Odunze", "D'Andre Swift", "Kalif Raymond"}
            chi_bring_backs = sum(1 for name in roster_names if name in chi_pass_catchers)
            if chi_bring_backs >= 1:
                corr_bonus += 1.2
                
        # Swift + Bears DST correlation
        if "D'Andre Swift" in roster_names and "Bears" in roster_names:
            corr_bonus += 1.5
            
        # Stevenson + Patriots DST correlation
        if "Rhamondre Stevenson" in roster_names and "Patriots" in roster_names:
            corr_bonus += 1.5
            
        # RB vs Opposing DST negative correlation
        if "D'Andre Swift" in roster_names and "Patriots" in roster_names:
            corr_bonus -= 2.5
        if "Rhamondre Stevenson" in roster_names and "Bears" in roster_names:
            corr_bonus -= 2.5

        # Ceiling score (90th percentile ceiling)
        ceiling_tot = mu_tot + 1.28 * sigma_tot
        
        # Ownership product / sum
        tot_own = cpt["own_cpt"] + sum(p["own_flex"] for p in flex_players)
        
        # GPP score: mu + 0.8 * (1 - own) * sigma + corr_bonus
        gpp_score = mu_tot + 1.0 * corr_bonus + 0.6 * (1.5 - min(tot_own, 2.5)) * sigma_tot

        all_lineups.append({
            "captain": cpt,
            "flex": flex_players,
            "salary": tot_sal,
            "mu": round(mu_tot, 2),
            "sigma": round(sigma_tot, 2),
            "floor": round(floor_tot, 2),
            "ceiling": round(ceiling_tot, 2),
            "tot_own": round(tot_own * 100, 1),
            "gpp_score": round(gpp_score, 2),
            "corr_bonus": round(corr_bonus, 2)
        })

print(f"Total legal valid Showdown lineups evaluated: {len(all_lineups):,}")

# 1. Exact Cash Optimum (Highest floor / median projection)
cash_lineup = max(all_lineups, key=lambda x: (x["mu"], x["floor"]))
print("\n" + "="*80)
print("EXACT GLOBAL OPTIMUM CASH SHOWDOWN LINEUP (Max Median Projection)")
print("="*80)
print(f"Total Salary: ${cash_lineup['salary']:,} / $50,000 | Projected: {cash_lineup['mu']} pts | Floor: {cash_lineup['floor']} pts | Own: {cash_lineup['tot_own']}%")
print(f"CPT:  {cash_lineup['captain']['name']} ({cash_lineup['captain']['team']} {cash_lineup['captain']['pos']}) - ${cash_lineup['captain']['salary_cpt']:,} [Proj: {cash_lineup['captain']['mu']*1.5:.1f} pts, Own: {cash_lineup['captain']['own_cpt']*100:.0f}%]")
for p in cash_lineup["flex"]:
    print(f"FLEX: {p['name']} ({p['team']} {p['pos']}) - ${p['salary_flex']:,} [Proj: {p['mu']:.1f} pts, Own: {p['own_flex']*100:.0f}%]")

# 2. Top 3 GPP Leverage Lineups
# Filter distinct captain / strategic archetypes
sorted_gpp = sorted(all_lineups, key=lambda x: -x["gpp_score"])

# Find top Caleb Williams CPT or D'Andre Swift CPT
gpp_cpt_candidates = {}
for lu in sorted_gpp:
    cpt_name = lu["captain"]["name"]
    if cpt_name not in gpp_cpt_candidates:
        gpp_cpt_candidates[cpt_name] = lu

print("\n" + "="*80)
print("TOP GPP LEVERAGE SHOWDOWN LINEUPS (Ceiling + Ownership + Stacking Correlation)")
print("="*80)

# Lineup 1: Caleb Williams CPT Stack (Dominant Passing Ceiling Stack)
cw_lineup = gpp_cpt_candidates.get("Caleb Williams")
print("\n--- GPP Lineup 1: Caleb Williams CPT Bears Air Attack Stack ---")
print(f"Salary: ${cw_lineup['salary']:,} / $50,000 | GPP Score: {cw_lineup['gpp_score']} | Proj: {cw_lineup['mu']} | Ceiling: {cw_lineup['ceiling']} | Corr Bonus: +{cw_lineup['corr_bonus']}")
print(f"CPT:  {cw_lineup['captain']['name']} ({cw_lineup['captain']['team']} {cw_lineup['captain']['pos']}) - ${cw_lineup['captain']['salary_cpt']:,}")
for p in cw_lineup["flex"]:
    print(f"FLEX: {p['name']} ({p['team']} {p['pos']}) - ${p['salary_flex']:,}")

# Lineup 2: D'Andre Swift CPT Stack (Monangai Out Bellcow Game-Script Stack)
swift_lineup = gpp_cpt_candidates.get("D'Andre Swift")
print("\n--- GPP Lineup 2: D'Andre Swift CPT Bellcow Workload Stack ---")
print(f"Salary: ${swift_lineup['salary']:,} / $50,000 | GPP Score: {swift_lineup['gpp_score']} | Proj: {swift_lineup['mu']} | Ceiling: {swift_lineup['ceiling']} | Corr Bonus: +{swift_lineup['corr_bonus']}")
print(f"CPT:  {swift_lineup['captain']['name']} ({swift_lineup['captain']['team']} {swift_lineup['captain']['pos']}) - ${swift_lineup['captain']['salary_cpt']:,}")
for p in swift_lineup["flex"]:
    print(f"FLEX: {p['name']} ({p['team']} {p['pos']}) - ${p['salary_flex']:,}")

# Lineup 3: Rome Odunze / Hunter Henry / DeMario Douglas CPT (Low-Owned Leverage Stack)
leverage_cpt = gpp_cpt_candidates.get("Rome Odunze") or gpp_cpt_candidates.get("DeMario Douglas") or gpp_cpt_candidates.get("Hunter Henry")
print(f"\n--- GPP Lineup 3: {leverage_cpt['captain']['name']} CPT High-Leverage Tournament Stack ---")
print(f"Salary: ${leverage_cpt['salary']:,} / $50,000 | GPP Score: {leverage_cpt['gpp_score']} | Proj: {leverage_cpt['mu']} | Ceiling: {leverage_cpt['ceiling']} | Corr Bonus: +{leverage_cpt['corr_bonus']}")
print(f"CPT:  {leverage_cpt['captain']['name']} ({leverage_cpt['captain']['team']} {leverage_cpt['captain']['pos']}) - ${leverage_cpt['captain']['salary_cpt']:,}")
for p in leverage_cpt["flex"]:
    print(f"FLEX: {p['name']} ({p['team']} {p['pos']}) - ${p['salary_flex']:,}")
