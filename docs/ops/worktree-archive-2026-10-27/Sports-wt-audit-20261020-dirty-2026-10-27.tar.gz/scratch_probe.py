import urllib.request
import json

url = "https://site.api.espn.com/apis/site/v2/sports/football/nfl/summary?event=401873010"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
with urllib.request.urlopen(req, timeout=15) as resp:
    data = json.load(resp)

print("=== Pickcenter ===")
print(json.dumps(data.get("pickcenter", []), indent=2)[:1000])

print("\n=== GameInfo ===")
print(json.dumps(data.get("gameInfo", {}), indent=2))

print("\n=== Leaders ===")
print(json.dumps(data.get("leaders", []), indent=2)[:1000])
