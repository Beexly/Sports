import pandas as pd
import numpy as np

df = pd.read_parquet(r"C:\Users\Garrett\Sports-wt-audit-20261020\intelligence\coaching\data\play_by_play_2026.parquet")

print(f"Total plays: {len(df)}")
df_ne = df[df["posteam"] == "NE"]
df_chi = df[df["posteam"] == "CHI"]

print("\n--- CHI OFFENSE ---")
chi_rushes = df_chi[df_chi["rush_attempt"] == 1]
print("Total CHI rushes:", len(chi_rushes))
chi_rush_counts = chi_rushes["rusher_player_name"].value_counts()
print(chi_rush_counts)

chi_targets = df_chi[df_chi["pass_attempt"] == 1]
print("\nTotal CHI pass attempts:", len(chi_targets))
chi_target_counts = chi_targets["receiver_player_name"].value_counts()
print(chi_target_counts)

print("\n--- NE OFFENSE ---")
ne_rushes = df_ne[df_ne["rush_attempt"] == 1]
print("Total NE rushes:", len(ne_rushes))
ne_rush_counts = ne_rushes["rusher_player_name"].value_counts()
print(ne_rush_counts)

ne_targets = df_ne[df_ne["pass_attempt"] == 1]
print("\nTotal NE pass attempts:", len(ne_targets))
ne_target_counts = ne_targets["receiver_player_name"].value_counts()
print(ne_target_counts)
