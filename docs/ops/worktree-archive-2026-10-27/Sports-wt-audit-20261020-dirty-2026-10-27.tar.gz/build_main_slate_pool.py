import json
import pandas as pd
import re

# Load draftables 155198
with open(r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\dfs\dk_draftables_155198_w7_main_slate.json", encoding="utf-8") as f:
    d = json.load(f)

draftables = d.get("draftables", [])

# Load DFF
df_fuel = pd.read_csv(r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\universal-agent-handoff\extracted-samples\dailyfantasyfuel_nfl_projections_2026-10-22.csv")

# Load LineStar
df_line = pd.read_csv(r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\universal-agent-handoff\extracted-samples\linestar_ownership_full_282_2026-10-22.csv")

# Excluded names from prompt and status:
# "Kyle Monangai OUT", "T.J. Edwards Doubtful", "Jack Sanborn OUT", "Anthony Johnson Jr. OUT", 
# "Ben Brown OUT", "Alijah Vera-Tucker IR", "Channing Canada OUT", "Karon Prunty OUT"
EXCLUDE_EXPLICIT = {
    "kyle monangai", "tj edwards", "t.j. edwards", "jack sanborn", "anthony johnson jr", "anthony johnson",
    "ben brown", "alijah veratucker", "alijah veratucker ir", "channing canada", "karon prunty"
}

def clean_name(n):
    return re.sub(r"[^a-zA-Z0-9 ]", "", str(n).lower()).strip()

# Build pool of unique players
pool = {}
for p in draftables:
    pid = p["playerId"]
    name = p["displayName"]
    cname = clean_name(name)
    pos = p["position"]
    team = p.get("teamAbbreviation", "")
    salary = p.get("salary", 0)
    status = str(p.get("status", "")).upper()
    is_disabled = p.get("isDisabled", False)
    
    # Live Roster Gate: Exclude OUT, IR, Doubtful, Suspended, or explicit exclude
    if status in ("OUT", "IR", "DOUBTFUL", "D", "SUSPENDED", "COVID") or is_disabled:
        continue
    if any(ex in cname for ex in EXCLUDE_EXPLICIT):
        continue
    if pos not in ("QB", "RB", "WR", "TE", "DST"):
        continue
        
    fppg_val = 0.0
    for a in p.get("draftStatAttributes", []):
        if a.get("id") == 90:
            try: fppg_val = float(a.get("value", 0))
            except: pass

    if pid not in pool:
        pool[pid] = {
            "pid": pid,
            "name": name,
            "pos": pos,
            "team": team,
            "salary": salary,
            "fppg": fppg_val,
            "status": status
        }

print(f"Total active eligible players in Main Slate: {len(pool)}")
pos_counts = {}
for p in pool.values():
    pos_counts[p["pos"]] = pos_counts.get(p["pos"], 0) + 1
print("Positional counts:", pos_counts)
