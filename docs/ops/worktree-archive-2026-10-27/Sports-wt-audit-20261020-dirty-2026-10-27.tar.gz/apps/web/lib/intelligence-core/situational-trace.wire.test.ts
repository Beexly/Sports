import { describe, it, expect } from "vitest";
import { runIntelligence, type GameBundle } from "./engine";

describe("situational trace wiring (L2 engine invoked in production spine)", () => {
  it("surfaces a situationTrace on runIntelligence output", () => {
    const bundle: GameBundle = {
      gameId: "test-1",
      sport: "nfl",
      league: "NFL",
      selection: "HOME",
      pickType: "MONEYLINE",
      homeTeam: "PHI",
      awayTeam: "DAL",
      commenceTime: new Date(Date.now() + 86400000).toISOString(),
      market: {
        market: "h2h",
        fairProb: 0.6,
        line: -150,
        bookmakerCount: 6,
        consensusPct: 60,
      },
      homeInjuries: [],
      awayInjuries: [],
      homeNgs: [],
      awayNgs: [],
      homePlayerStats: [],
      awayPlayerStats: [],
      homeRatings: [],
      awayRatings: [],
      weather: [],
      gameSignals: [],
      homeSnaps: [],
      awaySnaps: [],
      modelVersion: "test-v1",
      statedConfidence: 0.6,
    } as unknown as GameBundle;
    const res = runIntelligence(bundle);
    expect(res).toHaveProperty("situationTrace");
    if (res.situationTrace) {
      expect(typeof res.situationTrace.ok).toBe("boolean");
      if (!res.situationTrace.ok) {
        expect(res.situationTrace.failReason).toBeTruthy();
      } else {
        expect(res.situationTrace.consistencyPassed).not.toBeNull();
      }
    }
  });

  it("activates positive and negative lean signals without crashing on unclamped probabilities and reconciles NFL SPREAD publishState", () => {
    const bundle: GameBundle = {
      gameId: "nfl-2026-w7-ne-chi",
      sport: "NFL",
      selection: "Chicago Bears -2.5",
      pickType: "SPREAD",
      commenceTime: "2026-10-23T00:15:00.000Z",
      homeTeam: "Chicago Bears",
      awayTeam: "New England Patriots",
      market: {
        market: "SPREAD",
        fairProb: 0.5000,
        line: -2.5,
        bookmakerCount: 7,
        consensusPct: 0.56,
      },
      situation: {
        restDaysHome: 4,
        restDaysAway: 4,
        weatherImpact: 0.025,
        injuryImpact: 0.045,
      },
      extraObservations: [
        {
          family: "PLAY_CHARTING",
          key: "nfl:caleb-epa",
          fact: "Caleb Williams healthy EPA/db lift",
          knownAt: "2026-10-22T22:00:00.000Z",
          origin: "play_by_play_2026",
          trust: 0.94,
          freshness: 0.98,
          lean: 0.48,
          rights: "cleared",
          tier: 1,
        },
        {
          family: "INJURY_AVAILABILITY",
          key: "nfl:chi-lb-void",
          fact: "CHI inside LBs Sanborn + Edwards OUT (negative counter-lean)",
          knownAt: "2026-10-22T22:45:00.000Z",
          origin: "nfl-official-90min-inactives",
          trust: 0.95,
          freshness: 1.0,
          lean: -0.22,
          rights: "cleared",
          tier: 1,
        },
      ],
      modelVersion: "v5.3.0-streams-12-15",
      statedConfidence: 66,
      grade: "SOLID_PLAY",
      now: new Date("2026-10-22T23:00:00.000Z"),
    };
    const res = runIntelligence(bundle);
    expect(res.situationTrace?.ok).toBe(true);
    expect(res.situationTrace?.activeSignals.length).toBeGreaterThanOrEqual(2);
    expect(res.publishState).toBe("CANDIDATE");
    expect(res.withholdReasons).toHaveLength(0);
  });
});
