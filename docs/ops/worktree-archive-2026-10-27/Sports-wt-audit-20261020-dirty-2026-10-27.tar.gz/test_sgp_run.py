import sys
import os
import json
import numpy as np

sys.path.insert(0, os.path.abspath("."))
from intelligence.sgp.sgp_copula_engine import (
    Leg,
    LogNormalMarginal,
    PoissonMarginal,
    NormalMarginal,
    StudentTCopula,
    price_sgp,
    over,
    under,
    american_to_probability,
    nearest_psd_higham,
    is_psd
)

# Test 2-leg SGP: Drake Maye Over 249.5 pass yds + Hunter Henry Over 36.5 rec yds
# Correlation between QB pass yds and TE rec yds is ~0.60
corr_2leg = np.array([
    [1.0, 0.60],
    [0.60, 1.0]
])

legs_2leg = [
    Leg(marginal=LogNormalMarginal(mean=268.5, sd=62.0), condition=over(249.5), label="Drake Maye Over 249.5 Pass Yds"),
    Leg(marginal=LogNormalMarginal(mean=46.5, sd=22.0), condition=over(36.5), label="Hunter Henry Over 36.5 Rec Yds")
]

res = price_sgp(
    legs=legs_2leg,
    correlation=corr_2leg,
    copula="student-t",
    nu=4.0,
    n_draws=50000,
    seed=42,
    book_price_american=+240  # typical standard book price for two -110 legs
)

print(res.summary())
