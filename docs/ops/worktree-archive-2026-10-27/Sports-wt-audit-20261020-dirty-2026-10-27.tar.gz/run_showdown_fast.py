import json
import itertools
import heapq
import math

# Load 155204 draftables
with open(r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\dfs\dk_draftables_155204_tnf_showdown.json", encoding="utf-8") as f:
    d = json.load(f)

draftables = d.get("draftables", [])

EXCLUDE = {
    "kyle monangai", "romeo doubs", "mack hollins", "myles montgomery", "reggie gilliam",
    "brittain brown", "nikola kalinic", "julian hill", "hayden large"
}

SHOWDOWN_PROFILES = {
    "Caleb Williams": {
        "mu": 20.4, "sigma": 6.8, "own_flex": 0.42, "own_cpt": 0.14,
        "note": "CHI starting QB; high floor/ceiling; red zone rushing threat (4 RZ rushes in 2026)"
    },
    "Drake Maye": {
        "mu": 18.8, "sigma": 6.4, "own_flex": 0.38, "own_cpt": 0.12,
        "note": "NE starting QB; Ben Brown OUT + Moses Q boosts scramble share (30 rushes in 2026)"
    },
    "D'Andre Swift": {
        "mu": 20.2, "sigma": 6.5, "own_flex": 0.52, "own_cpt": 0.20,
        "note": "Kyle Monangai OUT -> bellcow role (absorbs 60 carries / 14 RZ carries); projected 18-22 touches"
    },
    "DeMario Douglas": {
        "mu": 15.2, "sigma": 5.0, "own_flex": 0.36, "own_cpt": 0.10,
        "note": "Doubs & Hollins on IR; Edwards (D) & Sanborn (OUT) leaves CHI middle vulnerable to slot WR"
    },
    "Rhamondre Stevenson": {
        "mu": 14.6, "sigma": 5.1, "own_flex": 0.32, "own_cpt": 0.08,
        "note": "Lead early-down back + checkdown boost vs missing CHI LBs; 57 rushes + 20 targets in 2026"
    },
    "Luther Burden III": {
        "mu": 14.2, "sigma": 5.2, "own_flex": 0.34, "own_cpt": 0.09,
        "note": "CHI target leader (35 tgts, 19.1% share, 8 RZ tgts); electric rookie separator"
    },
    "Rome Odunze": {
        "mu": 13.5, "sigma": 5.8, "own_flex": 0.28, "own_cpt": 0.08,
        "note": "Deep threat leverage: 14.0 aDOT, 406 air yards; massive GPP ceiling"
    },
    "Hunter Henry": {
        "mu": 13.0, "sigma": 4.8, "own_flex": 0.26, "own_cpt": 0.07,
        "note": "Prime beneficiary of CHI LB injuries (Edwards/Sanborn out); red-zone target priority"
    },
    "A.J. Brown": {
        "mu": 9.5, "sigma": 5.0, "own_flex": 0.10, "own_cpt": 0.02,
        "note": "High salary ($9000), limited recent volume (4 targets in 2026); contrarian leverage only"
    },
    "Colston Loveland": {
        "mu": 8.8, "sigma": 4.0, "own_flex": 0.16, "own_cpt": 0.03,
        "note": "CHI TE1: 23 targets, 6 RZ targets in 2026; solid intermediate option"
    },
    "Kalif Raymond": {
        "mu": 7.8, "sigma": 3.8, "own_flex": 0.18, "own_cpt": 0.02,
        "note": "High efficiency WR3: 27 targets, 0.62 EPA/target; key salary relief at $3,400"
    },
    "Cairo Santos": {
        "mu": 7.8, "sigma": 3.2, "own_flex": 0.18, "own_cpt": 0.01,
        "note": "CHI K: 8.0 FPPG baseline, favorable conditions"
    },
    "Bears": {
        "mu": 7.2, "sigma": 4.2, "own_flex": 0.20, "own_cpt": 0.02,
        "note": "CHI DST: facing degraded NE OL (Ben Brown OUT, Moses Q); sack/turnover floor"
    },
    "Andy Borregales": {
        "mu": 6.8, "sigma": 3.0, "own_flex": 0.14, "own_cpt": 0.01,
        "note": "NE K: 7.0 FPPG baseline"
    },
    "Efton Chism III": {
        "mu": 6.7, "sigma": 3.4, "own_flex": 0.15, "own_cpt": 0.01,
        "note": "NE WR3: absorbing vacated Doubs/Hollins snaps; 13 targets in 2026; elite $2,800 salary saver"
    },
    "Patriots": {
        "mu": 6.5, "sigma": 4.0, "own_flex": 0.16, "own_cpt": 0.01,
        "note": "NE DST: facing rookie Caleb Williams; pressure opportunity"
    },
    "TreVeyon Henderson": {
        "mu": 6.4, "sigma": 3.6, "own_flex": 0.12, "own_cpt": 0.02,
        "note": "NE RB2: 42 carries, 4 targets in 2026; explosive change-of-pace"
    },
    "Roschon Johnson": {
        "mu": 5.8, "sigma": 3.4, "own_flex": 0.14, "own_cpt": 0.01,
        "note": "CHI RB2 behind Swift: 9 carries, 8 targets; goal line vulture at $4,400"
    },
    "Eli Raridon": {
        "mu": 4.5, "sigma": 2.9, "own_flex": 0.07, "own_cpt": 0.005,
        "note": "NE TE2: 9 targets, 3 RZ targets in 2026"
    },
    "Kyle Williams": {
        "mu": 4.2, "sigma": 2.8, "own_flex": 0.06, "own_cpt": 0.005,
        "note": "NE WR4: 10 targets in 2026"
    },
    "Cole Kmet": {
        "mu": 4.0, "sigma": 2.8, "own_flex": 0.08, "own_cpt": 0.005,
        "note": "CHI TE2 behind Loveland: 9 targets in 2026"
    },
    "Corey Kiner": {
        "mu": 2.5, "sigma": 2.0, "own_flex": 0.03, "own_cpt": 0.001,
        "note": "NE RB3: 20 carries in 2026"
    },
    "Zavion Thomas": {
        "mu": 2.0, "sigma": 1.8, "own_flex": 0.02, "own_cpt": 0.001,
        "note": "CHI returner / depth WR"
    },
    "Jahdae Walker": {
        "mu": 1.8, "sigma": 1.6, "own_flex": 0.02, "own_cpt": 0.001,
        "note": "CHI depth WR"
    },
    "Lan Larison": {
        "mu": 1.5, "sigma": 1.5, "own_flex": 0.01, "own_cpt": 0.001,
        "note": "NE depth RB"
    },
    "Sam Roush": {
        "mu": 1.2, "sigma": 1.4, "own_flex": 0.01, "own_cpt": 0.001,
        "note": "CHI depth TE"
    },
    "Zavier Scott": {
        "mu": 0.8, "sigma": 1.0, "own_flex": 0.005, "own_cpt": 0.0005,
        "note": "CHI depth RB"
    }
}

active_players = {}
for p in draftables:
    name = p["displayName"]
    if name.lower() in EXCLUDE:
        continue
    status = str(p.get("status", "")).upper()
    if status in ("OUT", "IR", "DOUBTFUL", "D", "SUSPENDED") or p.get("isDisabled", False):
        continue
    if name not in SHOWDOWN_PROFILES:
        continue
    if p["rosterSlotId"] == 512:
        prof = SHOWDOWN_PROFILES[name]
        active_players[name] = {
            "name": name,
            "team": p["teamAbbreviation"],
            "pos": p["position"],
            "salary_flex": p["salary"],
            "salary_cpt": int(round(p["salary"] * 1.5)),
            "mu": prof["mu"],
            "sigma": prof["sigma"],
            "own_flex": prof["own_flex"],
            "own_cpt": prof["own_cpt"],
            "note": prof["note"],
            "pid": p["playerId"]
        }

player_list = list(active_players.values())
# Bound per team to top 11 by projection (standard showdown bounds)
chi_players = sorted([p for p in player_list if p["team"] == "CHI"], key=lambda x: -x["mu"])[:11]
ne_players = sorted([p for p in player_list if p["team"] == "NE"], key=lambda x: -x["mu"])[:11]
pool = chi_players + ne_players
n = len(pool)
print(f"Bounded Showdown Pool: {len(pool)} players ({len(chi_players)} CHI, {len(ne_players)} NE)", flush=True)

best_cash = None
best_cash_score = -1e9

# Top lineups by GPP strategy
best_by_cpt = {}

eval_count = 0
for cpt_idx, cpt in enumerate(pool):
    cpt_sal = cpt["salary_cpt"]
    rem_sal = 50000 - cpt_sal
    if rem_sal < 0:
        continue
    
    other_indices = [i for i in range(n) if i != cpt_idx]
    
    for flex_comb in itertools.combinations(other_indices, 5):
        flex_players = [pool[i] for i in flex_comb]
        tot_flex_sal = sum(p["salary_flex"] for p in flex_players)
        tot_sal = cpt_sal + tot_flex_sal
        if tot_sal > 50000:
            continue
        
        # Must span both teams
        teams = {cpt["team"]} | {p["team"] for p in flex_players}
        if len(teams) < 2:
            continue
            
        eval_count += 1
        
        mu_tot = 1.5 * cpt["mu"] + sum(p["mu"] for p in flex_players)
        var_tot = (1.5 * cpt["sigma"])**2 + sum(p["sigma"]**2 for p in flex_players)
        sigma_tot = math.sqrt(var_tot)
        floor_tot = mu_tot - 0.5 * sigma_tot
        ceiling_tot = mu_tot + 1.28 * sigma_tot
        
        # Cash score
        if mu_tot > best_cash_score:
            best_cash_score = mu_tot
            best_cash = {
                "captain": cpt,
                "flex": flex_players,
                "salary": tot_sal,
                "mu": round(mu_tot, 2),
                "sigma": round(sigma_tot, 2),
                "floor": round(floor_tot, 2),
                "ceiling": round(ceiling_tot, 2),
                "tot_own": round((cpt["own_cpt"] + sum(p["own_flex"] for p in flex_players)) * 100, 1)
            }
            
        # GPP objective
        roster_names = {cpt["name"]} | {p["name"] for p in flex_players}
        corr = 0.0
        if "Caleb Williams" in roster_names:
            pass_catchers = {"Luther Burden III", "Rome Odunze", "Colston Loveland", "Kalif Raymond", "D'Andre Swift"}
            corr += 1.8 * len(roster_names & pass_catchers)
            ne_pass_catchers = {"DeMario Douglas", "Hunter Henry", "Rhamondre Stevenson", "Efton Chism III"}
            if len(roster_names & ne_pass_catchers) >= 1:
                corr += 1.2
                
        if "Drake Maye" in roster_names:
            ne_pass_catchers = {"DeMario Douglas", "Hunter Henry", "Rhamondre Stevenson", "Efton Chism III"}
            corr += 1.8 * len(roster_names & ne_pass_catchers)
            chi_pass_catchers = {"Luther Burden III", "Rome Odunze", "D'Andre Swift", "Kalif Raymond"}
            if len(roster_names & chi_pass_catchers) >= 1:
                corr += 1.2
                
        if "D'Andre Swift" in roster_names and "Bears" in roster_names:
            corr += 1.5
        if "Rhamondre Stevenson" in roster_names and "Patriots" in roster_names:
            corr += 1.5
        if "D'Andre Swift" in roster_names and "Patriots" in roster_names:
            corr -= 2.5
        if "Rhamondre Stevenson" in roster_names and "Bears" in roster_names:
            corr -= 2.5
            
        tot_own = cpt["own_cpt"] + sum(p["own_flex"] for p in flex_players)
        gpp_score = mu_tot + 1.0 * corr + 0.6 * (1.6 - min(tot_own, 2.5)) * sigma_tot
        
        cpt_name = cpt["name"]
        if cpt_name not in best_by_cpt or gpp_score > best_by_cpt[cpt_name]["gpp_score"]:
            best_by_cpt[cpt_name] = {
                "captain": cpt,
                "flex": flex_players,
                "salary": tot_sal,
                "mu": round(mu_tot, 2),
                "sigma": round(sigma_tot, 2),
                "ceiling": round(ceiling_tot, 2),
                "tot_own": round(tot_own * 100, 1),
                "gpp_score": round(gpp_score, 2),
                "corr": round(corr, 2)
            }

print(f"Evaluated {eval_count:,} legal combinations in bounded pool.", flush=True)

print("\n" + "="*80)
print("EXACT GLOBAL OPTIMUM CASH SHOWDOWN LINEUP (Max Median / Floor)")
print("="*80)
print(f"Salary: ${best_cash['salary']:,} / $50,000 | Projected: {best_cash['mu']} pts | Floor: {best_cash['floor']} pts | Own: {best_cash['tot_own']}%")
print(f"CPT:  {best_cash['captain']['name']} ({best_cash['captain']['team']} {best_cash['captain']['pos']}) - ${best_cash['captain']['salary_cpt']:,} (Proj: {best_cash['captain']['mu']*1.5:.1f})")
for p in best_cash["flex"]:
    print(f"FLEX: {p['name']} ({p['team']} {p['pos']}) - ${p['salary_flex']:,} (Proj: {p['mu']:.1f})")

print("\n" + "="*80)
print("TOP GPP LEVERAGE SHOWDOWN LINEUPS BY CAPTAIN ARCHETYPE")
print("="*80)

# Sort captains by gpp_score
sorted_captains = sorted(best_by_cpt.values(), key=lambda x: -x["gpp_score"])
for idx, lu in enumerate(sorted_captains[:6], 1):
    cpt = lu["captain"]
    print(f"\nGPP Lineup {idx} [{cpt['name']} CPT ({cpt['team']})]: Score={lu['gpp_score']} | Salary=${lu['salary']:,} | Proj={lu['mu']} | Ceiling={lu['ceiling']} | Corr=+{lu['corr']} | Own={lu['tot_own']}%")
    print(f"  CPT:  {cpt['name']} - ${cpt['salary_cpt']:,} [{cpt['note']}]")
    for f in lu["flex"]:
        print(f"  FLEX: {f['name']} ({f['team']} {f['pos']}) - ${f['salary_flex']:,}")
