import sys
import os
sys.path.insert(0, os.path.abspath("."))
from intelligence.roster.live_roster_gate import LiveRosterGate

test_players = [
    ("Kyle Monangai", "CHI"),
    ("T.J. Edwards", "CHI"),
    ("Jack Sanborn", "CHI"),
    ("Anthony Johnson Jr.", "CHI"),
    ("Ben Brown", "NE"),
    ("Alijah Vera-Tucker", "NE"),
    ("Channing Canada", "NE"),
    ("Karon Prunty", "NE"),
    ("Drake Maye", "NE"),
    ("Caleb Williams", "CHI"),
    ("D'Andre Swift", "CHI"),
    ("Rome Odunze", "CHI"),
    ("Luther Burden III", "CHI"),
    ("Kalif Raymond", "CHI"),
    ("Colston Loveland", "CHI"),
    ("Cole Kmet", "CHI"),
    ("Hunter Henry", "NE"),
    ("DeMario Douglas", "NE"),
    ("Rhamondre Stevenson", "NE"),
]

gate = LiveRosterGate(use_sleeper=False)
gate.load(["CHI", "NE"])
report = gate.verify_players(test_players)
print(f"Checked at: {report.checked_at}, Passed all: {report.passed}")
for v in report.verdicts:
    print(f"{v.player:22} ({v.claimed_team}): ok={str(v.ok):5} status={str(v.status):10} reason={v.reason}")
