import pandas as pd
import numpy as np

pbp_path = r"C:\Users\Garrett\Sports-wt-audit-20261020\intelligence\coaching\data\play_by_play_2026.parquet"
pbp = pd.read_parquet(pbp_path)
print("PBP columns:", [c for c in pbp.columns if any(k in c.lower() for k in ["pass", "rush", "rec", "epa", "cpoe", "air"])][:30])
print(f"Total rows in 2026 PBP: {len(pbp)}")
print("Weeks:", sorted(pbp['week'].dropna().unique()))

# Filter for NE and CHI games
ne_chi_games = pbp[(pbp.home_team.isin(['NE', 'CHI'])) | (pbp.away_team.isin(['NE', 'CHI']))]
print(f"NE and CHI rows: {len(ne_chi_games)}")
