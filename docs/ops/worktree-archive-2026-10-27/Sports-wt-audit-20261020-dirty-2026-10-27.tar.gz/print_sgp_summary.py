import json

with open(r"C:\Users\Garrett\Sports-wt-audit-20261020\outbox\thursday_10_22_props_and_sgp_results.json", "r") as f:
    d = json.load(f)

print("=== 50,000-DRAW STUDENT-T COPULA SGP RESULTS ===")
for s in d["copula_sgps"]:
    print(f"Title: {s['title']}")
    for leg in s['legs']:
        print(f"   • {leg}")
    print(f"  Independent Prob: {s['independent_prob']:.4f} | Copula Joint Prob: {s['true_copula_prob']:.4f}")
    print(f"  Correlation Lift: {s['correlation_lift_pct']:+.2f}% | Copula Lift z-score: {s['z_score']:+.2f}")
    print(f"  Fair American Price: {s['fair_american_price']} | Book Price: {s['book_american_price']} (Implied: {s['book_implied_prob']:.4f})")
    print(f"  Alpha (Edge vs Book): {s['alpha']:+.2f}% | Edge z-score: {s['edge_z_score']:+.2f} | Confirmed Edge: {s['is_confirmed_edge']}")
    print("-" * 75)
