import json

with open(r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\dfs\dk_draftables_155204_tnf_showdown.json", encoding="utf-8") as f:
    d = json.load(f)

draftables = d.get("draftables", [])
slots = set(p["rosterSlotId"] for p in draftables)
print("Unique rosterSlotIds for 155204:", slots)
for s in sorted(slots):
    samples = [p for p in draftables if p["rosterSlotId"] == s]
    p = samples[0]
    print(f"Slot {s}: count={len(samples)}, sample={p['displayName']}, salary={p['salary']}")

with open(r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\dfs\dk_draftables_155198_w7_main_slate.json", encoding="utf-8") as f:
    d2 = json.load(f)

draftables2 = d2.get("draftables", [])
slots2 = set(p["rosterSlotId"] for p in draftables2)
print("\nUnique rosterSlotIds for 155198:", slots2)
for s in sorted(slots2):
    samples = [p for p in draftables2 if p["rosterSlotId"] == s]
    p = samples[0]
    print(f"Slot {s}: count={len(samples)}, sample={p['displayName']}, pos={p['position']}, salary={p['salary']}")
