import sys
import os
import json
import re
import pandas as pd
import numpy as np

# Add intelligence/optimizer to path
sys.path.insert(0, r"C:\Users\Garrett\Sports-wt-audit-20261020\intelligence\optimizer")
import dfs_optimizer_suite as suite

# 1. Load DraftKings draftables for 155198
with open(r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\dfs\dk_draftables_155198_w7_main_slate.json", encoding="utf-8") as f:
    d = json.load(f)

draftables = d.get("draftables", [])

# 2. Load DFF projections and LineStar ownership
p_fuel = r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\universal-agent-handoff\extracted-samples\dailyfantasyfuel_nfl_projections_2026-10-22.csv"
df_fuel = pd.read_csv(p_fuel)

p_line = r"C:\Users\Garrett\Sports-wt-audit-20261020\docs\data-sources\research\2026-10-22\universal-agent-handoff\extracted-samples\linestar_ownership_full_282_2026-10-22.csv"
df_line = pd.read_csv(p_line)

def clean_name(n):
    return re.sub(r"[^a-zA-Z0-9 ]", "", str(n).lower()).strip()

def norm_init_last(fn, ln):
    init = fn[0].lower() if fn else ""
    last = re.sub(r"[^a-zA-Z]", "", ln.lower())
    return f"{init}_{last}"

def norm_line(name):
    parts = name.strip().split()
    if len(parts) == 1:
        return f"_{re.sub(r'[^a-zA-Z]', '', parts[0].lower())}"
    init = parts[0][0].lower()
    last = re.sub(r"[^a-zA-Z]", "", "".join(parts[1:]).lower())
    return f"{init}_{last}"

dff_by_name = {}
for _, row in df_fuel.iterrows():
    dff_by_name[clean_name(row["name"])] = row

line_by_key_sal = {}
for _, row in df_line.iterrows():
    key = norm_line(row["name"])
    sal = int(row["salary"])
    line_by_key_sal[(key, sal)] = float(row["owned_pct"])
    line_by_key_sal[key] = float(row["owned_pct"])

EXCLUDE_EXPLICIT = {
    "kyle monangai", "tj edwards", "t.j. edwards", "jack sanborn", "anthony johnson jr", "anthony johnson",
    "ben brown", "alijah veratucker", "alijah vera-tucker", "channing canada", "karon prunty"
}

# 3. Build deduplicated player pool for suite
pool = {}
mu = {}
sigma = {}
own = {}

for p in draftables:
    pid = p["playerId"]
    name = p["displayName"]
    cname = clean_name(name)
    pos = p["position"]
    team = p.get("teamAbbreviation", "")
    salary = p.get("salary", 0)
    status = str(p.get("status", "")).upper()
    is_disabled = p.get("isDisabled", False)
    
    # Gate check
    if status in ("OUT", "IR", "DOUBTFUL", "D", "SUSPENDED", "COVID") or is_disabled:
        continue
    if any(ex in cname for ex in EXCLUDE_EXPLICIT):
        continue
    if pos not in ("QB", "RB", "WR", "TE", "DST"):
        continue
    if salary <= 0:
        continue
        
    if pid in pool:
        continue
        
    fppg_val = 0.0
    for a in p.get("draftStatAttributes", []):
        if a.get("id") == 90:
            try: fppg_val = float(a.get("value", 0))
            except: pass
            
    # Projection matching
    proj = fppg_val
    dff_match = dff_by_name.get(cname)
    if dff_match is not None:
        proj = float(dff_match["fpts"])
    else:
        # Fallback if no DFF
        if proj <= 0:
            proj = max(2.0, (salary / 1000.0) * 1.8)
            
    # Volatility
    if pos == "QB": sig = max(3.0, proj * 0.32)
    elif pos == "RB": sig = max(3.0, proj * 0.38)
    elif pos == "WR": sig = max(3.5, proj * 0.46)
    elif pos == "TE": sig = max(2.5, proj * 0.44)
    else: sig = max(3.0, proj * 0.55) # DST
    
    # Ownership matching
    fn = p.get("firstName", "")
    ln = p.get("lastName", "")
    k = norm_init_last(fn, ln) if fn else f"_{re.sub(r'[^a-zA-Z]', '', ln.lower())}"
    
    owned_pct = None
    if (k, salary) in line_by_key_sal:
        owned_pct = line_by_key_sal[(k, salary)]
    elif k in line_by_key_sal:
        owned_pct = line_by_key_sal[k]
    elif pos == "DST":
        # check team in linestar
        for lk, lown in line_by_key_sal.items():
            if isinstance(lk, str) and lk.startswith("_") and lk[1:] in clean_name(name):
                owned_pct = lown; break
                
    if owned_pct is not None:
        ownership = owned_pct / 100.0
    else:
        # Model estimated ownership
        ownership = min(0.30, max(0.015, (proj / max(salary, 3000)) * 0.06))
        
    pool[pid] = {
        "pid": pid,
        "name": name,
        "pos": pos,
        "team": team,
        "salary": salary,
        "ppg": fppg_val,
        "mu": round(proj, 2),
        "sigma": round(sig, 2),
        "own": round(ownership, 3)
    }
    mu[pid] = round(proj, 2)
    sigma[pid] = round(sig, 2)
    own[pid] = round(ownership, 3)

print(f"Constructed pool with {len(pool)} active players across 20 teams.", flush=True)

# Test top 5 by mu
top5 = sorted(pool.values(), key=lambda x: -x["mu"])[:5]
print("\nTop 5 Projections in Main Slate:")
for p in top5:
    print(f"  {p['name']} ({p['team']} {p['pos']}) - Sal: ${p['salary']}, Proj: {p['mu']}, Own: {p['own']*100:.1f}%")

# Build pairwise correlations
corr = {}
pids = list(pool.keys())
for i in range(len(pids)):
    p1 = pool[pids[i]]
    for j in range(i + 1, len(pids)):
        p2 = pool[pids[j]]
        pair = (min(p1["pid"], p2["pid"]), max(p1["pid"], p2["pid"]))
        val = 0.0
        # QB + same team WR/TE
        if (p1["pos"] == "QB" and p2["pos"] in ("WR", "TE") and p1["team"] == p2["team"]) or \
           (p2["pos"] == "QB" and p1["pos"] in ("WR", "TE") and p1["team"] == p2["team"]):
            val += 1.8
        # RB + same team DST
        if (p1["pos"] == "RB" and p2["pos"] == "DST" and p1["team"] == p2["team"]) or \
           (p2["pos"] == "RB" and p1["pos"] == "DST" and p1["team"] == p2["team"]):
            val += 1.2
        # RB + opposing team DST
        # We can add game-level matchups if needed, but keeping positive stacks is key
        if val > 0:
            corr[pair] = val

print(f"Built {len(corr)} correlation edges.", flush=True)

# 4. Run Suite Engines
print("\n--- Running Suite Engines ---", flush=True)

# Engine 4: Cash Mode
cash_lu = suite.cash_mode(pool, mu, sigma)
print(f"Cash Mode Lineup: valid={cash_lu is not None}", flush=True)
if cash_lu:
    print(f"  Salary: ${sum(p['salary'] for p in cash_lu):,} | Proj: {suite.raw_score(cash_lu, mu):.1f}")
    for p in cash_lu:
        print(f"    {p['pos']:<4} {p['name']:<22} ({p['team']}) - ${p['salary']:,} [Proj: {mu[p['pid']]:.1f}, Own: {own[p['pid']]*100:.1f}%]")

# Engine 1: Greedy Leverage
lam = 0.8
greedy_lu, greedy_score = suite.greedy_leverage(pool, mu, lam, own, sigma, tries=150)
print(f"\nGreedy Leverage Lineup: valid={greedy_lu is not None}", flush=True)
if greedy_lu:
    print(f"  Salary: ${sum(p['salary'] for p in greedy_lu):,} | GPP Score: {greedy_score:.1f} | Proj: {suite.raw_score(greedy_lu, mu):.1f}")
    for p in greedy_lu:
        print(f"    {p['pos']:<4} {p['name']:<22} ({p['team']}) - ${p['salary']:,} [Proj: {mu[p['pid']]:.1f}, Own: {own[p['pid']]*100:.1f}%]")

# Engine 2: Tabu Portfolio (top 3 distinct GPP lineups)
print("\nRunning Tabu Portfolio (top 3 GPP)...", flush=True)
tabu_top = suite.tabu_portfolio(pool, mu, lam, own, sigma, seed=greedy_lu, n_keep=3, iters=250, time_budget=30)
print(f"Tabu returned {len(tabu_top)} lineups.", flush=True)
for idx, (score, lu) in enumerate(tabu_top[:3], 1):
    print(f"\nTabu Lineup {idx}: GPP Score={score:.1f} | Sal=${sum(p['salary'] for p in lu):,} | Proj={suite.raw_score(lu, mu):.1f}")
    for p in lu:
        print(f"    {p['pos']:<4} {p['name']:<22} ({p['team']}) - ${p['salary']:,} [Proj: {mu[p['pid']]:.1f}, Own: {own[p['pid']]*100:.1f}%]")

# Engine 3: FieldSim Portfolio (targeting 99.5th percentile tail)
print("\nRunning FieldSim Portfolio (1500 field sims, targeting >99.5th percentile)...", flush=True)
fieldsim_lus, p_hit, pctl = suite.fieldsim_portfolio(pool, mu, sigma, own, n_sims=1500, k=3)
print(f"FieldSim finished: P(>99.5pct)={p_hit:.4f}, Field 99.5th Pctl={pctl:.1f}", flush=True)
for idx, lu in enumerate(fieldsim_lus, 1):
    print(f"\nFieldSim Lineup {idx}: Sal=${sum(p['salary'] for p in lu):,} | Proj={suite.raw_score(lu, mu):.1f}")
    for p in lu:
        print(f"    {p['pos']:<4} {p['name']:<22} ({p['team']}) - ${p['salary']:,} [Proj: {mu[p['pid']]:.1f}, Own: {own[p['pid']]*100:.1f}%]")
