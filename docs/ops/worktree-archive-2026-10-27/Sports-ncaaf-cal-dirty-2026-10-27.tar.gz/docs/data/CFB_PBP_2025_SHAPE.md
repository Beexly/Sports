# cfb_pbp_2025_all.csv — shape report (dispatch OVERNIGHT_NCAAF_2026-09-04.md §5 T4)

Owner-local file: `C:/Users/Garrett/Downloads/cfb_pbp_2025_all.csv` (554,440,205 bytes, modified 2026-09-03).
Inspected 2026-09-04 with head/awk (column counts consistent: row 2 has 362 fields; 0 header-length mismatches in a full-file scan).

## Real shape (observed, not assumed)

- Rows: 293,200 plays (+1 header)
- Columns: 362 (full header list observed; play-level EPA/WP/penalty/fumble/first-down chains)
- Distinct games (game_id): 1,657
- Seasons observed: 2025 ONLY
- Weeks observed: 1 through 16
- Odds-bearing columns: `spread` (col 95), `formatted_spread` (col 96), `over_under` (col 97).
  NO moneyline column exists anywhere in the 362 headers.
- Odds population: spread populated 278,239/293,200 (~94.9%), over_under 277,460/293,200 (~94.6%)
- Data warts: numeric `spread` occasionally carries vendor text instead of a number
  (e.g. row ~100k has `DraftKings` in col 95 while `formatted_spread` carries the real
  `Indiana -9.5`); sample rows: `13.5,Alabama -13.5,50.5` / `-2.5,San José State -2.5,55.5`.

Head of file (first 12 cols):

```
year,week,id_play,game_id,game_play_number,half_play_number,drive_play_number,pos_team,def_pos_team,pos_team_score,def_pos_team_score,half
2025,1,401752665101850000,401752665,1,1,1,Alabama,Florida State,0,0,1
2025,1,401752665101855000,401752665,2,2,2,Alabama,Florida State,0,0,1
```

## Provenance chain (as read, 2026-09-04)

- Kaggle dataset: `robbypeery/college-football-data-2025`, uploader Robby Peery, Version 6 (956.01 MB, 14 files).
- Licence declared on the dataset page: **Apache 2.0** — https://www.apache.org/licenses/LICENSE-2.0
- Stated upstream source on the page: **NONE** — the About section reads "No description available".
- Inference (labelled as inference): the column schema (id_play, EPA, wp_before/after, spread,
  formatted_spread, over_under) matches CollegeFootballData.com (CFBD) play-by-play output exactly.
  A Kaggle re-upload inherits its upstream's rights — it does not launder them — so CFBD's own terms
  remain the binding question for anything beyond internal feature modeling.

## Registry entry

`apps/web/lib/scraping/source-rights-registry.ts` → `source_id: "kaggle-cfb-pbp-2025"`,
status `approved_open_license` (Apache 2.0 as actually read), with the upstream-grant caveat
and the features-only scope recorded in `notes`.

## Scope guard

This file is a **feature input only** — down/distance/EPA/WP context for live model features.
It is **never a calibration corpus**: one season (2025), no closing moneyline, and its spread
column is a pre-game snapshot, not a graded settlement record. Calibration work stays on the
nflverse replay corpus (docs/data/NFL_REPLAY_CALIBRATION_2026-09-04.md).
