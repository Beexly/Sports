import { PrismaClient } from "@prisma/client";
const url = process.env["DATABASE_URL"]!.trim();
const p = new PrismaClient({ datasources: { db: { url } } });

async function main() {
  const rows = await p.$queryRawUnsafe<Record<string, unknown>[]>(
    `select "playerName", "statType", "pctShareIntendedAirYards" as v
       from next_gen_stats
      where season = 2026 and "pctShareIntendedAirYards" is not null
      order by "pctShareIntendedAirYards" desc limit 8`,
  );
  console.log("TOP stored pctShareIntendedAirYards values:");
  for (const r of rows) console.log("  ", r.playerName, r.statType, "=", r.v);

  const agg = await p.$queryRawUnsafe<Record<string, unknown>[]>(
    `select min("pctShareIntendedAirYards")::float lo,
            max("pctShareIntendedAirYards")::float hi,
            avg("pctShareIntendedAirYards")::float av,
            count(*)::int n,
            count(*) filter (where "pctShareIntendedAirYards" > 1)::int gt1,
            count(*) filter (where "pctShareIntendedAirYards" <= 1)::int le1
       from next_gen_stats
      where season = 2026 and "pctShareIntendedAirYards" is not null`,
  );
  console.log("RANGE 2026:", JSON.stringify(agg[0]));

  // Same probe on the other newly-wired numeric columns the adapters read.
  const others = await p.$queryRawUnsafe<Record<string, unknown>[]>(
    `select
       min("cpoe")::float cpoe_lo, max("cpoe")::float cpoe_hi,
       min("avgSeparation")::float sep_lo, max("avgSeparation")::float sep_hi,
       min("avgYacAboveExpectation")::float yac_lo, max("avgYacAboveExpectation")::float yac_hi,
       min("completionPct")::float cpct_lo, max("completionPct")::float cpct_hi,
       min("expectedCompletionPct")::float ecpct_lo, max("expectedCompletionPct")::float ecpct_hi,
       min("rushYardsOverExpectedPerAtt")::float rhoe_lo, max("rushYardsOverExpectedPerAtt")::float rhoe_hi
     from next_gen_stats where season = 2026`,
  );
  console.log("OTHER NGS COLUMNS 2026:", JSON.stringify(others[0], null, 1));

  await p.$disconnect();
}
main().catch((e) => { console.error(e.message); process.exit(1); });