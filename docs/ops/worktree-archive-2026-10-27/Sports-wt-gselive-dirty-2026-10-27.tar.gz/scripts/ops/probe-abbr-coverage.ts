import { db } from "@sports/db";
import { nflTeamAbbr, isPlaceholderTeamName } from "@sports/ingestion-pipeline";

async function main() {
  const games = await db.game.findMany({
    where: { sport: { key: "americanfootball_nfl" } },
    select: { homeTeamName: true, awayTeamName: true },
  });
  const names = new Set<string>();
  for (const g of games) { names.add(g.homeTeamName); names.add(g.awayTeamName); }
  let ok = 0; const bad: string[] = [];
  for (const n of names) { if (nflTeamAbbr(n)) ok++; else bad.push(n); }
  console.log(`distinct NFL team names on prod: ${names.size}`);
  console.log(`resolved by nflTeamAbbr: ${ok}`);
  console.log(`UNRESOLVED (${bad.length}): ${JSON.stringify(bad)}`);

  // The safety claim: placeholders and junk must return null, not a guess.
  for (const probe of ["TBD", "Tbd", "", "  ", "Los Angeles Rams", "l.a. rams", "Team", "Dallas Cowboys", "Washington Football Team"]) {
    console.log(`  probe ${JSON.stringify(probe)} -> ${JSON.stringify(nflTeamAbbr(probe))} placeholder=${isPlaceholderTeamName(probe)}`);
  }

  // Would a guess be catastrophic? show which abbrs actually exist in the data.
  const teams = await db.$queryRawUnsafe<{ team: string; n: number }[]>(
    `select team, count(*)::int n from team_game_efficiency where season = 2026 group by team order by team`,
  );
  console.log("team_game_efficiency 2026 abbrs:", teams.map((t) => `${t.team}(${t.n})`).join(" "));
  await db.$disconnect();
}
main().catch((e) => { console.error(e.message); process.exit(1); });