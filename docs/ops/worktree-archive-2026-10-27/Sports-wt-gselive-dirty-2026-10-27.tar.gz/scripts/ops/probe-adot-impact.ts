/**
 * Quantify the pctShareIntendedAirYards unit defect in
 * apps/web/lib/intelligence-core/signal-adapters.ts:200-202.
 *
 *   lean += clamp01(r.pctShareIntendedAirYards) * 0.3;
 *   notes.push(`aDOT share ${(r.pctShareIntendedAirYards * 100).toFixed(0)}%`);
 *
 * If prod stores percentage POINTS (0-100), then clamp01() saturates to 1.0
 * for every row above 1.0 and the term becomes a CONSTANT +0.3 added to
 * every NGS observation -> a uniform home-field tilt, not a signal.
 */
import { PrismaClient } from "@prisma/client";
const p = new PrismaClient({ datasources: { db: { url: process.env["DATABASE_URL"]!.trim() } } });
const clamp01 = (x: number) => (x < 0 ? 0 : x > 1 ? 1 : x);

async function main() {
  const rows = await p.$queryRawUnsafe<{ v: number; t: string }[]>(
    `select "pctShareIntendedAirYards"::float v, "statType" t
       from next_gen_stats
      where season = 2026 and "pctShareIntendedAirYards" is not null`,
  );
  const n = rows.length;
  const sat = rows.filter((r) => r.v > 1);
  const satPct = ((sat.length / n) * 100).toFixed(1);

  console.log(`NGS rows (season 2026) with aDOT share: ${n}`);
  console.log(`  rows where clamp01(v) === 1.0 (saturated, term is constant): ${sat.length} (${satPct}%)`);
  console.log(`  distinct clamp01(v) values produced: ${JSON.stringify([...new Set(rows.map((r) => Math.round(clamp01(r.v) * 100) / 100))])}`);

  // What the adapter's own note text would print.
  const top = rows.sort((a, b) => b.v - a.v).slice(0, 3);
  console.log(`  sample note text: ${top.map((r) => `aDOT share ${(r.v * 100).toFixed(0)}%`).join(" | ")}`);

  // Lean impact per observation: current (buggy) vs percent-corrected.
  const buggy = (v: number) => clamp01(v) * 0.3;
  const fixed = (v: number) => clamp01(v / 100) * 0.3;
  const meanBuggy = rows.reduce((a, r) => a + buggy(r.v), 0) / n;
  const meanFixed = rows.reduce((a, r) => a + fixed(r.v), 0) / n;
  console.log(`  mean adot term as-shipped: ${meanBuggy.toFixed(4)}`);
  console.log(`  mean adot term if percent-corrected: ${meanFixed.toFixed(4)}`);
  console.log(`  overstatement factor: ${(meanBuggy / meanFixed).toFixed(1)}x`);

  // Home/away tilt: the lean is multiplied by +1 (home) / -1 (away).
  // A constant term C on every row produces a net tilt of C * (nHome - nAway).
  const byType = rows.reduce<Record<string, number>>((a, r) => { a[r.t] = (a[r.t] ?? 0) + 1; return a; }, {});
  console.log(`  rows by statType: ${JSON.stringify(byType)}`);
  console.log(`  -> adot term is a CONSTANT +${meanBuggy.toFixed(3)} on EVERY NGS row,`);
  console.log(`     which after the home/away sign flip is a uniform home-field tilt of`);
  console.log(`     +/- ${meanBuggy.toFixed(3)} per row rather than a per-player signal.`);
  await p.$disconnect();
}
main().catch((e) => { console.error(e.message); process.exit(1); });