/**
 * LIVE E2E VERIFICATION (read-only) for PR #975 — "wire real DB rows into the
 * GSE observation bundle".
 *
 * This does NOT reimplement the loader predicates (scripts/ops/proof-bundle-
 * db-wiring.ts does that, which proves the SQL but not the merged code). It
 * imports the ACTUAL modules under test:
 *   - apps/web/lib/intelligence-core/db-loaders.ts  -> loadBundleSurfaces()
 *   - apps/web/lib/picks/intelligence-enrichment.ts -> enrichPickWithIntelligence()
 *
 * The falsifier: for every real prod pick it runs the engine TWICE —
 *   A) surfaces omitted  = the pre-merge behaviour (market context only)
 *   B) surfaces attached = the post-merge behaviour (real DB rows)
 * and reports whether calibratedProb / evidenceHealth / observationCount
 * actually MOVED. Wiring that loads rows but never changes a number is
 * decoration, so a no-op delta is a FAIL here, not a pass.
 *
 *   DATABASE_URL=<ro url> npx tsx scripts/ops/verify-gse-live-e2e.ts
 */
import { db } from "@sports/db";
import { loadBundleSurfaces } from "@/lib/intelligence-core/db-loaders";
import { enrichPickWithIntelligence } from "@/lib/picks/intelligence-enrichment";
import type { UniversalSignals } from "@/lib/intelligence-core/universal-wiring";

const url = process.env["DATABASE_URL"]?.trim();
if (!url || url === "stub" || url.startsWith("changeme")) {
  console.error("verify-gse-live-e2e: DATABASE_URL missing or stub — abort.");
  process.exit(2);
}
if (!/hermes_ro/.test(decodeURIComponent(url))) {
  console.error("verify-gse-live-e2e: refusing to run against a non-read-only role.");
  process.exit(2);
}

type AnyIntel = ReturnType<typeof enrichPickWithIntelligence>;
const n = (v: unknown): string =>
  v == null ? "null" : typeof v === "number" ? v.toFixed(6) : String(v);

async function main(): Promise<void> {
  const games = await db.game.findMany({
    where: { sport: { key: "americanfootball_nfl" }, commenceTime: { gte: new Date() } },
    select: {
      id: true,
      sport: { select: { key: true } },
      homeTeamName: true,
      awayTeamName: true,
      homeTeamId: true,
      commenceTime: true,
    },
    orderBy: { commenceTime: "asc" },
    take: 8,
  });
  console.log(`== prod upcoming NFL games sampled: ${games.length} ==\n`);
  if (games.length === 0) {
    console.log("NO UPCOMING NFL GAMES ON PROD — cannot falsify.");
    process.exit(3);
  }

  let rowsWithDb = 0, rowsTotal = 0, surfacesFilledTotal = 0;
  let moved = 0, unmoved = 0, notesSeen = 0, loadFailures = 0;
  const surfaceTally: Record<string, number> = {};
  const emptyTally: Record<string, number> = {};

  for (const g of games) {
    const input = {
      gameId: g.id,
      homeTeamName: g.homeTeamName,
      awayTeamName: g.awayTeamName,
      commenceTime: g.commenceTime,
    };
    const surfaces = await loadBundleSurfaces(input);
    const res = surfaces.resolution;
    notesSeen += res.notes.length;
    loadFailures += res.notes.filter((x) => /load failed/.test(x)).length;
    for (const x of res.notes) console.log(`  NOTE [${g.homeTeamName} v ${g.awayTeamName}] ${x}`);

    // Real market fields off prod so the engine sees genuine inputs.
    const odds = await db.gameSignal
      .findMany({ where: { gameId: g.id }, take: 1 })
      .catch(() => []);

    const pick = {
      id: g.id,
      selection: `${g.homeTeamName} -3.5`,
      pickType: "SPREAD",
      confidence: 0.62,
      reasoning: "live e2e verification",
      sportKey: g.sport.key,
      commenceTime: g.commenceTime,
      homeTeamName: g.homeTeamName,
      awayTeamName: g.awayTeamName,
      homeFairProb: 0.58,
      marketFairProb: 0.57,
      line: -3.5,
      bookmakerCount: odds ? 8 : null,
      consensusPct: 0.51,
      modelVersion: "v5.3.0",
      pickGrade: "SOLID_PLAY",
    };
    const signals: UniversalSignals = {
      market: {
        consensus: { line: -3.5, total: 44.5, books: 8 },
        devig: { homeProb: 0.58, awayProb: 0.42 },
      },
    };

    // A = pre-merge behaviour. B = post-merge behaviour.
    const A: AnyIntel = enrichPickWithIntelligence(pick, new Date(), signals);
    const B: AnyIntel = enrichPickWithIntelligence(pick, new Date(), signals, surfaces);

    rowsTotal += B.dbRowCount;
    surfacesFilledTotal += B.dbSurfacesFilled;
    if (B.dbRowCount > 0) rowsWithDb++;

    for (const key of B.dbSurfacesEmpty) emptyTally[key] = (emptyTally[key] ?? 0) + 1;
    for (const [k, v] of Object.entries(surfaces as unknown as Record<string, unknown>)) {
      if (Array.isArray(v)) surfaceTally[k] = (surfaceTally[k] ?? 0) + v.length;
    }

    const changed =
      n(A.calibratedProb) !== n(B.calibratedProb) ||
      n(A.evidenceHealth) !== n(B.evidenceHealth) ||
      A.observationCount !== B.observationCount ||
      n(A.knowability) !== n(B.knowability) ||
      n(A.situationalShift) !== n(B.situationalShift);
    if (changed) moved++; else unmoved++;

    console.log(
      `${g.commenceTime.toISOString().slice(0, 16)} ${g.homeTeamName} v ${g.awayTeamName}\n` +
        `  abbr=${res.homeAbbr}/${res.awayAbbr} season=${res.season} asOfWeek=${res.asOfWeek} lagWeek=${res.lagWeek}\n` +
        `  weeks: inj=[${res.weeksSeen.injuries}] rat=[${res.weeksSeen.ratings}] snap=[${res.weeksSeen.snaps}] ngs=[${res.weeksSeen.ngs}]\n` +
        `  A(market only) calibProb=${n(A.calibratedProb)} evidence=${n(A.evidenceHealth)} obs=${A.observationCount} know=${n(A.knowability)}\n` +
        `  B(with DB)       calibProb=${n(B.calibratedProb)} evidence=${n(B.evidenceHealth)} obs=${B.observationCount} know=${n(B.knowability)}\n` +
        `  surfacesFilled=${B.dbSurfacesFilled}/12 dbRowCount=${B.dbRowCount} empty=[${B.dbSurfacesEmpty.join(",") || "none"}] DELTA=${changed ? "MOVED" : "NO-OP"}\n` +
        `  B.why=${JSON.stringify(B.why.slice(0, 3))}\n`,
    );
  }

  console.log("== AGGREGATE ==");
  console.log("surface row totals:", surfaceTally);
  console.log("empty-surface tally:", emptyTally);
  console.log(`picks with >0 DB rows: ${rowsWithDb}/${games.length}`);
  console.log(`total DB rows read: ${rowsTotal} | surfaces filled total: ${surfacesFilledTotal}`);
  console.log(`engine delta: MOVED=${moved} NO-OP=${unmoved}`);
  console.log(`resolution notes=${notesSeen} loader failures=${loadFailures}`);

  // Verdict
  const ok =
    rowsWithDb > 0 && rowsTotal > 0 && moved > 0 && loadFailures === 0;
  console.log(`\nVERDICT: ${ok ? "PASS" : "FAIL"}`);
  await db.$disconnect();
  process.exit(ok ? 0 : 1);
}

main().catch((e) => {
  console.error("HARNESS ERROR:", e);
  process.exit(1);
});