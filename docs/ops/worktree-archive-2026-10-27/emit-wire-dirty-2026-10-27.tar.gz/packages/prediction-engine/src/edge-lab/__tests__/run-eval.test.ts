import { readFileSync, writeFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { it, expect } from 'vitest';
import { fitStackingWeights, runGateArm, runEnsembleArm, runMarketOnlyArm, runPassAllArm, runEdgeThresholdArm, applyFrozenBars } from '../emission-gate-harness.js';

it('runs emission gate evaluation', () => {
  const inPath = resolve('reports/emission-gate-eval-set-v2.jsonl');
  const outPath = resolve('reports/emission-gate-eval-results-2026-10-16.md');
  const raw = readFileSync(inPath,'utf8').trim().split('\n').filter(Boolean).map(l=>JSON.parse(l));

  // Build HarnessRows
  function toHarnessRow(r: any){
    return {
      rowId: r.rowId,
      gameKey: r.gameKey,
      market: r.market,
      baseSignals: r.baseSignals,
      marketPrior: r.marketPrior,
      outcome: r.outcome,
      units: r.units,
      period: r.period,
      tier: r.tier,
    };
  }
  const rows = raw.map(toHarnessRow);
  console.log(`Loaded ${rows.length} rows. Markets: ${JSON.stringify(rows.reduce((a: any,r: any)=>(a[r.market]=(a[r.market]||0)+1,a),{}))}`);

  // Split: calibration = earliest 50% by period, test = latest 50%
  const sorted = [...rows].sort((a: any,b: any)=> String(a.period).localeCompare(String(b.period)) || String(a.rowId).localeCompare(String(b.rowId)));
  const mid = Math.floor(sorted.length/2);
  const calibRows = sorted.slice(0, mid);
  const testRows = sorted.slice(mid);
  console.log(`Calib ${calibRows.length}, Test ${testRows.length}`);

  // Fit weights on calib
  const weights = fitStackingWeights(calibRows, {splitLabel:'calib-50pct', lambda:1e-3});
  console.log(`Weights: ${JSON.stringify(weights.weights)} converged=${weights.converged} iters=${weights.iterations}`);

  // Run arms on test block
  const gate = runGateArm(testRows, weights, {threshold:0.03, abstainBand:0.01});
  const ensemble = runEnsembleArm(testRows, {marketBlend:0.5, edgeThreshold:0});
  const marketOnly = runMarketOnlyArm(testRows);
  const passAll = runPassAllArm(testRows);
  const edgeThr = runEdgeThresholdArm(testRows, 0);

  function fmtMetrics(m: any){
    return `n=${m.n} cov=${(m.coverage*100).toFixed(1)}% meanUnits=${m.meanUnits?.toFixed(4)??'null'} CI=${m.meanUnitsCi95?`[${m.meanUnitsCi95[0].toFixed(4)},${m.meanUnitsCi95[1].toFixed(4)}]`:''} winRate=${m.winRate!=null?(m.winRate*100).toFixed(1)+'%':'null'} brier=${m.brier?.toFixed(4)??'null'} logLoss=${m.logLoss?.toFixed(4)??'null'} ece=${m.ece?.toFixed(4)??'null'} auc=${m.auc?.toFixed(4)??'null'} dup=${(m.duplicationRate*100).toFixed(1)}% falsePass=${m.falsePass?.toFixed(3)??'null'} falseReject=${m.falseReject?.toFixed(3)??'null'}`;
  }
  for(const arm of [gate, ensemble, marketOnly, passAll, edgeThr]){
    console.log(`\n=== ${arm.arm} ===`);
    console.log(fmtMetrics(arm.metrics));
    if(arm.metrics.reliability) console.log(' reliability:', JSON.stringify(arm.metrics.reliability));
    console.log(' notes:', arm.notes.join('; '));
  }

  const gateVerdict = applyFrozenBars(gate, marketOnly.metrics, {games: new Set(testRows.map((r: any)=>r.gameKey)).size});
  console.log(`\nGATE VERDICT: ${gateVerdict.verdict}`);
  for(const l of gateVerdict.lines) console.log(`  ${l.pass===true?'PASS':l.pass===false?'FAIL':'NULL'} ${l.bar}: ${l.measured}`);
  for(const k of gateVerdict.kills) console.log(`  KILL: ${k}`);

  expect(rows.length).toBeGreaterThan(0);
});
